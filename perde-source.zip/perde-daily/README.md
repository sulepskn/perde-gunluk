# Perde günlük güncelleme hazırlığı — henüz etkin değil

Bu klasör GitHub'a yüklenmedi; yeni hesap, ücretli plan veya bulut görevi oluşturulmadı.

Hazırlanan iş her gün 12.17 Türkiye saatinde resmi TMDB başlık dosyalarını ve IMDb puan dosyasını indirir, mevcut sitenin kullandığı statik biçime dönüştürür ve doğrulama geçerse aynı Cloudflare Worker'a yayımlar. Saat kesin çalışma garantisi değildir; GitHub zamanlayıcısı gecikebilir. Kısmi dosyada veya çok az kayıtta yayın yapılmaz, eski canlı veri korunur.

Ücretsiz çalışma hedefi: kullanıcıya ait herkese açık GitHub deposu + standart GitHub runner. İş yalnız açık depoda çalışacak şekilde sınırlandı. Özel depo için ücretli kullanım açılmaz. Oluşturulan büyük veri dosyaları depoya veya GitHub artifact deposuna yazılmaz; sadece küçük kaynak sürüm kaydı commit edilir. Bu sürüm kaydı aynı zamanda gerçek günlük depo etkinliği sağlar.

Gerekli bağlantılar: Kullanıcının GitHub hesabı ve kendi Cloudflare hesabı için Worker yayınlama yetkili bir API token. Token sadece GitHub Actions secret olarak saklanır. Giriş anahtarı, oturum sırrı, kişisel yedekler ve kişisel arşiv verileri bu depoda tutulmaz. Cloudflare'daki mevcut uygulama secret'ları ve veritabanı korunur. Bu dosyaları herkese açmadan önce depo ve erişim kapsamı kullanıcı tarafından onaylanmalıdır.

Günlük görev genel başlık dizinini, IMDb puanlarını ve Türkiye platform kataloğundaki bilinen yapımların platformlarını yeniler. Önceki katalogdaki yapımlar da yeniden kontrol edilir; böylece giren ve çıkanlar karşılaştırılır. Yeni genel katalog kimlikleri de kontrol edilir. İlk platform çalışması karşılaştırma başlangıcıdır; giriş/çıkış geçmişi ikinci tamamlanmış günlük çalışmayla oluşur. Kaynağın verdiği bilgiler gerçek platform hesabından bağımsız olarak doğrulanmış erişim garantisi değildir. Kullanıcı platform düzeltmeleri kalıcı Durable Object SQLite arşivindedir ve bu iş tarafından değiştirilmez.

Dizilerde bölüm süresi gösterilmez; sezon ve toplam bölüm sayısı gösterilir. Süre filtresi yalnız filmler içindir. 2014 ve 2022 gibi ayrı yapım kayıtları birleştirilmez. Filtre sonrası tüm kişisel listeler aynı kaynak üyeliğiyle eşleştirilir.

İlk tam veri oluşturma ve ilk bulut çalışma kaydı doğrulanmadan bu sistemi çalışıyor kabul etmeyin. Site ve veri güncelliği, yayımlanan daily-status.json ile kontrol edilmelidir. Kaynak verilerinin kullanım koşulları geçerlidir; IMDb dosyaları kişisel/ticari olmayan kullanım içindir ve oluşturulan IMDb dosyaları GitHub deposuna eklenmez.
