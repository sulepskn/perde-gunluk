# Perde günlük güncelleme kuruldu

İlk gerçek GitHub Actions çalışması 1 Kasım 2026 tarihinde başarıyla tamamlandı ve aynı Cloudflare sitesine yayımlandı.

Site: https://perde-bagimsiz.sulepiskin.workers.dev/
Görev: https://github.com/sulepskn/perde-gunluk/actions
İlk doğrulanmış çalışma: https://github.com/sulepskn/perde-gunluk/actions/runs/41337845417

Görev her gün Türkiye saatiyle 12.17 için ayarlandı. GitHub kuyruğu nedeniyle başlama saati gecikebilir. Bilgisayarın veya bu sohbetin açık olması gerekmez. Ücretli plan açılmadı.

Günlük iş genel film/dizi kataloğunu, IMDb puan ve oy sayılarını, Türkiye platform kataloğundaki bilinen yapımların platformlarını yeniler. Önceki platform kaydındaki yapımlar yeniden kontrol edilir; yeni katalog kimlikleri de kontrol edilir. İlk platform kaydı karşılaştırma başlangıcıdır: gerçek giriş/çıkış farkları ikinci tamamlanmış günlük çalışmadan itibaren hesaplanır. Kaynakta gecikme veya yanlış platform eşleştirmesi olabilir; gerçek platform hesabından bağımsız erişim garantisi verilmez. Bildirdiğin kalıcı platform düzeltmeleri korunur.

İlk yayında genel katalog 1.650.122 kayıt, IMDb dosyası 1.727.597 kayıt ve Türkiye platform kontrolü 35.374 yapım içerdi. Bunlar farklı kapsamlı kaynaklardır; 1,65 milyon yapımın tek tek platform kontrolü yapıldığı anlamına gelmez.

Yayın öncesi ve sonrası kişisel arşiv karşılaştırıldı: 890 izlenen, 22.337 gizlenen, 6 istek listesi kaydı ve 339 kişisel puan aynı kaldı. Günlük iş kişisel yedekleri veya işaretlemeleri GitHub'a göndermez. Gizlenenler de genel metadata kontrolüne dahildir; kişisel gizleme işaretleri değişmez. Dizilerde sezon ve toplam bölüm sayısı gösterilir, bölüm dakikası gösterilmez; filmlerin süreleri korunur.

Manuel çalıştırma: GitHub Actions sayfasında “Perde daily catalogue IMDb and Turkey platforms” görevini aç, “Run workflow” seç ve main dalında çalıştır. Sonuç yeşil Success olmalıdır. Eksik veya geçersiz veri varsa yayın yapılmaz; mevcut site verileri kalır.

Anahtarlar yalnız deponun GitHub Actions Secrets bölümündedir. Cloudflare anahtarı Workers Scripts: Edit ve Account Settings: Read ile sınırlandırılmıştır. Giriş anahtarı, oturum sırrı ve kişisel arşiv verileri herkese açık depoda bulunmaz. İlk taramanın yalnız genel yapım/platform kontrol kaydı depoya eklenmiştir.

Kaynakların kullanım koşulları geçerlidir. IMDb dosyaları kişisel ve ticari olmayan kullanım içindir; oluşturulan tam IMDb dosyaları GitHub deposuna eklenmez.
