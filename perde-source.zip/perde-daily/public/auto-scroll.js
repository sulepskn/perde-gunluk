(function(root){
function createAutoPager({canLoad,isNear,load,onError=()=>{},delay=200}){let timer=null,stopped=false,running=false;function poke(){if(stopped||timer!==null||running)return;timer=setTimeout(async()=>{timer=null;if(stopped||!canLoad()||!isNear())return;running=true;try{await load()}catch(e){stopped=true;onError(e)}finally{running=false;poke()}},delay)}return{poke,stop(){stopped=true;if(timer!==null)clearTimeout(timer);timer=null}}}
if(typeof module!=='undefined')module.exports={createAutoPager};else root.PerdeAutoScroll={createAutoPager};
})(typeof window!=='undefined'?window:globalThis);
