(function(root){
// Content-based preference estimate, not a calibrated probability.
const ignoredWords = new Set('film movie story this that with from after before their there they them when where which while about into through have been olan olarak kendi sonra once icin gibi daha fakat ancak onun onunla birlikte hayat yasam yeni zaman olanlar birinin kendini kadar karsi these those will would finds must does find makes make young hayatini yasamini'.split(' '));
const plain = (v) => String(v || '').normalize('NFKD').replace(/[\u0300-\u036f]/g, '').replace(/ı/g, 'i').toLowerCase();
function tasteMetadata(x) {
    if (x.taste)
        return x.taste;
    const keywords = x.keywords?.keywords || x.keywords?.results || [];
    return { keywords: keywords.map((k) => Number(k.id)), keywordText: keywords.map((k) => k.name).join(' '), cast: (x.credits?.cast || []).slice(0, 8).map((c) => Number(c.id)), creators: [...(x.created_by || []), ...(x.credits?.crew || []).filter((c) => ['Director', 'Screenplay', 'Writer'].includes(c.job))].slice(0, 12).map((c) => Number(c.id)), collection: x.belongs_to_collection?.id || null, rich: Boolean(x.keywords && x.credits) };
}
const themeRules = [
    ['workplace', /workplace|office|coworker|co-worker|is yeri|isyer|ofis|meslektas/],
    ['sitcom', /sitcom|situation comedy|durum komed/],
    ['absurd', /absurd|surreal|satire|satirical|hiciv|absurt/],
    ['mockumentary', /mockumentary|sahte belgesel/],
    ['romance', /romance|romantic|dating|romantik|ask |sevgili/],
    ['friendship', /friendship|friends|dostluk|arkadas/],
    ['mystery', /mystery|detective|investigation|gizem|dedektif|sorusturma/],
    ['puzzle', /plot twist|mind.?bending|psychological thriller|twist ending|ters kose|psikolojik gerilim/],
    ['time', /time travel|time loop|alternate reality|paradox|zaman yolcul|zaman dongu|paradoks/],
    ['space', /space travel|outer space|planet|astronaut|uzay|gezegen/],
    ['war', /warfare|war film|military|soldier|battlefield|savas|asker|cephe/],
    ['supernatural-horror', /possession|demonic|demon|haunted|exorcism|seytan|musallat|cinler/],
    ['science-fiction', /science fiction|sci-fi|bilim kurgu/],
    ['intelligent-humor', /witty|wit |satirical|satire|black comedy|dark comedy|clever humor|zekice mizah|zeki mizah|hiciv/],
    ['slapstick', /slapstick|toilet humor|toilet humour|gross.out|sulu komedi|bel alti mizah/],
    ['intense-horror', /gore|gory|torture porn|extreme horror|body horror|splatter|graphic violence|vahset|iskence|asiri korku/],
    ['slow-story', /slow cinema|slow.paced|slow.burn|contemplative|meditative|duragan|yavas ilerleyen/],
    ['story-progress', /race against time|fast.paced|high.stakes|zamana karsi|nefes kesen|surukleyici/],
    ['coherent-action', /heist|espionage|spy thriller|soygun|casusluk/],
    ['visual-spectacle', /visually stunning|visual spectacle|spectacular visuals|etkileyici gorsel|gorsel solen/],
    ['incoherent', /nonsensical|incoherent plot|random sketches|anlamsiz skecler|baglantisiz skecler/],
    ['preschool', /preschool|toddler|okul oncesi|anaokulu/]
];
function tasteFeatures(x) {
    const ids = x.genre_ids || x.genres || [];
    const genres = [];
    for (const raw of ids) {
        const id = Number(typeof raw === 'object' ? raw.id : raw);
        for (const g of id === 10759 ? [28, 12] : id === 10765 ? [878, 14] : id === 10768 ? [10752] : [id])
            if (Number.isInteger(g) && g > 0 && !genres.includes(g))
                genres.push(g);
    }
    const meta = tasteMetadata(x), text = plain(x.overview), themeText = text + ' ' + plain(meta.keywordText);
    const words = new Set((text.match(/[a-z]{4,}/g) || []).filter(w => !ignoredWords.has(w)).slice(0, 128));
    const themes = themeRules.filter(([, pattern]) => pattern.test(themeText)).map(([name]) => name);
    if (genres.includes(878) && !themes.includes('science-fiction'))
        themes.push('science-fiction');
    return { genres, words, themes, keywords: meta.keywords || [], cast: meta.cast || [], creators: meta.creators || [], collection: meta.collection, type: x.media_type || (['movie', 'tv'].includes(x.type) ? x.type : ''), language: x.original_language || x.originalLanguage || '', year: Number(x.year || String(x.release_date || x.first_air_date || '').slice(0, 4)) || 0, runtime: Number(x.runtime || x.episode_run_time?.[0]) || 0 };
}
function tasteSimilarity(a, b, wordCounts, documents = 0) {
    const overlap = (aa = [], bb = []) => aa.filter(g => bb.includes(g)).length / Math.max(1, new Set([...aa, ...bb]).size);
    const genre = overlap(a.genres, b.genres);
    const importance = (w) => 1 + Math.log((documents + 1) / ((wordCounts?.get(w) || 0) + 1));
    let common = 0, lengthA = 0, lengthB = 0;
    for (const w of a.words) {
        const weight = importance(w) ** 2;
        lengthA += weight;
        if (b.words.has(w))
            common += weight;
    }
    for (const w of b.words)
        lengthB += importance(w) ** 2;
    const words = common / Math.max(1, Math.sqrt(lengthA * lengthB));
    let score = .24 * genre, weight = .24;
    if (a.words.size && b.words.size) {
        score += .35 * words;
        weight += .35;
    }
    for (const [name, w] of [['themes', .22], ['keywords', .30], ['creators', .10], ['cast', .05]]) {
        if (a[name]?.length && b[name]?.length) {
            score += w * overlap(a[name], b[name]);
            weight += w;
        }
    }
    if (a.collection && a.collection === b.collection) {
        score += .14;
        weight += .14;
    }
    // Era/language/length only refine an already established content match.
    if (genre || words > .1) {
        if (a.language && b.language) {
            score += .02 * Number(a.language === b.language);
            weight += .02;
        }
        if (a.year && b.year) {
            score += .015 * Math.max(0, 1 - Math.abs(a.year - b.year) / 30);
            weight += .015;
        }
        if (a.runtime && b.runtime) {
            score += .015 * Math.min(a.runtime, b.runtime) / Math.max(a.runtime, b.runtime);
            weight += .015;
        }
    }
    let similarity = score / Math.max(.65, weight);
    if (a.type && b.type && a.type !== b.type)
        similarity *= .85;
    if (a.themes?.includes('preschool') !== b.themes?.includes('preschool'))
        similarity *= .5;
    return similarity;
}
function tasteProfile(marks, policy = {}) {
    const unique = new Map();
    const priority = (m) => Number(m.item.userRating) > 0 ? 3 : m.kind === 'hidden' ? 2 : m.kind === 'conversation' ? 1 : 0;
    for (const m of marks) {
        const item = m.item || m, id = String(item.id || '');
        if (!id)
            continue;
        const next = { kind: m.kind || 'watched', item }, previous = unique.get(id);
        if (!previous || priority(next) > priority(previous))
            unique.set(id, next);
    }
    const hiddenContext = new Map(), hiddenIds = new Set();
    const evidence = new Map(), weak = new Map();
    const samples = [];
    // Repeated numbered entries from one series are correlated, not independent evidence against a whole genre.
    const family = (x) => String(x.original || x.title || x.name || x.id).normalize('NFKD').toLowerCase().replace(/\d+/g, '').replace(/[^a-z]+/g, ' ').trim();
    const families = new Map();
    for (const m of unique.values())
        if (Number(m.item.userRating) > 0) {
            const key = family(m.item);
            families.set(key, (families.get(key) || 0) + 1);
        }
    for (const m of unique.values()) {
        const x = m.item, features = tasteFeatures(x), rating = Number(x.userRating) || 0;
        if (rating >= 1 && rating <= 10 || m.kind === 'conversation' && Number.isFinite(x.preference)) {
            const explicit = rating >= 1 && rating <= 10, preference = explicit ? (rating - 5.5) / 4.5 : Math.max(-1, Math.min(1, x.preference)), groupSize = families.get(family(x)) || 1, sampleWeight = (groupSize >= 3 ? 1 / groupSize : 1) * (explicit ? 1 : .65);
            const weight = sampleWeight / Math.sqrt(features.genres.length || 1);
            samples.push({ id: x.id, title: x.title || x.name || '', rating: explicit ? rating : 5.5 + 4.5 * preference, explicit, preference, features, sampleWeight, family: groupSize >= 3 ? family(x) : x.id });
            for (const g of features.genres) {
                const e = evidence.get(g) || { sum: 0, weight: 0, count: 0 };
                e.sum += preference * weight;
                e.weight += weight;
                e.count++;
                evidence.set(g, e);
            }
        }
        else if (m.kind === 'hidden') {
            hiddenIds.add(x.id);
            for (const value of [...features.genres.map(g => 'genre:' + g), ...features.themes.map(g => 'theme:' + g), ...features.keywords.map((g) => 'keyword:' + g), ...features.creators.map((g) => 'creator:' + g)])
                hiddenContext.set(value, (hiddenContext.get(value) || 0) + 1);
            for (const g of features.genres) {
                const w = weak.get(g) || { wish: 0, hide: 0, watch: 0 };
                w.hide++;
                weak.set(g, w);
            }
        }
        else if (['watched', 'wishlist'].includes(m.kind))
            for (const g of features.genres) {
                const w = weak.get(g) || { wish: 0, hide: 0, watch: 0 };
                if (m.kind === 'wishlist')
                    w.wish++;
                else if (m.kind === 'watched')
                    w.watch++;
                else
                    w.hide++;
                weak.set(g, w);
            }
    }
    // Estimate and confidence are separate: sparse evidence must not automatically pull every score toward 50.
    const weights = new Map();
    for (const [g, e] of evidence)
        weights.set(g, e.sum / e.weight);
    // Hidden titles are negative preferences. Logarithmic caps prevent thousands of hides from overwhelming explicit ratings.
    for (const [g, w] of weak)
        if (!evidence.has(g))
            weights.set(g, Math.min(.22, .08 * Math.log2(1 + w.watch) + .1 * Math.log2(1 + w.wish)) - Math.min(.08, .02 * Math.log2(1 + w.hide)));
    const wordCounts = new Map();
    for (const sample of samples)
        for (const w of sample.features.words)
            wordCounts.set(w, (wordCounts.get(w) || 0) + 1);
    return { policy, weights, evidence, samples, weak, wordCounts, hiddenContext, hiddenIds, ratings: samples.filter(s => s.explicit).length, signals: samples.length + weak.size };
}
function tastePrediction(x, p) {
    const features = tasteFeatures(x);
    const ranked = p.samples.map(s => ({ ...s, similarity: tasteSimilarity(features, s.features, p.wordCounts, p.samples.length) })).filter(s => s.similarity >= .12).sort((a, b) => b.similarity - a.similarity);
    const seenFamilies = new Set();
    const neighbors = ranked.filter(s => { if (s.similarity < Math.max(.12, (ranked[0]?.similarity || 0) * .65) || seenFamilies.has(s.family))
        return false; seenFamilies.add(s.family); return true; }).slice(0, 8);
    const known = features.genres.filter(g => p.evidence.has(g));
    const best = neighbors[0] || null;
    const style = features.themes.filter(name => Number.isFinite(p.policy.themes?.[name])).map(name => ({ name, weight: Number(p.policy.themes[name]) }));
    const styleAffinity = style.length ? style.reduce((sum, x) => sum + x.weight, 0) / style.length : 0;
    const styleSpecific = style.some(x => x.name !== 'science-fiction');
    if (!style.length && !known.length && (!best || best.similarity < .2)) {
        const history = features.genres.filter(g => p.weak.has(g));
        if (history.length) {
            const affinity = history.reduce((sum, g) => sum + (p.weights.get(g) || 0), 0) / history.length;
            return { score: Math.round(50 + 45 * affinity), affinity, confidence: 'history', nearest: null, knownGenres: history };
        }
        return { score: null, affinity: 0, confidence: 'unknown', nearest: null, knownGenres: known };
    }
    const genre = known.reduce((sum, g) => sum + (p.weights.get(g) || 0), 0) / Math.max(1, known.length);
    // Content-based k-nearest-neighbors: equally similar ratings have equal influence, including middling ratings.
    let total = 0, weighted = 0;
    for (const n of neighbors) {
        const weight = Math.pow(n.similarity, 4) * n.sampleWeight;
        weighted += n.preference * weight;
        total += weight;
    }
    const neighbor = total ? weighted / total : genre;
    const sharedWords = best ? [...features.words].filter(w => best.features.words.has(w)).length : 0;
    const contentMatch = Boolean(best && (sharedWords >= 2 || features.themes.some(t => t !== 'science-fiction' && best.features.themes.includes(t)) || features.keywords.some((k) => best.features.keywords.includes(k)) || features.creators.some((k) => best.features.creators.includes(k))));
    const reliability = best ? (contentMatch ? Math.min(1, .65 + best.similarity * .7) : .42) : .25;
    // Genre-only evidence cannot turn an unrelated title into a confident like/dislike.
    const signals = [...features.themes.map(g => 'theme:' + g), ...features.keywords.map((g) => 'keyword:' + g), ...features.creators.map((g) => 'creator:' + g)];
    const contextualDislike = signals.length ? signals.reduce((sum, k) => sum + Math.min(1, Math.log2(1 + (p.hiddenContext.get(k) || 0)) / 4), 0) / signals.length : 0;
    const genreDislike = features.genres.reduce((sum, g) => sum + Math.min(1, Math.log2(1 + (p.hiddenContext.get('genre:' + g) || 0)) / 8), 0) / Math.max(1, features.genres.length);
    // An explicit, closely related positive rating remains stronger than aggregate hides.
    const protection = best?.explicit && best.preference > 0 && best.similarity >= .65 ? .2 : 1;
    const hiddenPenalty = (.22 * contextualDislike + .06 * genreDislike) * protection;
    const direct = Boolean(best?.explicit && best.similarity >= .55 && contentMatch);
    let affinity = (total ? neighbor * .95 + genre * .05 : genre) * reliability;
    if (style.length) {
        const influence = direct ? .12 : total ? .5 : 1;
        const prior = styleAffinity * (styleSpecific ? 1 : .72);
        affinity = affinity * (1 - influence) + prior * influence;
    }
    // A stated aversion to intense horror or incoherent humor is meaningful even alongside a liked genre.
    const strongAversion = style.filter(x => x.weight <= -.7 && ['intense-horror', 'supernatural-horror', 'incoherent', 'slapstick'].includes(x.name));
    if (strongAversion.length && !direct)
        affinity = Math.min(affinity, -.45);
    affinity = Math.max(-1, Math.min(1, affinity - hiddenPenalty));
    // A predicted personal rating of 1 maps to 0, and 10 maps to 99. This is taste fit, not a calibrated probability.
    const score = Math.max(0, Math.min(99, Math.round(49.5 + 49.5 * Math.tanh(1.5 * affinity) / Math.tanh(1.5))));
    return { score, affinity, confidence: style.length ? 'profile' : p.ratings < 5 ? 'early' : 'learned', nearest: best, knownGenres: known };
}
function tasteScore(x, p) { return tastePrediction(x, p).score; }
function tasteAssessment(x, p) {
    const prediction = tastePrediction(x, p), rawVotes = x.vote_count ?? x.votes, votes = rawVotes == null ? null : Number(rawVotes), rawRating = x.vote_average ?? x.rating, rating = rawRating == null ? null : Number(rawRating);
    const overview = String(x.overview || '').trim(), features = tasteFeatures(x);
    const evidence = overview.length < 40 || !features.genres.length ? 'missing_context' : prediction.confidence === 'unknown' || prediction.confidence === 'history' ? 'personal_evidence_missing' : 'supported';
    const nearestLikes = p.samples.filter(s => s.rating >= 7).map(s => ({ ...s, similarity: tasteSimilarity(features, s.features, p.wordCounts, p.samples.length) })).filter(s => s.similarity >= .25).sort((a, b) => b.similarity - a.similarity).slice(0, 2).map(s => ({ id: s.id, title: s.title, rating: s.explicit ? s.rating : null, source: s.explicit ? 'rating' : 'conversation' }));
    const nearestDislikes = p.samples.filter(s => s.rating <= 4).map(s => ({ ...s, similarity: tasteSimilarity(features, s.features, p.wordCounts, p.samples.length) })).filter(s => s.similarity >= .25).sort((a, b) => b.similarity - a.similarity).slice(0, 2).map(s => ({ id: s.id, title: s.title, rating: s.explicit ? s.rating : null, source: s.explicit ? 'rating' : 'conversation' }));
    return { ...prediction, score: evidence === 'supported' ? prediction.score : null, evidence, votes, rating, nearestLikes, nearestDislikes };
}

function profile(state){const marks=[];for(const [kind,map]of [['watched',state.watched],['wishlist',state.wishlist],['hidden',state.hiddenItems]])for(const item of Object.values(map||{}))marks.push({kind,item});for(const item of state.preferences||[])marks.push({kind:'conversation',item});return tasteProfile(marks,state.policy||{})}
let cachedProfile=null,assessments=new WeakMap();
function assess(x,p){if(cachedProfile!==p){cachedProfile=p;assessments=new WeakMap()}const key=JSON.stringify([x.genres,x.genre_ids,x.overview,x.votes,x.vote_count,x.rating,x.vote_average,x.taste,x.keywords,x.credits,x.year,x.runtime,x.originalLanguage]),cached=assessments.get(x);if(cached?.key===key)return cached.value;const value=tasteAssessment(x,p);assessments.set(x,{key,value});return value}
function describe(x,p){if(x.userRating)return{text:'',score:null,color:'#d7a0fa',reason:''};const a=assess(x,p),score=a.evidence==='supported'||a.evidence==='weak_quality'?a.score:null;return{text:score==null?'':'%'+score,score,color:score==null?'#a9adb5':score>=70?'#9eddb5':score>=45?'#e1c37a':'#d99a9a',reason:score==null?(a.evidence==='missing_context'?'Yapımın özet veya tür bilgisi henüz tamamlanmadı.':'Bu içerikle ilgili zevk bilgisi henüz yeterli değil.'):''}}
root.PerdeTaste={metadata:tasteMetadata,profile,score:tasteScore,describe,assess,predict:tastePrediction,features:tasteFeatures,similarity:tasteSimilarity};

})(typeof window!=='undefined'?window:globalThis);
