(function(root){
 // Keep unchanged cards (and loaded posters) in place during background updates.
 function update(container,rows,cardHTML,emptyHTML){
  const old=new Map([...container.children].filter(el=>el.dataset.id).map(el=>[el.dataset.id,el]));
  if(!rows.length){if(container.innerHTML!==emptyHTML)container.innerHTML=emptyHTML;return}
  for(const el of [...container.children])if(!el.dataset.id)el.remove();
  const wanted=new Set(rows.map(x=>x.id));
  for(const [id,el]of old)if(!wanted.has(id))el.remove();
  let cursor=container.firstElementChild;
  for(const row of rows){const html=cardHTML(row);let el=old.get(row.id);
   if(!el||el._perdeHTML!==html){const template=document.createElement('template');template.innerHTML=html;const next=template.content.firstElementChild;next._perdeHTML=html;if(el){if(cursor===el)cursor=next;el.replaceWith(next)}el=next}
   if(el!==cursor)container.insertBefore(el,cursor);cursor=el.nextElementSibling;
  }
 }
 root.PerdeCardGrid={update};
})(window);
