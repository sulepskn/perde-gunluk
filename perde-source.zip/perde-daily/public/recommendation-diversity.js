(function(root){
const genreIds = (x) => (x.genre_ids || x.genres || []).map((g) => Number(typeof g === 'object' ? g.id : g));
function recommendationEligible(x, type = x.media_type || x.type || 'movie', allowKids = false) {
    const votes = Number(x.vote_count ?? x.votes), rating = Number(x.vote_average ?? x.rating), text = String(x.overview || '').toLowerCase();
    const preschool = /okul\s*[öo]ncesi|anaokul|preschool|pre-school|toddlers|minik izleyiciler|küçük izleyiciler/.test(text);
    return votes >= (type === 'tv' ? 200 : 500) && rating >= (type === 'tv' ? 6.5 : 6.3) && (allowKids || !genreIds(x).includes(10762) && !preschool);
}
function recommendationRank(x) {
    const type = x.media_type || x.type || 'movie', votes = Math.max(1, Number(x.vote_count ?? x.votes) || 0), minimum = type === 'tv' ? 200 : 500;
    const reach = Math.max(0, Math.min(100, 100 * Math.log(votes / minimum) / Math.log(100000 / minimum))), quality = Math.max(0, Math.min(10, Number(x.vote_average ?? x.rating) || 6.5));
    return .6 * (Number(x.match_score) || 0) + .25 * quality * 10 + .15 * reach;
}
function overlap(a, b) { const aa = genreIds(a), bb = genreIds(b); return aa.filter(g => bb.includes(g)).length / Math.max(1, new Set([...aa, ...bb]).size); }
function diverseSeeds(rows, limit = 4) {
    const remaining = rows.slice(), selected = [];
    while (remaining.length && selected.length < limit) {
        let best = 0, bestValue = -Infinity;
        remaining.forEach((r, i) => { const similarity = selected.length ? Math.max(...selected.map(s => overlap(r.item, s.item))) : 0; const value = (Number(r.item.userRating) || 6) - 4 * similarity; if (value > bestValue) {
            best = i;
            bestValue = value;
        } });
        selected.push(remaining.splice(best, 1)[0]);
    }
    return selected;
}
function diverseRecommendations(rows, limit = 24) {
    const remaining = rows.slice().sort((a, b) => recommendationRank(b) - recommendationRank(a) || Number(b.vote_count || 0) - Number(a.vote_count || 0) || Number(a.id) - Number(b.id)), selected = [];
    while (remaining.length && selected.length < limit) {
        let best = -1, bestValue = -Infinity;
        const animationCount = selected.filter(x => genreIds(x).includes(16)).length, hasOther = remaining.some(x => !genreIds(x).includes(16));
        remaining.forEach((r, i) => { if (hasOther && genreIds(r).includes(16) && animationCount >= Math.ceil((selected.length + 1) / 2))
            return; const similarity = selected.length ? Math.max(...selected.slice(-6).map(s => overlap(r, s))) : 0; const sameType = selected.length && r.media_type && r.media_type === selected[selected.length - 1].media_type ? 3 : 0; const value = recommendationRank(r) - 18 * similarity - sameType; if (value > bestValue) {
            best = i;
            bestValue = value;
        } });
        if (best < 0)
            best = 0;
        selected.push(remaining.splice(best, 1)[0]);
    }
    return selected;
}

root.PerdeDiversity={recommendations:diverseRecommendations,eligible:recommendationEligible};
})(typeof window!=="undefined"?window:globalThis);
