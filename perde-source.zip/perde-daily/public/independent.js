(() => {
  if (document.getElementById('perde-independent-nav')) return;
  const nav=document.createElement('nav');nav.id='perde-independent-nav';
  nav.style.cssText='display:flex;gap:20px;justify-content:center;padding:12px;background:#172016;font:14px system-ui';
  for(const [title,path] of [['Güncel başlıklar','/guncel'],['Yönetim ve yedek','/yonetim'],['Çıkış yap','/perde-logout']]){
    const a=document.createElement('a');a.textContent=title;a.href=path;a.style.color='#d7f28b';nav.append(a);
  }
  document.body.prepend(nav);
  const until=Date.parse('2026-11-01T00:00:00Z');
  if(Date.now()<until){
    const notice=document.createElement('p');notice.setAttribute('role','status');
    notice.style.cssText='margin:0;padding:16px 5%;background:#42391d;color:#fff0bd;font:15px/1.6 system-ui';
    notice.textContent='Cloudflare hesabının günlük ücretsiz veritabanı okuma kotası doldu. Listelerin silinmedi; yeni veritabanında yedeğinle birebir doğrulandı. Liste erişimi 1 Kasım saat 03.00 (Türkiye) sonrasında yeniden denenmeli.';
    nav.after(notice);
  }
})();
