(function(root){
 const entries=new Map();let paint=null;function redraw(){if(paint)return;paint=setTimeout(()=>{paint=null;root.PerdeHost?.render()},60)}
 function key(params){const p=new URLSearchParams(params);for(const k of ['count_cursor','hide_watched','counts_only','source_count'])p.delete(k);p.sort();return p.toString()}
 function get(params){return entries.get(key(params))}
 function publish(params,ids){const k=key(params),old=entries.get(k);old?.controller?.abort();const entry={ids:new Set(ids),complete:true,pending:false,at:Date.now()};entries.set(k,entry);redraw();return entry}
 async function ensure(params){const k=key(params);let e=entries.get(k);for(const [otherKey,other]of entries)if(otherKey!==k&&other.pending){other.controller.abort();entries.delete(otherKey)}if(e&&(e.pending||e.complete&&Date.now()-e.at<300000||e.error))return e.promise||e;
  e={ids:new Set(),pending:true,complete:false,checked:0,controller:new AbortController(),at:Date.now()};entries.set(k,e);while(entries.size>8){const oldest=entries.keys().next().value;entries.get(oldest)?.controller?.abort();entries.delete(oldest)}
  e.promise=(async()=>{try{const p=new URLSearchParams(params);p.set('counts_only','1');p.set('source_count','1');p.delete('count_cursor');do{if(Date.now()-e.at>180000)throw Error('count_scan_timeout');const r=await fetch('/api/catalog-index?'+p,{signal:AbortSignal.any([e.controller.signal,AbortSignal.timeout(20000)]),cache:'no-store'});if(!r.ok)throw Error('source_count_unavailable');const d=await r.json();if(!Array.isArray(d.source_ids))throw Error('source_membership_missing');for(const id of d.source_ids)e.ids.add(id);e.checked+=Number(d.count_checked)||0;redraw();if(d.next_count_cursor==null){e.complete=true;break}p.set('count_cursor',d.next_count_cursor)}while(true)}catch(error){if(error.name!=='AbortError')e.error=true}finally{e.pending=false;e.at=Date.now();redraw()}return e})();return e.promise;
 }
 function clear(){for(const e of entries.values())e.controller?.abort();entries.clear();redraw()}
 function partition(ids,watched,hiddenItems,hideWatched=true){let hidden=0,seen=0,both=0;for(const id of ids){if(hiddenItems[id])hidden++;if(watched[id])seen++;if(hiddenItems[id]&&watched[id])both++}return{total:ids.size,hidden,seen,both,remaining:ids.size-hidden-(hideWatched?seen-both:0)}}
 root.PerdeMembership={get,publish,ensure,clear,partition};root.addEventListener('perde-platform-correction',clear);
})(window);
