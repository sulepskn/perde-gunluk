import test from 'node:test';import assert from 'node:assert/strict';
import {splitWindow,windowedCount} from '../src/count-windows.mjs';
test('date windows split without missing or overlapping a day',()=>{const [a,b]=splitWindow({type:'movie',lo:'2000-01-01',hi:'2000-12-31',page:1});assert.equal(a.lo,'2000-01-01');assert.equal(b.hi,'2000-12-31');assert.equal(Date.parse(b.lo)-Date.parse(a.hi),86400000)});
test('a source larger than 500 pages is partitioned and completely enumerated',async()=>{
 const p=new URLSearchParams({type:'movie',dated:'1'}),ids=new Set();let calls=0;
 const load=async(type,page,w)=>{calls++;if(w.lo==='1800-01-01'&&w.hi==='2099-12-31')return{total_pages:1000,results:[]};const early=w.lo==='1800-01-01';return{total_pages:1,results:[{id:early?1:2,release_date:early?'1900-01-01':'2000-01-01'}]}};
 const d=await windowedCount(p,['movie'],load,(batch,checked,next)=>({batch,checked,next}));for(const id of d.batch)ids.add(id);assert.equal(d.next,null);assert.deepEqual([...ids],['movie-1','movie-2']);assert.equal(calls,3);
});
