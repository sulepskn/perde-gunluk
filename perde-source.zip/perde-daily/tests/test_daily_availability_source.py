import pathlib
import sys
import unittest
import datetime as dt
import gzip
import io
import json
import tempfile
from unittest.mock import patch

sys.path.insert(0, str(pathlib.Path(__file__).parents[1] / 'scripts'))
from availability_source import item_id, merge_availability, supplemental_entries, refresh_source


def node(identifier, year, provider, tmdb=None, kind='MOVIE'):
    return {'id': identifier, 'objectType': kind, 'content': {
        'title': 'Title ' + identifier, 'originalTitle': 'Original', 'originalReleaseYear': year,
        'fullPath': '/tr/film/title-' + identifier, 'externalIds': {'tmdbId': tmdb, 'imdbId': None},
        'runtime': 23, 'genres': [{'technicalName': 'animation'}], 'productionCountries': ['US']},
        'offers': [{'monetizationType': 'FLATRATE', 'package': {
            'packageId': provider, 'clearName': {8: 'Netflix', 9: 'Amazon Prime Video'}[provider]}}]}


class AvailabilitySourceTests(unittest.TestCase):
    def test_verified_same_day_snapshot_avoids_another_full_scan(self):
        source = {'region': 'TR', 'total': 43102, 'checked_at': int(dt.datetime.now(dt.timezone.utc).timestamp()*1000), 'titles': []}
        def response(request, timeout):
            self.assertEqual(request.get_header('User-agent'), 'PerdeDaily/1.0')
            return io.BytesIO(gzip.compress(json.dumps(source).encode()))
        with tempfile.TemporaryDirectory() as directory, patch('availability_source.urllib.request.urlopen', side_effect=response), patch('availability_source.subprocess.run') as scan:
            result = refresh_source(pathlib.Path(directory)/'source.json')
            self.assertEqual(result['refresh_status'], 'same_day_snapshot')
            self.assertEqual(result['total'], 43102)
            scan.assert_not_called()

    def test_all_years_and_providers_are_merged_without_a_year_or_platform_allowlist(self):
        source = {'total': 2, 'expected': 2, 'checked_at': 1234,
                  'titles': [node('tm1', 1970, 8, '123'), node('ts2', 2026, 9, '456', 'SHOW')]}
        records = {}
        report = merge_availability(records, source, [
            {'provider_id': 8, 'provider_name': 'Netflix'},
            {'provider_id': 119, 'provider_name': 'Amazon Prime Video'}])
        self.assertEqual(records['movie-123']['availability']['offers'][0]['id'], 8)
        self.assertEqual(records['tv-456']['availability']['offers'][0]['id'], 119)
        self.assertEqual(report['mapped_titles'], 2)

    def test_missing_tmdb_mapping_gets_stable_separate_identity(self):
        film = node('tm10', 2025, 8)
        series = node('ts10', 2025, 8, kind='SHOW')
        self.assertEqual(item_id(film), 'movie-900000000010')
        self.assertEqual(item_id(series), 'tv-900000000010')
        self.assertEqual(len(supplemental_entries({'titles': [film, series]})), 2)

    def test_same_provider_name_uses_turkey_identifier(self):
        source = {'total': 1, 'expected': 1, 'checked_at': 1234, 'titles': [node('tm1', 1999, 9, '123')]}
        providers = [{'provider_id': 9, 'provider_name': 'Amazon Prime Video', 'display_priorities': {'US': 1}},
                     {'provider_id': 119, 'provider_name': 'Amazon Prime Video', 'display_priorities': {'TR': 2}}]
        records = {}
        merge_availability(records, source, providers)
        self.assertEqual(records['movie-123']['availability']['offers'][0]['id'], 119)

    def test_source_editions_union_offers_and_an_empty_current_listing_removes_old_offers(self):
        first = node('tm1', 2020, 8, '12')
        second = node('tm2', 2020, 9, '12')
        records = {}
        source = {'total': 2, 'expected': 2, 'checked_at': 1234, 'titles': [first, second]}
        providers = [{'provider_id': 8, 'provider_name': 'Netflix'}, {'provider_id': 119, 'provider_name': 'Amazon Prime Video'}]
        merge_availability(records, source, providers)
        self.assertEqual({p['id'] for p in records['movie-12']['availability']['offers']}, {8, 119})
        first['offers'] = []
        source['titles'] = [first]
        merge_availability(records, source, providers)
        self.assertEqual(records['movie-12']['availability']['offers'], [])
