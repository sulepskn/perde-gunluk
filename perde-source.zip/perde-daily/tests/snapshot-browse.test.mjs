import test from 'node:test';
import assert from 'node:assert/strict';
import {snapshotBrowse, snapshotDiscover} from '../src/snapshot-browse.mjs';
import {snapshotCount} from '../src/snapshot-count.mjs';

const now = Date.now();
const rows = Array.from({length: 80}, (_, i) => [
  (i % 2 ? 'tv-' : 'movie-') + (i + 1), 0, '2025-01-' + String(i % 28 + 1).padStart(2, '0'),
  [16], ['US'], 'en', i, 23, {'1899': ['flatrate']}, now, 'Title ' + i, i, 7
]);
function environment() {
  const manifest = {snapshot: 'test', built_at: new Date(now).toISOString(), count_shards: 1,
    currently_available: rows.length, browse: {total: rows.length, chunk_size: 256, providers: {'1899': 'HBO Max'}}};
  const assets = {'manifest.json': manifest, 'browse-old-0000.json': rows,
    'count-00.json': rows, 'browse-popular-0000.json': rows};
  return {ASSETS: {async fetch(request) {
    const value = assets[new URL(request.url).pathname.split('/').at(-1)];
    return value ? Response.json(value) : new Response('', {status: 404});
  }}, DB: {prepare(sql) {return {bind() {return this;}, async run() {return {};}, async all() {
    if (sql.includes('platform_corrections')) return {results: [{item_id: 'movie-3', provider_id: 1899, blocked: 1}]};
    if (sql.includes('marks')) return {results: [{item_id: 'movie-1', kind: 'watched'}, {item_id: 'tv-2', kind: 'hidden'}]};
    return {results: []};
  }}}}};
}
test('snapshot cards paginate once per title and equal the exact remaining membership', async () => {
  const env = environment(), p = new URLSearchParams({providers: '1899', sort: 'old', hide_watched: '1'});
  const ids = [];
  do {
    const response = await snapshotBrowse(new Request('https://test/api/catalog-index?' + p), env);
    assert.equal(response.status, 200);
    const data = await response.json();
    ids.push(...data.results.map(row => row.media_type + '-' + row.id));
    if (!data.next_cursor) break;
    p.set('cursor', data.next_cursor);
  } while (true);
  const count = await (await snapshotCount(new Request('https://test/api/catalog-index?providers=1899&hide_watched=1'), env)).json();
  assert.equal(ids.length, new Set(ids).size);
  assert.equal(ids.length, count.source_remaining_delta);
  assert.equal(ids.length, 77);
});
test('Film and Dizi partition Hepsi and duration applies only to matching film records', async () => {
  const env = environment();
  for (const type of ['movie', 'tv']) {
    const response = await snapshotDiscover(new Request('https://test/api/catalog?path=discover/' + type + '&providers=1899&sort_by=popularity.desc'), env);
    const data = await response.json();
    assert.ok(data.results.every(row => row.media_type === type));
    assert.ok(data.results.every(row => row.watch_availability.offers[0].name === 'HBO Max'));
    assert.equal(data.perde_has_more, true);
  }
  const data = await (await snapshotBrowse(new Request('https://test/api/catalog-index?providers=1899&type=movie&runtime_max=20'), env)).json();
  assert.deepEqual(data.results, []);
});
test('cursors reject changed filters and a partial snapshot returns an error', async () => {
  const env = environment();
  const data = await (await snapshotBrowse(new Request('https://test/api/catalog-index?providers=1899'), env)).json();
  const p = new URLSearchParams({providers: '8', cursor: data.next_cursor});
  assert.equal((await snapshotBrowse(new Request('https://test/api/catalog-index?' + p), env)).status, 400);
});
