import test from 'node:test';import assert from 'node:assert/strict';import {DatabaseSync} from 'node:sqlite';import {readFile} from 'node:fs/promises';import {gzipSync} from 'node:zlib';import vm from 'node:vm';
import {durableJournalNamespace} from '../src/durable-journal.mjs';import {memoryDatabase} from '../src/memory-sql.mjs';import initSQL from '../vendor/sqlite-runtime.cjs';
const wasm=new WebAssembly.Module(await readFile(new URL('../vendor/sqlite-runtime.wasm',import.meta.url))),SQL=await initSQL({instantiateWasm(imports,receive){const i=new WebAssembly.Instance(wasm,imports);receive(i);return i.exports}});
const source=await readFile(new URL('../src/archive-store.mjs',import.meta.url),'utf8'),schema=vm.runInNewContext('(()=>{'+source.slice(source.indexOf('const SCHEMA='),source.indexOf('const IMPORT='))+';return SCHEMA})()');
function fixture(){const persistent=new DatabaseSync(':memory:'),values=new Map(),metadata=new Map();let puts=0,lists=0,maxBlob=0;
 const storage={sql:{exec(sql,...args){args=args.map(x=>x instanceof ArrayBuffer?Buffer.from(x):x);for(const a of args)if(a instanceof Uint8Array)maxBlob=Math.max(maxBlob,a.byteLength);const before=persistent.prepare('SELECT total_changes() AS n').get().n,rows=persistent.prepare(sql).all(...args);return{toArray:()=>rows,rowsRead:rows.length,rowsWritten:persistent.prepare('SELECT total_changes() AS n').get().n-before}}},transactionSync(fn){persistent.exec('BEGIN');try{const r=fn();persistent.exec('COMMIT');return r}catch(e){persistent.exec('ROLLBACK');throw e}}};
 const kv={values,metadata,get:async k=>values.get(k)||null,getWithMetadata:async k=>({value:values.get(k),metadata:metadata.get(k)}),put:async(k,v,o={})=>{puts++;values.set(k,v);metadata.set(k,o.metadata)},list:async()=>{lists++;return{keys:[...values.keys()].filter(x=>x.startsWith('journal/')).sort().map(name=>({name,metadata:metadata.get(name)})),list_complete:true}},delete:async k=>values.delete(k)};
 return{persistent,storage,kv,puts:()=>puts,lists:()=>lists,maxBlob:()=>maxBlob,open:()=>durableJournalNamespace(kv,storage)};
}
test('thousands of journal writes use existing SQL instead of any KV put and paginate completely',async()=>{
 const f=fixture(),n=f.open();try{for(let i=0;i<2100;i++)await n.put('journal/'+String(i).padStart(13,'0'),JSON.stringify({at:i,statements:[]}),{metadata:{at:i}});
  assert.equal(f.puts(),0);const first=await n.list({prefix:'journal/',limit:1000}),second=await n.list({prefix:'journal/',limit:1000,cursor:first.cursor}),last=await n.list({prefix:'journal/',limit:1000,cursor:second.cursor});
  assert.equal(first.keys.length+second.keys.length+last.keys.length,2100);assert.equal(last.list_complete,true);assert.equal(JSON.parse(await f.open().get('journal/0000000002099')).at,2099);
 }finally{f.persistent.close()}
});
test('legacy KV journals remain readable and later old-version writes are imported during transition',async()=>{
 const f=fixture(),now=Date.now;let time=10000000;Date.now=()=>time;
 try{f.kv.values.set('journal/old','old value');const n=f.open();assert.equal((await n.list({prefix:'journal/'})).keys.length,1);assert.equal(await n.get('journal/old'),'old value');
  f.kv.values.set('journal/late','late value');time+=61000;assert.equal((await n.list({prefix:'journal/'})).keys.length,2);
  const scans=f.lists();time+=11*60000;await f.open().list({prefix:'journal/'});assert.equal(f.lists(),scans);assert.equal(f.puts(),0);
 }finally{Date.now=now;f.persistent.close()}
});
test('large UTF-8 journals are safely split below the SQL row-size limit',async()=>{
 const f=fixture(),n=f.open();try{const value='ğ漢🙂'.repeat(300000);await n.put('journal/large',value);assert.equal(await n.get('journal/large'),value);assert.ok(f.maxBlob()<=512*1024);assert.equal(f.puts(),0)}finally{f.persistent.close()}
});
test('a partial journal failure rolls back the durable header as well',async()=>{
 const f=fixture(),n=f.open();try{f.persistent.exec('DROP TABLE perde_durable_journal_parts');await assert.rejects(n.put('journal/failed','value'));assert.equal(f.persistent.prepare('SELECT COUNT(*) AS n FROM perde_durable_journal').get().n,0)}finally{f.persistent.close()}
});
test('acknowledged personal changes survive cold restart without a new KV snapshot',async()=>{
 const f=fixture();try{const seed=new SQL.Database();seed.run(schema.join(';'));f.kv.values.set('archive.sqlite.b64gz',Buffer.from(gzipSync(seed.export())).toString('base64'));f.kv.metadata.set('archive.sqlite.b64gz',{checkpointAt:Date.now()});seed.close();
  const namespace=f.open(),a=memoryDatabase(namespace,initSQL,wasm);await a.ready;
  const sql='INSERT INTO marks VALUES(?,?,?,?,?,?) ON CONFLICT(user_id,kind,item_id) DO UPDATE SET data=excluded.data,active=excluded.active,updated_at=excluded.updated_at';
  for(let i=0;i<100;i++)await a.prepare(sql).bind('perde-household','hidden','movie-'+i,JSON.stringify({id:'movie-'+i}),1,i).run();assert.equal(f.puts(),0);
  const b=memoryDatabase(f.open(),initSQL,wasm);await b.ready;assert.equal((await b.prepare('SELECT COUNT(*) AS n FROM marks').first()).n,100);assert.equal(b.stats.journalReplayed,100);
  const before=namespace.stats.rowsRead;for(let i=0;i<100;i++)await a.prepare('SELECT COUNT(*) AS n FROM marks').first();assert.equal(namespace.stats.rowsRead,before);
 }finally{f.persistent.close()}
});

test('a blocked KV snapshot write does not block or lose an acknowledged SQL-journal change',async()=>{
 const f=fixture();try{const seed=new SQL.Database();seed.run(schema.join(';'));f.kv.values.set('archive.sqlite.b64gz',Buffer.from(gzipSync(seed.export())).toString('base64'));f.kv.metadata.set('archive.sqlite.b64gz',{checkpointAt:Date.now()-16*60000});seed.close();
  f.kv.put=async()=>{throw Error('KV put daily limit exceeded')};
  const a=memoryDatabase(f.open(),initSQL,wasm);await a.ready;
  await a.prepare('INSERT INTO marks VALUES(?,?,?,?,?,?)').bind('perde-household','hidden','movie-1','{"id":"movie-1"}',1,1).run();
  assert.match(a.stats.checkpointError,/daily limit/);
  const b=memoryDatabase(f.open(),initSQL,wasm);await b.ready;assert.equal((await b.prepare('SELECT item_id FROM marks').first()).item_id,'movie-1');
 }finally{f.persistent.close()}
});

test('legacy personal operations and new SQL operations are both recovered without rewriting legacy KV',async()=>{
 const f=fixture();try{const seed=new SQL.Database();seed.run(schema.join(';'));f.kv.values.set('archive.sqlite.b64gz',Buffer.from(gzipSync(seed.export())).toString('base64'));f.kv.metadata.set('archive.sqlite.b64gz',{checkpointAt:Date.now()});seed.close();
  const sql='INSERT INTO marks VALUES(?,?,?,?,?,?)',old=JSON.stringify({at:1,statements:[{sql,params:['perde-household','hidden','movie-1','{"id":"movie-1"}',1,1]}]});
  f.kv.values.set('journal/legacy',old);f.kv.metadata.set('journal/legacy',{at:1});
  const a=memoryDatabase(f.open(),initSQL,wasm);await a.ready;await a.prepare(sql).bind('perde-household','hidden','movie-2','{"id":"movie-2"}',1,2).run();
  const b=memoryDatabase(f.open(),initSQL,wasm);await b.ready;assert.equal((await b.prepare('SELECT COUNT(*) AS n FROM marks').first()).n,2);assert.equal(f.kv.values.get('journal/legacy'),old);assert.equal(f.puts(),0);
 }finally{f.persistent.close()}
});

test('a failed SQL journal cannot acknowledge or retain a private in-memory change',async()=>{
 const f=fixture();try{const seed=new SQL.Database();seed.run(schema.join(';'));f.kv.values.set('archive.sqlite.b64gz',Buffer.from(gzipSync(seed.export())).toString('base64'));f.kv.metadata.set('archive.sqlite.b64gz',{checkpointAt:Date.now()});seed.close();
  const a=memoryDatabase(f.open(),initSQL,wasm);await a.ready;const original=f.storage.sql.exec;
  f.storage.sql.exec=(sql,...args)=>{if(sql.startsWith('INSERT INTO perde_durable_journal_parts'))throw Error('SQL write unavailable');return original(sql,...args)};
  await assert.rejects(a.prepare('INSERT INTO marks VALUES(?,?,?,?,?,?)').bind('perde-household','hidden','movie-1','{"id":"movie-1"}',1,1).run(),/SQL write unavailable/);
  assert.equal((await a.prepare('SELECT COUNT(*) AS n FROM marks').first()).n,0);assert.equal(f.persistent.prepare('SELECT COUNT(*) AS n FROM perde_durable_journal').get().n,0);
 }finally{f.persistent.close()}
});
