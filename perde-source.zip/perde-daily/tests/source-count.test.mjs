import {test} from 'node:test';
import assert from 'node:assert/strict';
import {sourceCountBatch} from '../src/source-count.mjs';
const base='https://test.invalid/api/catalog-index?counts_only=1&source_count=1&type=tv&providers=8&dated=1&hide_watched=1';
test('provider verification is bounded to one source page and personal overlaps are deduplicated',async()=>{
 const original=globalThis.fetch,calls=[];
 globalThis.fetch=async target=>{const u=new URL(target);calls.push(u);if(u.pathname.endsWith('/watch/providers'))return Response.json({results:{TR:{flatrate:[{provider_id:8,provider_name:'Netflix'}]}}});const page=Number(u.searchParams.get('page'));return Response.json({total_pages:12,total_results:225,results:Array.from({length:page===12?5:20},(_,i)=>({id:(page-1)*20+i+1}))})};
 const db={prepare(sql){if(!sql.includes('FROM marks'))return{bind(){return this},async run(){return{}},async all(){return{results:[]}}};return{bind(owner,ids){assert.equal(owner,'perde-household');this.ids=JSON.parse(ids);return this},async all(){return{results:[{item_id:'tv-10',kind:'hidden'},{item_id:'tv-20',kind:'watched'},{item_id:'tv-21',kind:'watched'},{item_id:'tv-21',kind:'hidden'}].filter(x=>this.ids.includes(x.item_id))}}}}};
 const env={DB:db,TMDB_API_KEY:'test-only'},ctx={waitUntil(){}};
 try{const first=await(await sourceCountBatch(new Request(base),env,ctx)).json();assert.equal(calls.filter(u=>u.pathname.includes('/discover/')).length,1);assert.equal(calls.length,21);assert.equal(first.source_total_delta,20);assert.equal(first.source_remaining_delta,18);assert.equal(first.eligible_mark_ids.length,2);const next=new URL(base);let cursor=first.next_count_cursor,total=20,remaining=18;while(cursor){next.searchParams.set('count_cursor',cursor);const d=await(await sourceCountBatch(new Request(next),env,ctx)).json();total+=d.source_total_delta;remaining+=d.source_remaining_delta;cursor=d.next_count_cursor}assert.equal(total,225);assert.equal(remaining,222);next.searchParams.set('providers','9');assert.equal((await sourceCountBatch(new Request(next),env,ctx)).status,400)}finally{globalThis.fetch=original}
});

test('unsupported metadata filters retain their existing verification path',async()=>{
 const result=await sourceCountBatch(new Request(base+'&country=TR&country_mode=exclusive'),{},{});assert.equal(result,null);
});
test('source page limit is reported rather than a false remaining count',async()=>{
 const original=globalThis.fetch;globalThis.fetch=async()=>Response.json({total_pages:501,total_results:10001,results:[]});
 try{const r=await sourceCountBatch(new Request(base.replace('dated=1','dated=0')),{TMDB_API_KEY:'test'},{});assert.equal(r.status,503);assert.equal((await r.json()).error,'source_count_limit')}finally{globalThis.fetch=original}
});
