import {test} from 'node:test';
import assert from 'node:assert/strict';
import {refresh,offers} from '../src/maintenance.mjs';
test('TR platform access types merge without duplicate providers',()=>{
 const result=offers({'watch/providers':{results:{TR:{flatrate:[{provider_id:8,provider_name:'Netflix'}],buy:[{provider_id:8,provider_name:'Netflix'}]},US:{flatrate:[{provider_id:9,provider_name:'US only'}]}}}},123);
 assert.equal(result.region,'TR');assert.equal(result.offers.length,1);assert.deepEqual(result.offers[0].types,['flatrate','buy']);assert.equal(result.checked_at,123);
});
test('scheduled refresh fetches a bounded batch and records success without touching marks',async()=>{
 const oldFetch=globalThis.fetch,queries=[],urls=[];
 const detail={id:123,title:'Test',original_title:'Test',genres:[],popularity:1,'watch/providers':{results:{TR:{flatrate:[{provider_id:8,provider_name:'Netflix'}]}}}};
 globalThis.fetch=async url=>{urls.push(String(url));return Response.json(String(url).includes('/discover/')?{results:Array.from({length:20},()=>({id:123}))}:detail)};
 const db={prepare(sql){queries.push(sql);return {bind(){return this},async first(){return null},async run(){return {success:true}}}},async batch(statements){return statements.map(()=>({success:true}))}};
 try{const state=await refresh({DB:db,TMDB_API_KEY:'test-only'},1793462400000);assert.equal(state.status,'ok');assert.equal(urls.length,2);assert.ok(queries.some(x=>/maintenance_state/.test(x)));assert.ok(!queries.some(x=>/\bmarks\b|personal_ratings/.test(x)));}finally{globalThis.fetch=oldFetch}
});
test('missing upstream key records an explicit error without leaking secrets',async()=>{
 let saved;
 const db={prepare(){return{bind(id,data){saved=JSON.parse(data);return this},async run(){}}}};
 await assert.rejects(refresh({DB:db}),/tmdb_key_missing/);assert.equal(saved.error,'tmdb_key_missing');
});
