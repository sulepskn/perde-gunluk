import {test} from 'node:test';
import assert from 'node:assert/strict';
import {runtimeValue,runtimeMatches,runtimeDiscover} from '../src/runtime.mjs';
import {sourceCountBatch} from '../src/source-count.mjs';
test('unknown durations never become zero-minute matches; TV durations are excluded',()=>{
 assert.equal(runtimeMatches({},0,30),false);assert.equal(runtimeMatches({runtime:0},0,30),false);
 assert.equal(runtimeMatches({runtime:95},0,30),false);assert.equal(runtimeMatches({runtime:7},0,30),true);
 assert.equal(runtimeMatches({episode_run_time:[26]},0,30),false);assert.equal(runtimeValue({episode_run_time:[]}),null);
});
test('duration discovery verifies details and retains unprocessed candidates in its cursor',async()=>{
 const original=globalThis.fetch;
 const rows=[1,2,3,4,5].map(id=>({id,title:'Fixture',release_date:'2000-01-01'}));
 globalThis.fetch=async target=>{const u=new URL(target);if(u.pathname.includes('/discover/'))return Response.json({page:1,total_pages:1,total_results:5,results:rows});const id=Number(u.pathname.split('/').at(-1));return Response.json({id,runtime:id===1?95:7,genres:[],release_date:'2000-01-01'})};
 const env={TMDB_API_KEY:'test',DB:{prepare(){return{bind(){return this},async all(){return{results:[]}}}}}},ctx={waitUntil(){}};
 const url=new URL('https://test.invalid/api/catalog?path=discover/movie&with_runtime.lte=30&sort_by=primary_release_date.asc');
 try{
   const first=await(await runtimeDiscover(new Request(url),env,ctx)).json();assert.deepEqual(first.results.map(x=>x.id),[2,3,4]);assert.ok(first.perde_has_more);assert.equal(JSON.parse(first.perde_cursor).offset,4);
   url.searchParams.set('perde_cursor',first.perde_cursor);const second=await(await runtimeDiscover(new Request(url),env,ctx)).json();assert.deepEqual(second.results.map(x=>x.id),[5]);assert.equal(second.perde_has_more,false);
   const count=await(await sourceCountBatch(new Request('https://test.invalid/api/catalog-index?type=movie&runtime_min=0&runtime_max=30'),env,ctx)).json();assert.equal(count.source_total_delta,4);assert.equal(count.source_remaining_delta,4);assert.equal(count.runtime_verified,true);
 }finally{globalThis.fetch=original}
});
