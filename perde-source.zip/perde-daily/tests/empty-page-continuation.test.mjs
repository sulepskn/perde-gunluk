import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import vm from 'node:vm';

const app = await fs.readFile(new URL('../public/perde-app.js', import.meta.url), 'utf8');

test('shipped discovery follows its source cursor after an empty filtered page', async () => {
  const start = app.indexOf('const arrays=await Promise.all(types.map');
  const end = app.indexOf('\n  if(n!==request)', start);
  assert.ok(start >= 0 && end > start);
  const responses = [
    {page: 1, total_pages: 1, total_results: 0, count_pending: true, results: [], perde_cursor: 'next', perde_has_more: true},
    {page: 2, total_pages: 1, total_results: 0, count_pending: true, results: [{id: 7}], perde_cursor: null, perde_has_more: false}
  ];
  const received = [];
  const context = vm.createContext({types: ['tv'], f: {}, nextPages: {tv: 1}, perdeSourceCursors: {tv: null},
    window: {PerdeFeatures: {duration: () => ({})}}, signal: undefined,
    $: () => ({checked: false}), filtersApi: {params: () => ({})}, normalize: row => row,
    api: async (path, params) => {received.push(params); return responses.shift();}});
  const run = () => vm.runInContext('(async()=>{' + app.slice(start, end) + ';return arrays})()', context);
  const first = await run();
  assert.equal(first[0].more, true);
  assert.equal(first[0].countPending, true);
  assert.equal(first[0].capped, false);
  assert.equal(context.perdeSourceCursors.tv, 'next');
  context.nextPages.tv = 2;
  const second = await run();
  assert.equal(received[1].perde_cursor, 'next');
  assert.equal(second[0].more, false);
  assert.equal(second[0].rows[0].id, 7);
});

test('full catalogue continues empty pages and cancels continuation after a filter change', async () => {
  const start = app.indexOf('async function refreshFull(');
  const end = app.indexOf('\nlet modalTitleId=', start);
  assert.ok(start >= 0 && end > start);
  const nodes = {};
  const $ = id => nodes[id] ||= {value: '', checked: false, hidden: false, textContent: '', innerHTML: ''};
  $('#sort').value = 'popular';
  const timers = [], calls = [];
  const context = vm.createContext({$, AbortController, URLSearchParams, Set, Map,
    catalogBusy: false, hasMore: false, catalogError: false, fullAbort: null, request: 0,
    indexCursor: null, detailGeneration: 1, countRequestGeneration: 1, countAbort: null,
    archiveCountsCompleteGeneration: -1, items: [], fastCapped: false, watched: {}, hiddenItems: {},
    window: {PerdeFeatures: {duration: () => ({}), pageReceived() {}}},
    platforms: {active: () => true, selection: () => ({providers: '8'})},
    filtersApi: {idsFor: () => []}, effectiveType: () => '', render() {},
    scrollPager: {poke() {}}, setTimeout: fn => {timers.push(fn); return timers.length;},
    refresh: append => calls.push(append),
    responseCache: {read: async () => Response.json({results: [], next_cursor: 'more',
      source: 'fast_filtered_discovery', count_pending: true, filtered: true})}});
  vm.runInContext(app.slice(start, end), context);
  await vm.runInContext('refreshFull()', context);
  assert.equal(context.catalogError, false);
  assert.equal(context.hasMore, true);
  assert.equal(timers.length, 1);
  assert.match($('#grid').innerHTML, /aranıyor/);
  timers[0]();
  assert.deepEqual(calls, [true]);
  context.request++;
  timers[0]();
  assert.deepEqual(calls, [true]);
});
