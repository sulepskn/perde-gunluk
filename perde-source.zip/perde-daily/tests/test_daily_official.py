import datetime as dt
import json
import pathlib
import sys
import unittest
from unittest.mock import patch

sys.path.insert(0, str(pathlib.Path(__file__).parents[1] / 'scripts'))
from official_catalogue import entries, parse_listing, refresh_official


class OfficialListingTests(unittest.TestCase):
    def document(self, start='2026-01-01T00:00:00Z', end='2027-01-01T00:00:00Z'):
        entry = entries()[0]
        feature = entry['source_url'].rsplit('/', 1)[1]
        geo = {'pageLocales': {'urlCountry': 'tr', 'windows': {'tr/tr': [start, end]}}}
        page = {'props': {'pageProps': {'mappedData': {'title': {
            'featureId': feature, 'title': {'full': entry['title']},
            'runtime': '23m', 'releaseDate': '2025-07-20', 'summary': {'short': 'Test'}
        }}}}}
        return '<script id="__DOTCOM_GEO__">' + json.dumps(geo) + '</script><script id="__NEXT_DATA__">' + json.dumps(page) + '</script>'

    def test_only_current_turkey_window_grants_official_offer(self):
        now = dt.datetime(2026, 11, 25, tzinfo=dt.timezone.utc)
        active = parse_listing(self.document(), entries()[0], now)
        self.assertEqual(active['watch_availability']['offers'][0]['id'], 1899)
        self.assertEqual(active['runtime'], 23)
        expired = parse_listing(self.document(end='2026-11-25T00:00:00Z'), entries()[0], now)
        self.assertEqual(expired['watch_availability']['offers'], [])

    def test_failed_or_wrong_country_response_cannot_publish_as_verified(self):
        now = dt.datetime(2026, 11, 25, tzinfo=dt.timezone.utc)
        for document in ['temporary failure', self.document().replace('"tr"', '"us"')]:
            with self.assertRaises((ValueError, KeyError)):
                parse_listing(document, entries()[0], now)

    def test_missing_upstream_genres_are_filled_and_expiry_removes_only_hbo(self):
        entry = entries()[0]
        records = {entry['item_id']: {'detail': {'genre_ids': [], 'vote_count': 12},
                   'availability': {'offers': [{'id': 8, 'name': 'Netflix', 'types': ['flatrate']}]}}}
        with patch('official_catalogue.entries', return_value=[entry]):
            refresh_official(records, lambda url: self.document(), dt.datetime(2026, 11, 25, tzinfo=dt.timezone.utc))
            self.assertEqual(records[entry['item_id']]['detail']['genre_ids'], [16, 35])
            self.assertEqual(records[entry['item_id']]['detail']['vote_count'], 12)
            refresh_official(records, lambda url: self.document(), dt.datetime(2027, 1, 1, tzinfo=dt.timezone.utc))
        self.assertEqual([offer['id'] for offer in records[entry['item_id']]['availability']['offers']], [8])


if __name__ == '__main__':
    unittest.main()
