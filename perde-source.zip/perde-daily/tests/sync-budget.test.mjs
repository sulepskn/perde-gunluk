import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs/promises';import vm from 'node:vm';
const source=await fs.readFile(new URL('../public/app.js',import.meta.url),'utf8');
function declaration(name){const start=source.indexOf('function '+name+'(');assert.ok(start>=0);const body=source.indexOf('{',start);let depth=0,quote='',escaped=false;for(let i=body;i<source.length;i++){const c=source[i];if(quote){if(escaped)escaped=false;else if(c==='\\')escaped=true;else if(c===quote)quote='';continue}if(c==='"'||c==="'"||c==='`'){quote=c;continue}if(c==='{')depth++;if(c==='}'&&--depth===0)return (source.slice(start-6,start)==='async '?'async ':'')+source.slice(start,i+1);}throw Error('Unclosed '+name)}
function fixture(){const values=new Map(),timers=new Map(),calls=[];let timerId=0;const ctx=vm.createContext({watched:{},hiddenItems:{},wishlist:{},baseline:{watched:{},hidden:{},wishlist:{}},pendingOps:[],syncReady:true,syncBusy:false,syncUser:{id:'test-user'},syncTimer:null,libraryStatsRequest:0,structuredClone,window:{},responseCache:{clear(){}},perdeUpdateCountsAfterMarks(){},syncMessage(){},loadLibraryStats(){},localStorage:{getItem:k=>values.get(k)||null,setItem:(k,v)=>values.set(k,v),removeItem:k=>values.delete(k)},setTimeout:fn=>{timers.set(++timerId,fn);return timerId},clearTimeout:id=>timers.delete(id),checkedFetch:async(url,options)=>{calls.push(JSON.parse(options.body));return{ok:true}}});
 for(const name of ['cache','scheduleSync','flushSync','save'])vm.runInContext(declaration(name),ctx);
 return{ctx,values,timers,calls,mark(id){ctx.watched[id]={id};vm.runInContext('save()',ctx)}};
}

test('rapid personal actions are persisted locally before being sent in bounded batches',async()=>{
 const f=fixture();for(let i=0;i<120;i++)f.mark('movie-'+i);
 assert.equal(f.calls.length,0);assert.equal(f.timers.size,1);
 assert.equal(JSON.parse(f.values.get('perde-account-test-user')).pending.length,120);
 await vm.runInContext('flushSync()',f.ctx);
 assert.deepEqual(f.calls.map(x=>x.ops.length),[100,20]);assert.equal(f.timers.size,0);
 assert.equal(JSON.parse(f.values.get('perde-account-test-user')).pending.length,0);
});

test('a failed upload keeps the durable local queue for retry',async()=>{
 const f=fixture();f.ctx.checkedFetch=async()=>{throw Error('offline')};f.mark('tv-1');
 await vm.runInContext('flushSync()',f.ctx);
 assert.equal(f.ctx.pendingOps.length,1);assert.equal(JSON.parse(f.values.get('perde-account-test-user')).pending[0].item.id,'tv-1');
});

test('large full-archive caches are replaced only after the pending queue was stored',()=>{
 const f=fixture();f.values.set('perde-account-test-user','legacy full cache');f.mark('movie-1');
 assert.ok(!f.values.get('perde-account-test-user').includes('legacy full cache'));
 assert.deepEqual(Object.keys(JSON.parse(f.values.get('perde-account-test-user'))),['pending']);
 assert.equal(JSON.parse(f.values.get('perde-account-test-user')).pending.length,1);
});

test('storage exhaustion sends immediately instead of delaying an unpersisted operation',async()=>{
 const f=fixture();f.ctx.localStorage.setItem=()=>{throw Error('quota')};f.mark('movie-1');
 await new Promise(resolve=>setImmediate(resolve));assert.equal(f.calls.length,1);assert.equal(f.timers.size,0);
});

test('unchanged preferences are not resent and a failed preference write remains retryable',async()=>{
 let body={sort:'old'},calls=0;const ctx=vm.createContext({syncReady:true,preferencesLoaded:true,preferencesSaving:false,lastSavedPreferences:null,accountPreferences:()=>body,queueMicrotask,syncMessage(){},fetch:async()=>{calls++;return{ok:true}}});
 vm.runInContext(declaration('uploadPreferences'),ctx);await vm.runInContext('uploadPreferences()',ctx);await vm.runInContext('uploadPreferences()',ctx);assert.equal(calls,1);
 body={sort:'new'};ctx.fetch=async()=>{calls++;return{ok:false}};await vm.runInContext('uploadPreferences()',ctx);assert.equal(ctx.lastSavedPreferences,'{"sort":"old"}');
 ctx.fetch=async()=>{calls++;return{ok:true}};await vm.runInContext('uploadPreferences()',ctx);assert.equal(ctx.lastSavedPreferences,'{"sort":"new"}');assert.equal(calls,3);
});
