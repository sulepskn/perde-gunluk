import {test} from 'node:test';
import assert from 'node:assert/strict';
import {runtimeInfo,runtimeMatches} from '../src/runtime.mjs';
import {correctAvailability,filterCorrectedIds} from '../src/corrections.mjs';
test('legacy TV minutes cannot become a film duration or duration match',()=>{
 const d={type:'tv',episode_run_time:[7],perde_runtime_range:{min:26,max:28,scope:'latest_season'}};assert.equal(runtimeInfo(d),null);assert.equal(runtimeMatches(d,0,30),false);
});
test('household correction blocks a false provider without changing other offers',()=>{
 const d=correctAvailability('tv-1',{offers:[{id:8},{id:119}]},[{item_id:'tv-1',provider_id:8,blocked:1,note:'Reported',updated_at:1}]);assert.deepEqual(d.offers,[{id:119}]);assert.equal(d.verification,'upstream_report_only');assert.equal(d.corrections[0].source,'household_report');
});
test('the same correction changes provider-filter membership and can be restored',async()=>{
 const old=globalThis.fetch;globalThis.fetch=async()=>Response.json({results:{TR:{flatrate:[{provider_id:8}]}}});let blocked=1;
 const env={TMDB_API_KEY:'test',DB:{prepare(){return{bind(){return this},async run(){},async all(){return{results:[{item_id:'tv-1',provider_id:8,blocked,note:'Report',updated_at:1}]}}}}}};
 try{assert.deepEqual(await filterCorrectedIds(env,['tv-1'],new URLSearchParams({providers:'8'})),[]);blocked=0;assert.deepEqual(await filterCorrectedIds(env,['tv-1'],new URLSearchParams({providers:'8'})),['tv-1'])}finally{globalThis.fetch=old}
});
