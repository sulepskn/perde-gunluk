import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import vm from 'node:vm';

// Exercise the shipped builders, rather than a second implementation of their policy.
async function fixture() {
 const features=await fs.readFile(new URL('../public/features.js',import.meta.url),'utf8');
 const app=await fs.readFile(new URL('../public/perde-app.js',import.meta.url),'utf8');
 const nodes={};
 for(const id of ['type','genre','country','year','originalLanguage','countryMode','minVotes','sort','search','hide','adult','deepScan','durationEnabled','durationMin','durationMax'])nodes['#'+id]={value:'',checked:false};
 nodes['#durationMin'].value='0';nodes['#durationMax'].value='30';nodes['#durationEnabled'].checked=true;
 const context=vm.createContext({window:{},$:s=>nodes[s],URLSearchParams,filtersApi:{idsFor:()=>[]},platforms:{selection:()=>({providers:'8|119|337',watch_access:'stream'}),active:()=>true}});
 vm.runInContext(features.split('\n').find(x=>x.includes('function duration()')),context);
 vm.runInContext('window.PerdeFeatures={duration};'+app.split('\n').find(x=>x.startsWith('function effectiveType()')),context);
 vm.runInContext(app.split('\n').find(x=>x.startsWith('function perdeMembershipParams(')),context);
 const full=app.slice(app.indexOf('async function refreshFull('));
 const start=full.indexOf('const p=new URLSearchParams('),end=full.indexOf(';if(indexCursor)',start);
 return{nodes,context,counts:()=>vm.runInContext("perdeMembershipParams({adult:false,sort:'popular'})",context),cards:()=>vm.runInContext('(()=>{'+full.slice(start,end)+';return p})()',context)};
}

test('Hepsi remains both types even when film duration values are retained',async()=>{
 const f=await fixture();f.nodes['#type'].value='';
 assert.deepEqual(Array.from(vm.runInContext('selectedTypes()',f.context)),['movie','tv']);
 for(const p of [f.counts(),f.cards()]){assert.equal(p.get('type'),'');assert.equal(p.get('runtime_min'),'');assert.equal(p.get('runtime_max'),'');}
});

test('Film applies its duration to both cards and membership; Dizi ignores it',async()=>{
 const f=await fixture();
 for(const type of ['movie','tv']){f.nodes['#type'].value=type;for(const p of [f.counts(),f.cards()]){assert.equal(p.get('type'),type);assert.equal(p.get('runtime_max'),type==='movie'?'30':'');}}
});

test('switching Film, Hepsi, Dizi and back does not leak the film query into another type',async()=>{
 const f=await fixture();for(const type of ['movie','','tv','','movie']){f.nodes['#type'].value=type;const a=f.counts(),b=f.cards();for(const k of ['type','runtime_min','runtime_max','providers','watch_access'])assert.equal(a.get(k),b.get(k));assert.equal(a.get('type'),type);}
 f.nodes['#durationEnabled'].checked=false;assert.equal(f.cards().get('runtime_max'),'');
});

test('paginated membership and its cache remain separate for Hepsi, Film and Dizi',async()=>{
 const f=await fixture();let calls=0;
 Object.assign(f.context,{AbortController,AbortSignal,Date,setTimeout:()=>0,fetch:async url=>{
  calls++;const p=new URL('https://test.invalid'+url).searchParams,type=p.get('type');
  return Response.json(type==='movie'?{source_ids:['movie-1'],next_count_cursor:null}:type==='tv'?{source_ids:['tv-2'],next_count_cursor:null}:p.has('count_cursor')?{source_ids:['tv-2'],next_count_cursor:null}:{source_ids:['movie-1'],next_count_cursor:'page-2'});
 }});
 f.context.window.addEventListener=()=>{};
 vm.runInContext(await fs.readFile(new URL('../public/filter-membership.js',import.meta.url),'utf8'),f.context);
 const m=f.context.window.PerdeMembership;
 for(const type of ['','movie','tv','']){f.nodes['#type'].value=type;const p=f.counts();await m.ensure(p);assert.deepEqual([...m.get(p).ids],type==='movie'?['movie-1']:type==='tv'?['tv-2']:['movie-1','tv-2']);}
 assert.equal(calls,4,'returning to Hepsi reuses its complete two-page count');
});
