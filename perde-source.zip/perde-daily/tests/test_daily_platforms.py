import importlib.util,pathlib,tempfile,unittest,json
spec=importlib.util.spec_from_file_location('platforms',pathlib.Path(__file__).parents[1]/'scripts'/'daily_platforms.py');p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
class DailyPlatforms(unittest.TestCase):
 def test_region_and_access_types(self):
  raw={'watch/providers':{'results':{'US':{'flatrate':[{'provider_id':8,'provider_name':'Netflix'}]},'TR':{'rent':[{'provider_id':2,'provider_name':'Apple'}],'buy':[{'provider_id':2,'provider_name':'Apple'}]}}}}
  a=p.availability(raw,100);self.assertEqual(a['offers'],[{'id':2,'name':'Apple','logo':None,'types':['rent','buy']}])
 def test_provider_entry_removal_and_first_baseline(self):
  self.assertTrue(p.changes(None,{'movie-1':{'8':['flatrate']}})['baseline'])
  delta=p.changes({'movie-1':{'8':['flatrate']}},{'movie-1':{'2':['rent']}});self.assertEqual((delta['entered'],delta['left']),(1,1));self.assertEqual(delta['events'][0]['removed_providers'],[8])
 def test_dated_discovery_partitions_beyond_source_page_limit(self):
  class Client:
   def get(self,path,q):
    if 'primary_release_date.gte' not in q:return {'total_pages':501,'results':[{'id':1}]}
    if q['primary_release_date.gte']=='1800-01-01' and q['primary_release_date.lte']=='2099-12-31':return {'total_pages':501,'results':[]}
    return {'total_pages':1,'results':[{'id':2 if q['primary_release_date.gte']=='1800-01-01' else 3}]}
  self.assertEqual(p.discover(Client(),'movie',{}),{'movie-1','movie-2','movie-3'})
 def test_public_buckets_and_manifest_preserve_ids(self):
  root=pathlib.Path(__file__).parents[1]/'work'/'test-temp';root.mkdir(parents=True,exist_ok=True)
  with tempfile.TemporaryDirectory(dir=root) as d:
   rows={'movie-550':{'checked_at':1793491200000,'availability':{'offers':[]},'detail':{'id':550,'release_date':'1999-01-01'}}};out=pathlib.Path(d);m=p.build(rows,out,'2026-11-01',None,{},set(),'2026-11-01T00:00:00Z');self.assertEqual(m['count'],1);self.assertIn('movie-550',json.loads((out/'038.json').read_text()));self.assertFalse(m['personal_data_accessed'])
if __name__=='__main__':unittest.main()

