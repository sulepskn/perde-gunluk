import {test} from 'node:test';
import assert from 'node:assert/strict';
import {digest,issue,session,cookie,trusted,COOKIE} from '../src/auth.mjs';
import {householdDatabase,ARCHIVE} from '../src/database.mjs';
const account={id:'perde-owner',name:'Test',email:'test@example.invalid',keyHash:await digest('x'.repeat(43))};
const env={PERDE_SESSION_SECRET:'s'.repeat(64),PERDE_ACCOUNTS_JSON:JSON.stringify([account])};
const req=token=>new Request('https://test.invalid/',{headers:{Cookie:`${COOKIE}=${token}`}});
test('signed session persists across devices and expires after 180 days',async()=>{
  const now=Date.now(),token=await issue(account,env.PERDE_SESSION_SECRET,now);
  assert.equal((await session(req(token),env,now)).id,account.id);
  assert.equal((await session(req(token),env,now+179*86400000)).id,account.id);
  assert.equal(await session(req(token),env,now+181*86400000),null);
  assert.match(cookie(token),/Secure; HttpOnly; SameSite=Lax/);
});
test('tampering, secret rotation, account revocation and version rotation reject sessions',async()=>{
  const token=await issue(account,env.PERDE_SESSION_SECRET);
  assert.equal(await session(req(token+'x'),env),null);
  assert.equal(await session(req(token),{...env,PERDE_SESSION_SECRET:'t'.repeat(64)}),null);
  assert.equal(await session(req(token),{...env,PERDE_ACCOUNTS_JSON:JSON.stringify([{...account,id:'other'}])}),null);
  assert.equal(await session(req(token),{...env,PERDE_ACCOUNTS_JSON:JSON.stringify([{...account,version:2}])}),null);
});
test('client identity headers are replaced by the verified identity',()=>{
  const result=trusted(new Request('https://test.invalid',{headers:{'oai-authenticated-user-id':'attacker','x-perde-admin':'true'}}),account);
  assert.equal(result.headers.get('oai-authenticated-user-id'),account.id);
  assert.equal(result.headers.get('x-perde-admin'),null);
});
test('shared lists map both users to household while personal ratings stay personal',()=>{
  const calls=[];const db={prepare(sql){return {bind(...args){calls.push({sql,args});return this}}}};
  for(const id of ['perde-owner','perde-member']){
    const wrapped=householdDatabase(db,id);
    wrapped.prepare('SELECT * FROM marks WHERE user_id=?').bind(id);
    wrapped.prepare('SELECT * FROM personal_ratings WHERE user_id=?').bind(id);
  }
  assert.deepEqual(calls.map(x=>x.args[0]),[ARCHIVE,'perde-owner',ARCHIVE,'perde-member']);
});
