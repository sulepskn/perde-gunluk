import gzip,importlib.util,json,pathlib,struct,tempfile,unittest
spec=importlib.util.spec_from_file_location('daily_catalog',pathlib.Path(__file__).parents[1]/'scripts/daily_catalog.py');daily=importlib.util.module_from_spec(spec);spec.loader.exec_module(daily)
TEMP_ROOT=pathlib.Path(__file__).parents[1]/'work/test-temp'
TEMP_ROOT.mkdir(parents=True,exist_ok=True)
class PublicSnapshotTests(unittest.TestCase):
    def test_catalogue_membership_sorting_and_adult_flags(self):
        with tempfile.TemporaryDirectory(dir=TEMP_ROOT) as temp:
            root=pathlib.Path(temp);assert root.resolve().is_relative_to(TEMP_ROOT.resolve());source=root/'movie.gz'
            with gzip.open(source,'wt',encoding='utf-8') as f:
                for x in [{'id':1,'original_title':'Zulu','popularity':2},{'id':2,'original_title':'Alpha','popularity':5,'adult':True}]:f.write(json.dumps(x)+'\n')
            manifest=daily.build_catalogue([('movie',False,source)],root/'catalogue','2026-11-01',minimum=1)
            self.assertEqual(manifest['total'],2);bits=(root/'catalogue/movie-membership.bin').read_bytes();self.assertEqual((bits[0]>>2)&3,1);self.assertEqual((bits[0]>>4)&3,2)
            self.assertEqual(json.loads((root/'catalogue/title-0000.json').read_text())[0][2],'Alpha')
            self.assertEqual(json.loads((root/'catalogue/popular-0000.json').read_text())[0][1],2)
    def test_imdb_binary_format_and_partial_download_guard(self):
        with tempfile.TemporaryDirectory(dir=TEMP_ROOT) as temp:
            root=pathlib.Path(temp);assert root.resolve().is_relative_to(TEMP_ROOT.resolve());source=root/'ratings.gz'
            with gzip.open(source,'wt',encoding='utf-8') as f:f.write('tconst\taverageRating\tnumVotes\ntt0000257\t8.2\t123\ntt0000001\t7.0\t50\n')
            manifest=daily.build_imdb(source,root/'imdb','2026-11-01',minimum=1)
            self.assertEqual(manifest['count'],2);self.assertEqual(list(struct.iter_unpack('<IBI',(root/'imdb/001.bin').read_bytes())),[(1,70,50),(257,82,123)])
            with self.assertRaises(ValueError):daily.build_imdb(source,root/'refused','2026-11-01')
if __name__=='__main__':unittest.main()
