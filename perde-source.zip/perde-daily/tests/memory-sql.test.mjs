import test from 'node:test';import assert from 'node:assert/strict';import{readFile}from'node:fs/promises';import{gzipSync}from'node:zlib';import vm from'node:vm';
import initSQL from '../vendor/sqlite-runtime.cjs';import{memoryDatabase}from'../src/memory-sql.mjs';
const wasm=new WebAssembly.Module(await readFile(new URL('../vendor/sqlite-runtime.wasm',import.meta.url))),SQL=await initSQL({instantiateWasm(imports,receive){const instance=new WebAssembly.Instance(wasm,imports);receive(instance);return instance.exports}});
const source=await readFile(new URL('../src/archive-store.mjs',import.meta.url),'utf8'),schema=vm.runInNewContext('(()=>{'+source.slice(source.indexOf('const SCHEMA='),source.indexOf('const IMPORT='))+';return SCHEMA})()');
function fixture(){const db=new SQL.Database();db.run(schema.join(';'));const initial=Buffer.from(gzipSync(db.export())).toString('base64');db.close();const values=new Map([['archive.sqlite.b64gz',initial]]),metadata=new Map([['archive.sqlite.b64gz',{checkpointAt:Date.now()}]]);const ns={values,metadata,hidden:new Set(),reads:0,lists:0,failWrites:false,async get(k){this.reads++;return values.get(k)||null},async getWithMetadata(k){this.reads++;return{value:values.get(k),metadata:metadata.get(k)}},async list(){this.lists++;return{keys:[...values.keys()].filter(k=>k.startsWith('journal/')&&!this.hidden.has(k)).sort().map(name=>({name,metadata:metadata.get(name)})),list_complete:true}},async put(k,v,options={}){if(this.failWrites)throw Error('storage unavailable');values.set(k,v);metadata.set(k,options.metadata)},async delete(k){values.delete(k);metadata.delete(k)}};return{ns,open:()=>memoryDatabase(ns,initSQL,wasm)}}
const upsert="INSERT INTO marks VALUES(?,?,?,?,?,?) ON CONFLICT(user_id,kind,item_id) DO UPDATE SET data=excluded.data,active=excluded.active,updated_at=excluded.updated_at";
const params=(id,at,title=id)=>['perde-household','watched',id,JSON.stringify({id,title}),1,at];
test('warm archive reads do not reread storage and uncheckpointed writes survive reopening',async()=>{const f=fixture(),a=f.open();await a.ready;const reads=f.ns.reads;for(let i=0;i<20;i++)await a.prepare('SELECT COUNT(*) AS n FROM marks').all();assert.equal(f.ns.reads,reads);await a.prepare(upsert).bind(...params('movie-1',10)).all();assert.equal(a.stats.journalWrites,1);assert.equal(a.stats.snapshotWrites,0);const b=f.open();await b.ready;assert.equal((await b.prepare('SELECT COUNT(*) AS n FROM marks').first()).n,1);assert.equal(b.stats.journalReplayed,1)});
test('a missing older journal is recovered after a later stale checkpoint',async()=>{const f=fixture(),a=f.open();await a.ready;await a.prepare(upsert).bind(...params('movie-1',10)).all();const old=[...f.ns.values.keys()].find(x=>x.startsWith('journal/'));f.ns.hidden.add(old);f.ns.metadata.set('archive.sqlite.b64gz',{checkpointAt:0});const b=f.open();await b.ready;await b.prepare(upsert).bind(...params('movie-2',20)).all();assert.equal(b.stats.snapshotWrites,1);f.ns.hidden.clear();const c=f.open();await c.ready;assert.deepEqual((await c.prepare('SELECT item_id FROM marks ORDER BY item_id').all()).results.map(x=>x.item_id),['movie-1','movie-2'])});
test('late replay cannot overwrite a newer change to the same record',async()=>{const f=fixture(),a=f.open();await a.ready;await a.prepare(upsert).bind(...params('movie-1',10,'older')).all();const old=[...f.ns.values.keys()].find(x=>x.startsWith('journal/'));f.ns.hidden.add(old);f.ns.metadata.set('archive.sqlite.b64gz',{checkpointAt:0});const b=f.open();await b.ready;await b.prepare(upsert).bind(...params('movie-1',20,'newer')).all();f.ns.hidden.clear();const c=f.open();await c.ready;assert.equal(JSON.parse((await c.prepare('SELECT data FROM marks').first()).data).title,'newer')});
test('a failed durable journal rolls back the in-memory mutation',async()=>{const f=fixture(),a=f.open();await a.ready;f.ns.failWrites=true;await assert.rejects(a.prepare(upsert).bind(...params('movie-1',10)).all(),/storage unavailable/);assert.equal((await a.prepare('SELECT COUNT(*) AS n FROM marks').first()).n,0)});

test('one hundred identical preference uploads consume one durable write and still survive restart',async()=>{
 const f=fixture(),a=f.open();await a.ready;
 const sql='INSERT INTO user_preferences VALUES(?,?,?) ON CONFLICT(user_id) DO UPDATE SET data=excluded.data,updated_at=excluded.updated_at';
 for(let i=1;i<=100;i++)await a.prepare(sql).bind('perde-owner','{"sort":"old"}',i).run();
 assert.equal(a.stats.journalWrites,1);assert.equal(a.stats.snapshotWrites,0);
 const b=f.open();await b.ready;assert.equal((await b.prepare('SELECT data FROM user_preferences').first()).data,'{"sort":"old"}');
 await a.prepare(sql).bind('perde-owner','{"sort":"new"}',101).run();assert.equal(a.stats.journalWrites,2);
});

test('ignored stale mutations and empty deletes do not create KV journals',async()=>{
 const f=fixture(),a=f.open();await a.ready;await a.prepare(upsert).bind(...params('movie-1',20,'newer')).run();
 await a.prepare(upsert).bind(...params('movie-1',10,'older')).run();
 await a.prepare('DELETE FROM marks WHERE item_id=?').bind('missing').run();
 assert.equal(a.stats.journalWrites,1);assert.equal(JSON.parse((await a.prepare('SELECT data FROM marks').first()).data).title,'newer');
});

test('full checkpoints wait fifteen minutes while every accepted change remains recoverable',async()=>{
 const f=fixture();f.ns.metadata.set('archive.sqlite.b64gz',{checkpointAt:Date.now()-120000});
 const a=f.open();await a.ready;await a.prepare(upsert).bind(...params('movie-1',10)).run();
 assert.equal(a.stats.snapshotWrites,0);const b=f.open();await b.ready;assert.equal((await b.prepare('SELECT COUNT(*) AS n FROM marks').first()).n,1);
 const g=fixture();g.ns.metadata.set('archive.sqlite.b64gz',{checkpointAt:Date.now()-16*60000});const c=g.open();await c.ready;
 await c.prepare(upsert).bind(...params('movie-2',20)).run();assert.equal(c.stats.snapshotWrites,1);
});
