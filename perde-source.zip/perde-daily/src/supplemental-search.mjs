import {snapshotSearch} from './snapshot-search.mjs';
import {platformRecords} from './platform-snapshot.mjs';
import {filterCorrectedIds} from './corrections.mjs';
import {countryMatches} from './runtime.mjs';

function normalized(value){return value.toLowerCase().replaceAll('ı','i').normalize('NFKD').replace(/[\u0300-\u036f]/g,'').replace(/[^\p{L}\p{N}]+/gu,' ').trim();}

export async function supplementalSearch(request, env, run) {
  const p = new URL(request.url).searchParams;
  if (!/^search\/(movie|tv)$/.test(p.get('path') || '')) return null;
  const type = p.get('path').split('/')[1];
  const snapshot=await snapshotSearch(request,env);
  if(snapshot)return snapshot;
  // Upstream search has title coverage; the daily snapshot has our verified availability.
  const upstream = new URL(request.url);
  upstream.searchParams.delete('providers');
  upstream.searchParams.delete('with_watch_providers');
  const response = await run(new Request(upstream, request));
  if (!response.ok) return response;
  const data = await response.json();
  const query = normalized(p.get('query') || '');
  const prefix = (query.split(' ')[0] || '').slice(0,2);
  const hex = [...new TextEncoder().encode(prefix)].map(value=>value.toString(16).padStart(2,'0')).join('');
  const extraResponse = prefix ? await env.ASSETS.fetch(new Request('https://assets.invalid/catalogue/supplemental-search-'+hex+'.json')) : null;
  const extraDetails = extraResponse?.ok ? await extraResponse.json() : [];
  const extras = extraDetails.filter(row=>row.media_type===type&&[row.title,row.original_title].some(title=>normalized(title||'').includes(query)));
  const page=Number(p.get('page')||1);
  const selectedExtras=extras.slice((page-1)*20,page*20);
  const daily = await platformRecords(env, [...new Set([...selectedExtras.map(row=>type+'-'+row.id), ...(data.results || []).map(row => type + '-' + row.id)])]);
  const rows = new Map((data.results || []).map(row => [type + '-' + row.id, {...row,
    watch_availability: daily?.records[type + '-' + row.id]?.availability || row.watch_availability}]));
  for (const entry of selectedExtras) {
    const identifier=type+'-'+entry.id;
    const row = daily?.records[identifier]?.detail;
    if (!row || rows.has(identifier)) continue;
    if (row.adult && p.get('include_adult') !== 'true') continue;
    const year = p.get(type === 'movie' ? 'primary_release_year' : 'first_air_date_year');
    if (year && (row.release_date || row.first_air_date || '').slice(0, 4) !== year) continue;
    if (!countryMatches(row, p.get('with_origin_country'), p.get('country_mode'))) continue;
    if (p.get('with_original_language') && row.original_language !== p.get('with_original_language')) continue;
    rows.set(identifier, row);
  }
  const allowed = new Set(await filterCorrectedIds(env, [...rows.keys()], p));
  data.results = [...rows].filter(([id]) => allowed.has(id)).map(([, row]) => row);
  data.total_results = (data.total_results || 0) + extras.length;
  if (data.results.length) data.total_pages = Math.max(1, data.total_pages || 0,Math.ceil(extras.length/20));
  return Response.json(data, {headers: {'Cache-Control': 'private,no-store'}});
}
