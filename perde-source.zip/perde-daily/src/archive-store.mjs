import {DurableObject} from 'cloudflare:workers';
const SCHEMA=[
 "CREATE TABLE IF NOT EXISTS marks(user_id TEXT NOT NULL,kind TEXT NOT NULL,item_id TEXT NOT NULL,data TEXT NOT NULL,active INTEGER NOT NULL DEFAULT 1,updated_at INTEGER NOT NULL,PRIMARY KEY(user_id,kind,item_id)) WITHOUT ROWID",
 'CREATE INDEX IF NOT EXISTS marks_user_active_item ON marks(user_id,active,item_id,kind)',
 'CREATE INDEX IF NOT EXISTS marks_user_updated ON marks(user_id,updated_at)',
 'CREATE TABLE IF NOT EXISTS personal_ratings(user_id TEXT NOT NULL,item_id TEXT NOT NULL,rating INTEGER NOT NULL,data TEXT NOT NULL,updated_at INTEGER NOT NULL,PRIMARY KEY(user_id,item_id)) WITHOUT ROWID',
 'CREATE TABLE IF NOT EXISTS user_preferences(user_id TEXT PRIMARY KEY,data TEXT NOT NULL,updated_at INTEGER NOT NULL) WITHOUT ROWID',
 'CREATE TABLE IF NOT EXISTS account_bootstrap(user_id TEXT PRIMARY KEY,initialized_at INTEGER NOT NULL) WITHOUT ROWID',
 'CREATE TABLE IF NOT EXISTS catalog(media_type TEXT NOT NULL,tmdb_id INTEGER NOT NULL,original_title TEXT NOT NULL,search_title TEXT NOT NULL,popularity REAL NOT NULL DEFAULT 0,adult INTEGER NOT NULL DEFAULT 0,snapshot TEXT NOT NULL,detail TEXT,detail_at INTEGER,imdb_id TEXT,imdb_score REAL NOT NULL DEFAULT -1,PRIMARY KEY(media_type,tmdb_id)) WITHOUT ROWID',
 'CREATE TABLE IF NOT EXISTS catalog_snapshots(id TEXT PRIMARY KEY,data TEXT NOT NULL) WITHOUT ROWID',
 'CREATE TABLE IF NOT EXISTS imdb_ratings(imdb_id TEXT PRIMARY KEY,rating REAL NOT NULL,votes INTEGER NOT NULL,snapshot TEXT NOT NULL) WITHOUT ROWID',
 'CREATE TABLE IF NOT EXISTS watch_availability(media_type TEXT NOT NULL,tmdb_id INTEGER NOT NULL,region TEXT NOT NULL,data TEXT NOT NULL,checked_at INTEGER NOT NULL,PRIMARY KEY(media_type,tmdb_id,region)) WITHOUT ROWID',
 'CREATE INDEX IF NOT EXISTS watch_refresh ON watch_availability(region,checked_at)',
 'CREATE TABLE IF NOT EXISTS perde_metadata(media_type TEXT NOT NULL,tmdb_id INTEGER NOT NULL,detail TEXT NOT NULL,detail_at INTEGER NOT NULL,PRIMARY KEY(media_type,tmdb_id)) WITHOUT ROWID',
 'CREATE TABLE IF NOT EXISTS perde_imdb_links(media_type TEXT NOT NULL,tmdb_id INTEGER NOT NULL,imdb_id TEXT,checked_at INTEGER NOT NULL DEFAULT 0,PRIMARY KEY(media_type,tmdb_id)) WITHOUT ROWID',
 'CREATE TABLE IF NOT EXISTS maintenance_state(id TEXT PRIMARY KEY,data TEXT NOT NULL) WITHOUT ROWID',
 'CREATE TABLE IF NOT EXISTS platform_corrections(item_id TEXT NOT NULL,provider_id INTEGER NOT NULL,blocked INTEGER NOT NULL,note TEXT NOT NULL,updated_at INTEGER NOT NULL,PRIMARY KEY(item_id,provider_id)) WITHOUT ROWID'
];
const IMPORT={marks:['user_id','kind','item_id','data','active','updated_at'],personal_ratings:['user_id','item_id','rating','data','updated_at'],user_preferences:['user_id','data','updated_at'],platform_corrections:['item_id','provider_id','blocked','note','updated_at']};
export class ArchiveStore extends DurableObject{
 constructor(ctx,env){super(ctx,env);this.state=ctx;this.memo=new Map();this.memoBytes=0;for(const sql of SCHEMA)ctx.storage.sql.exec(sql)}
 execute(sql,params=[]){
   const cursor=this.state.storage.sql.exec(sql,...params),results=cursor.toArray();return{success:true,results,columns:cursor.columnNames,meta:{rows_read:cursor.rowsRead,rows_written:cursor.rowsWritten,changes:cursor.rowsWritten}};
 }
 *backup(user){
   yield '{"version":4,"exportedAt":'+JSON.stringify(new Date().toISOString());
   for(const kind of ['watched','hidden','wishlist']){yield ',"'+kind+'":{';let first=true;for(const row of this.state.storage.sql.exec('SELECT item_id,data FROM marks WHERE user_id=? AND kind=? AND active=1 ORDER BY item_id','perde-household',kind)){yield(first?'':',')+JSON.stringify(row.item_id)+':'+row.data;first=false}yield '}'}
   yield ',"personalRatings":[';let first=true;for(const row of this.state.storage.sql.exec('SELECT rating,data FROM personal_ratings WHERE user_id=? AND rating>0 ORDER BY item_id',user)){yield(first?'':',')+'{"rating":'+row.rating+',"item":'+row.data+'}';first=false}yield ']';
   const preferences=this.state.storage.sql.exec('SELECT data FROM user_preferences WHERE user_id=?',user).toArray()[0];yield ',"preferences":'+(preferences?.data||'{}')+'}';
 }
 invalidate(statements){
   const changed=['marks','personal_ratings','user_preferences','platform_corrections'].filter(table=>statements.some(s=>new RegExp('\\b'+table+'\\b','i').test(s.sql)&&!/^\s*(SELECT|EXPLAIN|PRAGMA)/i.test(s.sql)));
   for(const [key,value] of this.memo)if(changed.some(table=>value.tables.includes(table))){this.memoBytes-=value.body.length;this.memo.delete(key)}
 }
 async fetch(request){
   const url=new URL(request.url);
   try{
     if(url.pathname==='/backup'){
       const iterator=this.backup(url.searchParams.get('user')||'perde-owner'),encoder=new TextEncoder();return new Response(new ReadableStream({pull(controller){for(let i=0;i<20;i++){const next=iterator.next();if(next.done){controller.close();return}controller.enqueue(encoder.encode(next.value))}},cancel(){iterator.return()}}),{headers:{'Content-Type':'application/json','Cache-Control':'no-store','Content-Disposition':'attachment; filename="perde-tam-yedek.json"'}});
     }
     const body=await request.json();
     if(url.pathname==='/seed'){
       const columns=IMPORT[body.table];if(!columns||!Array.isArray(body.rows)||body.rows.length>100)return Response.json({error:'invalid_import'},{status:400});
       const sql='INSERT INTO '+body.table+'('+columns.join(',')+') VALUES('+columns.map(()=>'?').join(',')+') ON CONFLICT DO NOTHING';
       this.state.storage.transactionSync(()=>{for(const row of body.rows){if(columns.some(k=>!Object.hasOwn(row,k)))throw Error('missing_import_field');if(JSON.stringify(row).length>25000)throw Error('import_row_too_large');this.state.storage.sql.exec(sql,...columns.map(k=>row[k]))}});this.memo.clear();this.memoBytes=0;return Response.json({ok:true,imported:body.rows.length});
     }
     if(url.pathname==='/batch'){
       if(!Array.isArray(body.statements)||body.statements.length>200)throw Error('batch_limit');
       const results=this.state.storage.transactionSync(()=>body.statements.map(x=>this.execute(x.sql,x.params)));this.invalidate(body.statements);return Response.json(results);
     }
     if(url.pathname!=='/query'||typeof body.sql!=='string')throw Error('invalid_storage_request');
     const key=JSON.stringify([body.sql,body.params]),read=/^\s*(SELECT|EXPLAIN|PRAGMA)/i.test(body.sql),privateQuery=/\b(marks|personal_ratings|user_preferences|platform_corrections)\b/i.test(body.sql),cached=read&&privateQuery?this.memo.get(key):null;
     if(cached&&Date.now()-cached.at<cached.ttl)return new Response(cached.body,{headers:{'Content-Type':'application/json'}});
     const result=this.execute(body.sql,body.params),encoded=JSON.stringify(result);
     if(!read&&privateQuery)this.invalidate([{sql:body.sql}]);
     if(read&&privateQuery&&encoded.length<1500000){const previous=this.memo.get(key);if(previous)this.memoBytes-=previous.body.length;this.memo.delete(key);this.memo.set(key,{at:Date.now(),body:encoded,tables:['marks','personal_ratings','user_preferences','platform_corrections'].filter(t=>new RegExp('\\b'+t+'\\b','i').test(body.sql)),ttl:/\b(JOIN|catalog|perde_metadata|imdb_ratings|watch_availability)\b/i.test(body.sql)?60000:21600000});this.memoBytes+=encoded.length;while(this.memo.size>80||this.memoBytes>12_000_000){const oldest=this.memo.keys().next().value;this.memoBytes-=this.memo.get(oldest).body.length;this.memo.delete(oldest)}}
     return new Response(encoded,{headers:{'Content-Type':'application/json'}});
   }catch(e){return Response.json({error:String(e.message).slice(0,300)},{status:500})}
 }
}

