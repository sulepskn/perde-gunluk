export function splitWindow(window){
 const a=Date.parse(window.lo+'T00:00:00Z'),b=Date.parse(window.hi+'T00:00:00Z');
 if(!Number.isFinite(a)||!Number.isFinite(b)||a>=b)throw Error('source_day_limit');
 const mid=Math.floor((a+b)/2/86400000)*86400000;
 return[{...window,hi:new Date(mid).toISOString().slice(0,10),page:1},{...window,lo:new Date(mid+86400000).toISOString().slice(0,10),page:1}];
}
export async function windowedCount(p,types,load,finish){
 const signature=new URLSearchParams(p);signature.delete('count_cursor');signature.sort();const key=signature.toString();
 let queue=types.map(type=>({type,lo:(p.get('year')||'1800')+'-01-01',hi:(p.get('year')||'2099')+'-12-31',page:1}));
 if(p.get('count_cursor'))try{const c=JSON.parse(p.get('count_cursor'));if(c.windowed!==true||c.key!==key||!Array.isArray(c.queue)||c.queue.length>64||c.queue.some(w=>!types.includes(w.type)||!/^\d{4}-\d{2}-\d{2}$/.test(w.lo)||!/^\d{4}-\d{2}-\d{2}$/.test(w.hi)||!Number.isInteger(w.page)||w.page<1||w.page>500))throw Error();queue=c.queue}catch{return Response.json({error:'invalid_cursor'},{status:400})}
 let checked=0,budget=10;const ids=new Set();
 while(queue.length&&budget>0){
  const w=queue[0],first=await load(w.type,w.page,w);budget--;
  if(first.total_pages>500){queue.splice(0,1,...splitWindow(w));continue}
  const last=Math.min(first.total_pages,w.page+budget),pages=[first,...await Promise.all(Array.from({length:Math.max(0,last-w.page)},(_,i)=>load(w.type,w.page+i+1,w)))];budget-=pages.length-1;
  for(const page of pages)for(const row of page.results){checked++;const date=row[w.type==='movie'?'release_date':'first_air_date']||'';if(date>=w.lo&&date<=w.hi)ids.add(w.type+'-'+row.id)}
  w.page=last+1;if(w.page>first.total_pages)queue.shift();
 }
 return finish([...ids],checked,queue.length?JSON.stringify({windowed:true,key,queue}):null);
}
