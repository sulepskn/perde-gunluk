import {Buffer} from 'node:buffer';
const privateWrite=sql=>/^\s*(INSERT|UPDATE|DELETE|REPLACE)\b/i.test(sql)&&/\b(marks|personal_ratings|user_preferences|platform_corrections|account_bootstrap)\b/i.test(sql);
export function memoryDatabase(namespace,initSQL,wasm,onReplay=()=>{}){
 const stream=bytes=>new ReadableStream({start(controller){controller.enqueue(bytes);controller.close()}});
 let db,queue=Promise.resolve(),lastSave=0,journals=[],nextScan=Infinity,recheckUntil=0,scanning;const stats={snapshotLoads:0,snapshotWrites:0,journalWrites:0,journalReplayed:0,loadedRevision:'initial'};
 function guarded(sql){const table=/^\s*INSERT(?:\s+OR\s+\w+)?\s+INTO\s+(marks|personal_ratings|user_preferences|platform_corrections)\b/i.exec(sql)?.[1],update=sql.search(/DO UPDATE SET/i);return table&&update>=0&&!/\bWHERE\b/i.test(sql.slice(update))?sql+' WHERE excluded.updated_at>='+table+'.updated_at'+(table==='user_preferences'?' AND excluded.data<>user_preferences.data':''):sql}
 const ready=(async()=>{
  const entry=namespace.getWithMetadata?await namespace.getWithMetadata('archive.sqlite.b64gz',{type:'text',cacheTtl:30}):{value:await namespace.get('archive.sqlite.b64gz')},encoded=entry.value;if(!encoded)throw Error('Özel arşiv dosyası bulunamadı.');lastSave=entry.metadata?.checkpointAt||0;stats.loadedRevision=entry.metadata?.revision||'initial';
  const bytes=await new Response(stream(Buffer.from(encoded,'base64')).pipeThrough(new DecompressionStream('gzip'))).arrayBuffer();
  const SQL=await initSQL({instantiateWasm(imports,receive){const instance=new WebAssembly.Instance(wasm,imports);receive(instance);return instance.exports}});
  db=new SQL.Database(new Uint8Array(bytes));db.run('PRAGMA cache_size=-1024;CREATE INDEX IF NOT EXISTS marks_user_active_item ON marks(user_id,active,item_id,kind);CREATE INDEX IF NOT EXISTS marks_user_updated ON marks(user_id,updated_at);CREATE TABLE IF NOT EXISTS archive_applied_ops(id TEXT PRIMARY KEY,created_at INTEGER NOT NULL) WITHOUT ROWID;');stats.snapshotLoads++;
  recheckUntil=Date.now()+120000;await reconcile(true);
 })();
 async function reconcile(force=false){if(!namespace.list||!force&&Date.now()<nextScan)return;if(scanning)return scanning;
  scanning=(async()=>{journals=[];let cursor;do{const page=await namespace.list({prefix:'journal/',limit:1000,...(cursor?{cursor}:{})});journals.push(...page.keys);cursor=page.list_complete?null:page.cursor}while(cursor);
   const missing=journals.filter(k=>!run('SELECT id FROM archive_applied_ops WHERE id=?',[k.name]).results.length),ops=await Promise.all(missing.map(k=>namespace.get(k.name)));
   for(const [i,text]of ops.entries()){if(!text)continue;const op=JSON.parse(text);if(!Array.isArray(op.statements)||op.statements.some(s=>!privateWrite(s.sql)))throw Error('Invalid private operation journal');db.run('BEGIN');try{for(const s of op.statements)run(guarded(s.sql),s.params);run('INSERT OR IGNORE INTO archive_applied_ops VALUES(?,?)',[missing[i].name,op.at]);db.run('COMMIT');stats.journalReplayed++}catch(e){db.run('ROLLBACK');throw e}}
   if(missing.length)onReplay();nextScan=Date.now()<recheckUntil?Date.now()+60000:Infinity;
  })();try{await scanning}finally{scanning=null}
 }
 function run(sql,params=[]){const statement=db.prepare(sql);try{statement.bind(params);const results=[];while(statement.step())results.push(statement.getAsObject());return{success:true,results,columns:statement.getColumnNames(),meta:{rows_read:0,rows_written:0,changes:/^\s*(SELECT|EXPLAIN|PRAGMA)/i.test(sql)?0:db.getRowsModified(),virtual_rows_returned:results.length}}}finally{statement.free()}}
 async function journal(statements){
  const at=Date.now(),id='journal/'+String(at).padStart(13,'0')+'-'+crypto.randomUUID(),privateStatements=statements.filter(s=>privateWrite(s.sql));
  await namespace.put(id,JSON.stringify({at,statements:privateStatements}),{metadata:{at}});run('INSERT OR IGNORE INTO archive_applied_ops VALUES(?,?)',[id,at]);journals.push({name:id,metadata:{at}});stats.journalWrites++;return{at,id};
 }
 async function checkpoint({at,id}){
  if(at-lastSave<15*60000)return;
  const pause=1100-(Date.now()-lastSave);if(pause>0)await new Promise(resolve=>setTimeout(resolve,pause));
  // Public metadata is replaceable cache; keep the private snapshot bounded.
  for(const table of ['catalog','perde_metadata','watch_availability','perde_imdb_links']){const n=run('SELECT COUNT(*) AS n FROM '+table).results[0].n;if(n>512)db.run('DELETE FROM '+table)}
  db.run('PRAGMA wal_checkpoint;VACUUM;');const bytes=db.export();
  const compressed=await new Response(stream(bytes).pipeThrough(new CompressionStream('gzip'))).arrayBuffer();
  await namespace.put('archive.sqlite.b64gz',Buffer.from(compressed).toString('base64'),{metadata:{checkpointAt:at,revision:id}});lastSave=Date.now();stats.snapshotWrites++;
  if(namespace.delete){const old=journals.filter(k=>(k.metadata?.at||at)<at-86400000).slice(0,64);for(const k of old)if(run('SELECT id FROM archive_applied_ops WHERE id=?',[k.name]).results.length){try{await namespace.delete(k.name);journals=journals.filter(x=>x.name!==k.name)}catch{}}}
 }
 function mutate(statements){const task=queue.catch(()=>{}).then(async()=>{await ready;await reconcile();db.run('BEGIN');let results,committed;try{results=statements.map(s=>run(guarded(s.sql),s.params));const changed=statements.filter((s,i)=>privateWrite(s.sql)&&results[i].meta.changes>0);if(changed.length)committed=await journal(changed);db.run('COMMIT')}catch(e){db.run('ROLLBACK');throw e}if(committed)try{await checkpoint(committed)}catch(e){stats.checkpointError=String(e.message)}return results});queue=task;return task}
 function prepare(sql,params=[]){return{sql,params,bind(...values){return prepare(sql,values)},async all(){if(!/^\s*(SELECT|EXPLAIN|PRAGMA)/i.test(sql))return(await mutate([{sql,params}]))[0];await ready;await queue.catch(()=>{});await reconcile();return run(sql,params)},async run(){return this.all()},async first(column){const row=(await this.all()).results[0];return row?(column?row[column]:row):null},async raw(options){const r=await this.all(),rows=r.results.map(x=>r.columns.map(k=>x[k]));return options?.columnNames?[r.columns,...rows]:rows}}}
 return{prepare,batch:mutate,ready,stats};
}
