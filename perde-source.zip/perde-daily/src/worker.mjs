import application from '../vendor/application.mjs';
import {accounts,session,issue,cookie,trusted,loginPage,digest,COOKIE} from './auth.mjs';
import {householdDatabase,ARCHIVE} from './database.mjs';
import {refresh} from './maintenance.mjs';
import {platforms,detail} from './platforms.mjs';
import {sourceCountBatch} from './source-count.mjs';
import {runtimeDiscover} from './runtime.mjs';
import {correctionApi,filterCorrectedIds} from './corrections.mjs';
import {durableDatabase,archiveStub} from './store-adapter.mjs';
export {ArchiveStore} from './archive-store.mjs';
const json=(data,status=200)=>Response.json(data,{status,headers:{'Cache-Control':'private,no-store'}});
const redirect=location=>new Response(null,{status:303,headers:{Location:location,'Cache-Control':'no-store'}});
const ownerId='perde-owner';
const UI_BUILD='2026-11-02-archive-kv-v1';
async function backup(env,account) {
  if(['durable','d1','kv'].includes(env.PERDE_STORE)&&env.ARCHIVE_STORE)return archiveStub(env).fetch('https://archive.internal/backup?user='+encodeURIComponent(account.id));
  const [marks,ratings,preferences]=await Promise.all([
    env.DB.prepare('SELECT kind,item_id,data FROM marks WHERE user_id=? AND active=1').bind(ARCHIVE).all(),
    env.DB.prepare('SELECT data,rating FROM personal_ratings WHERE user_id=? AND rating>0').bind(account.id).all(),
    env.DB.prepare('SELECT data FROM user_preferences WHERE user_id=?').bind(account.id).first()
  ]);
  const lists={watched:{},hidden:{},wishlist:{}};
  for(const row of marks.results) if(lists[row.kind]) lists[row.kind][row.item_id]=JSON.parse(row.data);
  const response=json({version:4,exportedAt:new Date().toISOString(),...lists,personalRatings:ratings.results.map(x=>({rating:x.rating,item:JSON.parse(x.data)})),preferences:preferences?JSON.parse(preferences.data):{}});
  response.headers.set('Content-Disposition','attachment; filename="perde-tam-yedek.json"');
  return response;
}
const admin=`<!doctype html><html lang="tr"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>Perde · Yönetim</title><style>body{font:17px system-ui;background:#101511;color:#eef1e9;max-width:800px;margin:40px auto;padding:20px;line-height:1.7}a{color:#d7f28b}pre{white-space:pre-wrap;overflow-wrap:anywhere}button{padding:12px;font:inherit}</style><a href="/">← Arşive dön</a><h1>Perde yönetimi</h1><p>Bu site kendi Cloudflare hesabında çalışır. ChatGPT veya Sites aboneliği gerekmez.</p><p><a href="/api/backup">Tam yedeğimi indir</a> · <a href="/guncel">Güncel başlıklar</a> · <a href="/perde-logout">Bu cihazdan çıkış yap</a></p><h2>Bulut güncellemesi</h2><p>15 dakikada bir küçük bir başlık grubu yenilenir. Tam katalog 31 Ekim 2026 tarihli statik arşivdir; tamamı her gün yenilenmez. Platformlar Türkiye için TMDB/JustWatch verisine dayanır ve gecikebilir.</p><pre id="status">Kontrol ediliyor…</pre><button id="refresh">Şimdi bir güncelleme çalıştır</button><p id="result"></p><h2>Hesap yönetimi</h2><p>Cloudflare → Workers & Pages → perde-bagimsiz → Settings. Giriş hesapları PERDE_ACCOUNTS_JSON, imza sırrı PERDE_SESSION_SECRET, katalog anahtarı TMDB_API_KEY içinde Secret olarak tutulur. Bir hesabın version değerini artırmak o hesaptaki tüm cihazları çıkarır. Ortak listeler paylaşılır; puanlar ve tercihler kişiseldir.</p><script>const load=async()=>{const r=await fetch('/api/admin/status');document.getElementById('status').textContent=JSON.stringify(await r.json(),null,2)};load().catch(()=>document.getElementById('status').textContent='Durum alınamadı.');document.getElementById('refresh').onclick=async()=>{const e=document.getElementById('result');e.textContent='Çalışıyor…';try{const r=await fetch('/api/admin/refresh',{method:'POST'});e.textContent=r.ok?'Güncelleme tamamlandı.':'Güncelleme tamamlanamadı.';await load()}catch{e.textContent='Bağlantı kurulamadı.'}};</script></html>`;
const recentPage=`<!doctype html><html lang="tr"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>Perde · Güncel</title><style>body{font:17px system-ui;background:#101511;color:#eef1e9;padding:24px;max-width:1000px;margin:auto}a{color:#d7f28b}#items{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:20px}img{width:100%;border-radius:12px}article{overflow:hidden}p{line-height:1.6}</style><a href="/">← Arşive dön</a><h1>Bulutta yenilenen başlıklar</h1><p>Tüm katalogdaki son yenilenen kayıtlar. Ayrıntılar ve listeler için ana arşivde başlığı arayabilirsin.</p><div id="items"></div><script>fetch('/api/recent').then(r=>{if(!r.ok)throw Error();return r.json()}).then(d=>{const root=document.getElementById('items');if(!d.results.length)root.textContent='İlk bulut güncellemesi henüz tamamlanmadı.';for(const x of d.results){const el=document.createElement('article');if(x.poster_path){const img=document.createElement('img');img.src='https://image.tmdb.org/t/p/w342'+x.poster_path;img.alt='';img.loading='lazy';el.append(img)}const title=document.createElement('p');title.textContent=x.title||x.name;el.append(title);root.append(el)}}).catch(()=>document.getElementById('items').textContent='Güncel liste alınamadı.');</script></html>`;
const html=value=>new Response(value,{headers:{'Content-Type':'text/html; charset=utf-8','Cache-Control':'private,no-store'}});
async function dataStatus(env){const read=async path=>{try{const r=await env.ASSETS.fetch(new Request('https://assets.invalid/'+path));return r.ok?await r.json():null}catch{return null}};const [catalogue,imdb,daily,platforms]=await Promise.all(['catalogue/manifest.json','imdb/manifest.json','daily-status.json','platform-snapshots/manifest.json'].map(read));return{catalogue:catalogue?{snapshot:catalogue.snapshot,total:catalogue.total}:null,imdb:imdb?{snapshot:imdb.snapshot,count:imdb.count}:null,platforms:platforms?{snapshot:platforms.snapshot,count:platforms.count,currentlyAvailable:platforms.currently_available,changes:platforms.changes,checkedAt:platforms.built_at}:null,lastBuild:daily?.built_at||null,automationVerified:daily?.execution_origin==='github_actions'&&Boolean(platforms)&&daily?.platforms?.snapshot===platforms.snapshot}}

export default {
  async fetch(request,env,ctx) {
    const url=new URL(request.url), path=url.pathname;
    // Durations are film-only; normalize legacy clients before selecting a handler.
    if(request.method==='GET'){
      const p=url.searchParams,tv=p.get('type')==='tv'||p.get('path')==='discover/tv';
      if(tv){for(const key of ['runtime_min','runtime_max','with_runtime.gte','with_runtime.lte'])p.delete(key)}
      else if(['/api/catalog-index','/api/recommendations'].includes(path)&&(p.get('runtime_min')||p.get('runtime_max')))p.set('type','movie');
      if(url.href!==request.url)request=new Request(url,request);
    }
    // Only public catalogue assets bypass authentication. Personal exports never live in public/.
    if(path.startsWith('/catalogue/')||path.startsWith('/platform-snapshots/')||path.startsWith('/_next/')) return env.ASSETS.fetch(request);
    try { accounts(env); } catch { return json({error:'Giriş ayarları tamamlanmadı.'},503); }
    if(!['GET','HEAD'].includes(request.method) && request.headers.get('Origin')!==url.origin) return json({error:'origin'},403);
    if(['/perde-login','/signin-with-chatgpt'].includes(path)) {
      if(request.method==='GET') return await session(request,env)?redirect('/'):loginPage();
      if(request.method!=='POST') return json({error:'method'},405);
      if(Number(request.headers.get('Content-Length'))>8192) return json({error:'too_large'},413);
      const raw=await request.text(); if(raw.length>8192) return json({error:'too_large'},413);
      const token=(new URLSearchParams(raw).get('key')||'').replace(/[\s\u200B-\u200D\uFEFF]/g,'');
      if(token.length<32||token.length>256) return loginPage(true);
      const hash=await digest(token),account=accounts(env).find(x=>x.keyHash===hash);
      if(!account) return loginPage(true);
      const response=redirect('/');response.headers.set('Set-Cookie',cookie(await issue(account,env.PERDE_SESSION_SECRET)));return response;
    }
    const account=await session(request,env);
    if(!account) return path.startsWith('/api/')?json({error:'signin_required'},401):redirect('/perde-login');
    if(env.PERDE_MIGRATING==='true'&&request.method==='POST'&&['/api/marks','/api/personal-ratings','/api/preferences','/api/platform-corrections'].includes(path))return json({error:'Arşiv güvenli depoya aktarılıyor; kayıt işlemi henüz yapılamıyor.'},503);
    if(path==='/api/admin/store-import'){
      if(account.id!==ownerId||request.method!=='POST'||env.PERDE_MIGRATING!=='true')return json({error:'import_disabled'},403);
      return archiveStub(env).fetch(new Request('https://archive.internal/seed',{method:'POST',headers:{'Content-Type':'application/json'},body:request.body,duplex:'half'}));
    }
    if(path==='/api/admin/store-query'){
      if(account.id!==ownerId||env.PERDE_MIGRATING!=='true')return json({error:'diagnostic_disabled'},403);
      return archiveStub(env).fetch('https://archive.internal/query',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({sql:"SELECT kind,COUNT(*) AS count FROM marks WHERE user_id='perde-household' AND active=1 GROUP BY kind",params:[]})});
    }
    if(path==='/api/admin/store-backup'){
      if(account.id!==ownerId||env.PERDE_MIGRATING!=='true')return json({error:'diagnostic_disabled'},403);
      return archiveStub(env).fetch('https://archive.internal/backup?user='+encodeURIComponent(account.id));
    }
    if(['durable','d1','kv'].includes(env.PERDE_STORE)&&env.ARCHIVE_STORE)env={...env,DB:durableDatabase(archiveStub(env))};
    if(['/perde-logout','/signout-with-chatgpt'].includes(path)) {
      const response=redirect('/perde-login');response.headers.set('Set-Cookie',`${COOKIE}=; Secure; HttpOnly; SameSite=Lax; Path=/; Max-Age=0`);return response;
    }
    if(path.startsWith('/api/admin/')&&account.id!==ownerId) return json({error:'owner_required'},403);
    if(path==='/api/platform-corrections'&&request.method==='POST'&&account.id!==ownerId)return json({error:'owner_required'},403);
    try {
      let response,retainedCount=false;
      if(path==='/api/admin/read-budget')response=await archiveStub(env).fetch('https://archive.internal/stats');
      else if(path==='/api/admin/diagnostics'){
        const tests={ping:'SELECT 1 AS ok',revision:"SELECT MAX(updated_at) AS revision FROM marks WHERE user_id='perde-household'",marks:"SELECT kind,item_id FROM marks WHERE user_id='perde-household' AND active=1 ORDER BY kind,item_id LIMIT 10",preferences:"SELECT user_id FROM user_preferences WHERE user_id='perde-owner'"},results={};
        for(const [name,sql]of Object.entries(tests))try{const r=await env.DB.prepare(sql).all();results[name]={ok:true,rows:r.results.length}}catch(e){results[name]={ok:false,error:String(e.message).slice(0,400),cause:e.cause?String(e.cause.message).slice(0,400):null}}
        response=json(results);
      }
      else if(path==='/api/ui-version')response=json({version:UI_BUILD});
      else if(path==='/'&&request.method==='GET')response=await env.ASSETS.fetch(request);
      else if(path==='/app.js'&&request.method==='GET'){const asset=new URL(request.url);asset.pathname='/perde-app.js';response=await env.ASSETS.fetch(new Request(asset,request))}
      else if(!path.startsWith('/api/')&&/\.(js|json|bin|css|svg|png|jpg|jpeg|webp|ico|woff2?)$/.test(path))response=await env.ASSETS.fetch(request);
      else if(path==='/api/data-status')response=json(await dataStatus(env));
      else if(path==='/api/platform-corrections')response=await correctionApi(request,env);
      else if(path==='/api/catalog-index'&&request.method==='GET'&&url.searchParams.get('counts_only')==='1'&&url.searchParams.get('source_count')==='1') {
        response=await sourceCountBatch(request,env,ctx);
        if(!response){retainedCount=true;response=await application.fetch(trusted(request,account),{...env,DB:householdDatabase(env.DB,account.id)},ctx)}
      }
      else if(path==='/api/catalog'&&request.method==='GET'&&/^discover\/(movie|tv)$/.test(url.searchParams.get('path')||'')&&(url.searchParams.has('with_runtime.gte')||url.searchParams.has('with_runtime.lte')))response=await runtimeDiscover(request,env,ctx);
      else if(path==='/api/platforms'&&request.method==='GET') response=await platforms(request,env,ctx);
      else if(path==='/api/catalog'&&request.method==='GET'&&/^(movie|tv)\/\d+$/.test(url.searchParams.get('path')||'')) {
        const [type,id]=url.searchParams.get('path').split('/');response=json(await detail(env,type,Number(id),ctx));
      }
      else if(path==='/api/backup'&&request.method==='GET') response=await backup(env,account);
      else if(path==='/yonetim') response=html(admin.replace('Tam katalog 31 Ekim 2026 tarihli statik arşivdir; tamamı her gün yenilenmez.','Tam katalog, IMDb ve Türkiye platform bilgileri her gün Türkiye saatiyle 12.17 için ayarlı GitHub göreviyle yenilenir. İş kuyruğu başlangıcı geciktirebilir. Bu düğme yalnız küçük ek yenilemeyi çalıştırır; tam günlük görevin sonucu GitHub Actions sayfasındadır.'));
      else if(path==='/guncel') response=html(recentPage);
      else if(path==='/api/admin/refresh'&&request.method==='POST') response=json(await refresh(env));
      else if(path==='/api/admin/status'&&request.method==='GET') {
        const row=await env.DB.prepare('SELECT data FROM maintenance_state WHERE id=?').bind('refresh').first();
        const counts=await env.DB.prepare('SELECT kind,COUNT(*) AS count FROM marks WHERE user_id=? AND active=1 GROUP BY kind').bind(ARCHIVE).all();
        response=json({independent:true,scheduled:row?JSON.parse(row.data):{status:'not_run'},lists:counts.results,tmdbConfigured:!!env.TMDB_API_KEY,data:await dataStatus(env)});
      } else if(path==='/api/recent'&&request.method==='GET') {
        try{const r=await env.ASSETS.fetch(new Request('https://assets.invalid/platform-snapshots/recent.json'));if(r.ok)return json(await r.json())}catch{}
        const rows=await env.DB.prepare('SELECT snapshot FROM catalog WHERE adult=0 ORDER BY detail_at DESC LIMIT 100').all();response=json({results:rows.results.map(x=>JSON.parse(x.snapshot))});
      } else if(env.PERDE_STORE==='kv'){
        const route=new URL('https://archive.internal/dispatch');route.searchParams.set('target',request.url);response=await archiveStub(env).fetch(new Request(route,trusted(request,account)));
      } else response=await application.fetch(trusted(request,account),{...env,DB:householdDatabase(env.DB,account.id)},ctx);
      if(response.ok&&retainedCount){
        const data=await response.json();if(Array.isArray(data.source_ids)){const ids=await filterCorrectedIds(env,data.source_ids,url.searchParams),rows=await env.DB.prepare("SELECT item_id,kind FROM marks WHERE user_id=? AND active=1 AND kind IN ('watched','hidden') AND item_id IN(SELECT value FROM json_each(?))").bind(ARCHIVE,JSON.stringify(ids)).all(),excluded=new Set(rows.results.filter(x=>x.kind==='hidden'||url.searchParams.get('hide_watched')==='1').map(x=>x.item_id));data.source_ids=ids;data.source_total_delta=ids.length;data.source_remaining_delta=ids.filter(id=>!excluded.has(id)).length}response=json(data);
      }
      if(response.ok&&path==='/api/catalog'&&/^discover\/(movie|tv)$/.test(url.searchParams.get('path')||'')){
        const data=await response.json(),type=url.searchParams.get('path').split('/')[1],ids=(data.results||[]).map(x=>type+'-'+x.id),allowed=new Set(await filterCorrectedIds(env,ids,url.searchParams));
        data.results=(data.results||[]).filter(x=>allowed.has(type+'-'+x.id));response=json(data);
      }
      if(path==='/'&&response.ok&&response.headers.get('Content-Type')?.includes('text/html')){
       const body=(await response.text()).replace(/src="([^"?]+\.js)(?:\?[^\"]*)?"/g,(_,src)=>'src="'+src+'?v='+UI_BUILD+'"');
       response=html('<meta name="perde-build" content="'+UI_BUILD+'">'+body);
      }
      const secured=new Response(response.body,response);
      secured.headers.set('X-Content-Type-Options','nosniff');secured.headers.set('Referrer-Policy','strict-origin-when-cross-origin');
      if(account.exp-Date.now()/1000<150*86400) secured.headers.append('Set-Cookie',cookie(await issue(account,env.PERDE_SESSION_SECRET)));
      return secured;
    } catch { return json({error:'İşlem tamamlanamadı. Yönetim sayfasından güncelleme ve veritabanı durumunu kontrol edin.'},503); }
  },
  async scheduled(event,env,ctx) { if(['durable','d1','kv'].includes(env.PERDE_STORE)&&env.ARCHIVE_STORE)env={...env,DB:durableDatabase(archiveStub(env))};if(env.PERDE_MIGRATING!=='true')ctx.waitUntil(refresh(env)); }
};

