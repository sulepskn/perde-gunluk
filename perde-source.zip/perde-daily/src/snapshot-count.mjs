import {ARCHIVE} from './database.mjs';
import {correctionRows} from './corrections.mjs';
const cache=new WeakMap();
export function matchesSnapshotRow(row,p,blocked=new Set()){
 const [id,adult,date,genres,countries,language,votes,runtime,providers]=row,type=id.split('-')[0];
 if(p.get('type')&&p.get('type')!==type)return false;
 if(adult&&p.get('adult')!=='1')return false;
 if(p.get('dated')==='1'&&!date)return false;
 if(p.get('year')&&date.slice(0,4)!==p.get('year'))return false;
 if(p.get('original_language')&&language!==p.get('original_language'))return false;
 if(Number(votes)<Number(p.get('min_votes')||0))return false;
 if(p.get('genre_selected')==='1'&&!(p.get('genres_'+type)||'').split('|').some(x=>genres.includes(Number(x))))return false;
 if(p.get('country')&&(!countries.includes(p.get('country'))||p.get('country_mode')==='exclusive'&&countries.some(x=>x!==p.get('country'))))return false;
 if(p.get('runtime_min')||p.get('runtime_max')){
  if(type!=='movie'||!(runtime>0)||runtime<Number(p.get('runtime_min')||0)||p.get('runtime_max')&&runtime>Number(p.get('runtime_max')))return false;
 }
 const selected=(p.get('providers')||p.get('with_watch_providers')||'').split('|').filter(Boolean);
 const access=p.get('watch_access'),allowed=access==='stream'?['flatrate','free','ads']:access==='free'?['free','ads']:access==='rent_buy'?['rent','buy']:['flatrate','free','ads','rent','buy'];
 return selected.some(provider=>!blocked.has(id+':'+provider)&&(providers[provider]||[]).some(x=>allowed.includes(x)));
}
export async function snapshotCount(request,env){
 const p=new URL(request.url).searchParams;
 if(!env.ASSETS||!(p.get('providers')||p.get('with_watch_providers')))return null;
 let state=cache.get(env.ASSETS);
 if(!state||Date.now()-state.at>60000){
  try{const r=await env.ASSETS.fetch(new Request('https://assets.invalid/platform-snapshots/manifest.json'));if(!r.ok)return null;const manifest=await r.json();if(!manifest.count_shards||Date.now()-Date.parse(manifest.built_at)>36*3600000)return null;state={manifest,at:Date.now()};cache.set(env.ASSETS,state)}catch{return null}
 }
 const signature=new URLSearchParams(p);signature.delete('count_cursor');signature.sort();const key=signature.toString();let part=0;
 if(p.get('count_cursor'))try{const c=JSON.parse(p.get('count_cursor'));if(!c.snapshot_count)return null;if(c.key!==key||c.snapshot!==state.manifest.built_at||!Number.isInteger(c.part)||c.part<0||c.part>=state.manifest.count_shards)throw Error();part=c.part}catch{return Response.json({error:'invalid_cursor'},{status:400})}
 const r=await env.ASSETS.fetch(new Request('https://assets.invalid/platform-snapshots/count-'+String(part).padStart(2,'0')+'.json'));if(!r.ok)throw Error('snapshot_count_shard_missing');
 const rows=await r.json(),rowIds=rows.map(x=>x[0]),corrections=await correctionRows(env,rowIds),blocked=new Set(corrections.filter(x=>x.blocked===1).map(x=>x.item_id+':'+x.provider_id));
 // A newer, explicit detail refresh takes precedence until the next daily scan.
 const checked=Math.min(...rows.map(x=>x[9])),overrides=new Map();
 for(const type of ['movie','tv']){
  const numbers=rowIds.filter(x=>x.startsWith(type+'-')).map(x=>Number(x.split('-')[1]));if(!numbers.length)continue;
  const updates=await env.DB.prepare("SELECT tmdb_id,data,checked_at FROM watch_availability INDEXED BY sqlite_autoindex_watch_availability_1 WHERE media_type=? AND tmdb_id IN(SELECT value FROM json_each(?)) AND region='TR'").bind(type,JSON.stringify(numbers)).all();
  for(const u of updates.results){const a=JSON.parse(u.data);overrides.set(type+'-'+u.tmdb_id,{at:u.checked_at,providers:Object.fromEntries(a.offers.map(x=>[String(x.id),x.types]))})}
 }
 const ids=[];for(const original of rows){let row=original;const newer=overrides.get(row[0]);if(newer&&newer.at>row[9]){row=[...row];row[8]=newer.providers}if(matchesSnapshotRow(row,p,blocked))ids.push(row[0])}
 const marks=await env.DB.prepare("SELECT item_id,kind FROM marks WHERE user_id=? AND active=1 AND kind IN ('watched','hidden') AND item_id IN(SELECT value FROM json_each(?))").bind(ARCHIVE,JSON.stringify(ids)).all();
 const personal=new Set(marks.results.map(x=>x.item_id)),excluded=new Set(marks.results.filter(x=>x.kind==='hidden'||p.get('hide_watched')==='1').map(x=>x.item_id));
 return Response.json({source_ids:ids,eligible_mark_ids:ids.filter(x=>personal.has(x)),source_total_delta:ids.length,source_remaining_delta:ids.filter(x=>!excluded.has(x)).length,count_checked:rows.length,next_count_cursor:part+1<state.manifest.count_shards?JSON.stringify({snapshot_count:true,snapshot:state.manifest.built_at,key,part:part+1}):null,count_source:'daily_platform_snapshot',snapshot:state.manifest.snapshot},{headers:{'Cache-Control':'private,no-store'}});
}
