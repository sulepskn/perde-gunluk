import {matchesSnapshotRow} from './snapshot-count.mjs';
import {platformRecords} from './platform-snapshot.mjs';
import {correctionRows} from './corrections.mjs';

function normalized(value) {
  return value.toLowerCase().replaceAll('ı', 'i').normalize('NFKD')
    .replace(/[\u0300-\u036f]/g, '').replace(/[^\p{L}\p{N}]+/gu, ' ').trim();
}

export async function snapshotSearch(request, env) {
  const source = new URL(request.url).searchParams;
  if (!source.get('providers') || !await platformRecords(env,[])) return null;
  const type = (source.get('path') || '').split('/')[1];
  const query = normalized(source.get('query') || '');
  const prefix = query.split(' ')[0].slice(0, 2);
  if (!prefix) return null;
  const digest = new Uint8Array(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(prefix)));
  const bucket = String(((digest[0] << 8) | digest[1]) % 4096).padStart(4, '0');
  const response = await env.ASSETS.fetch(new Request('https://assets.invalid/platform-snapshots/search-' + bucket + '.json'));
  if (!response.ok) return null;
  const p = new URLSearchParams({type, providers: source.get('providers'),
    watch_access: source.get('watch_access') || 'all', adult: source.get('include_adult') === 'true' ? '1' : '0'});
  for (const [from, to] of [['with_origin_country', 'country'], ['country_mode', 'country_mode'],
    ['with_original_language', 'original_language'], ['primary_release_year', 'year'], ['first_air_date_year', 'year']]) {
    if (source.get(from)) p.set(to, source.get(from));
  }
  const rows = (await response.json()).filter(row => matchesSnapshotRow(row, p) &&
    [row[10], row[13] || ''].some(title => normalized(title).includes(query)));
  const corrections = await correctionRows(env, rows.map(row => row[0]));
  const blocked = new Set(corrections.filter(row => row.blocked === 1).map(row => row.item_id + ':' + row.provider_id));
  const matches = rows.filter(row => matchesSnapshotRow(row, p, blocked));
  const page = Math.max(1, Number(source.get('page')) || 1);
  const ids = matches.slice((page - 1) * 20, page * 20).map(row => row[0]);
  const daily = await platformRecords(env, ids);
  const results = ids.map(id => daily?.records[id]?.detail).filter(Boolean);
  return Response.json({results, page, total_results: matches.length, total_pages: Math.ceil(matches.length / 20)},
    {headers: {'Cache-Control': 'private,no-store'}});
}
