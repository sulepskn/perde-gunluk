export const ARCHIVE = 'perde-household';
// Lists are household-wide; ratings and preferences remain account-specific.
export function householdDatabase(db, accountId) {
  return new Proxy(db,{get(target,name){
    if(name==='prepare') return sql => {
      const stmt=target.prepare(sql);
      if(!/\bmarks\b/i.test(sql)) return stmt;
      return new Proxy(stmt,{get(statement,method){
        if(method==='bind') return (...values)=>statement.bind(...values.map(x=>x===accountId?ARCHIVE:x));
        const value=statement[method]; return typeof value==='function'?value.bind(statement):value;
      }});
    };
    const value=target[name]; return typeof value==='function'?value.bind(target):value;
  }});
}
