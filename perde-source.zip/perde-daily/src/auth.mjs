const encoder = new TextEncoder();
export const COOKIE = '__Host-perde-session';
const AGE = 180 * 86400;
const b64 = bytes => btoa(String.fromCharCode(...bytes)).replaceAll('+','-').replaceAll('/','_').replace(/=+$/,'');
const decode = value => Uint8Array.from(atob(value.replaceAll('-','+').replaceAll('_','/')), c => c.charCodeAt(0));
const key = secret => crypto.subtle.importKey('raw',encoder.encode(secret),{name:'HMAC',hash:'SHA-256'},false,['sign','verify']);
export async function digest(value) { return [...new Uint8Array(await crypto.subtle.digest('SHA-256',encoder.encode(value)))].map(x=>x.toString(16).padStart(2,'0')).join(''); }
export function accounts(env) {
  if (typeof env.PERDE_SESSION_SECRET !== 'string' || env.PERDE_SESSION_SECRET.length < 43) throw Error('auth_configuration');
  const data = JSON.parse(env.PERDE_ACCOUNTS_JSON || 'null');
  if (!Array.isArray(data) || !data.length || data.some(x=>!x.id || !x.email || !/^[a-f0-9]{64}$/.test(x.keyHash))) throw Error('auth_configuration');
  return data;
}
export async function issue(account, secret, now = Date.now()) {
  const body = b64(encoder.encode(JSON.stringify({sub:account.id,exp:Math.floor(now/1000)+AGE,ver:account.version||1})));
  return body+'.'+b64(new Uint8Array(await crypto.subtle.sign('HMAC',await key(secret),encoder.encode(body))));
}
export async function session(request, env, now = Date.now()) {
  const list = accounts(env);
  const token = (request.headers.get('Cookie')||'').split(';').map(x=>x.trim()).find(x=>x.startsWith(COOKIE+'='))?.slice(COOKIE.length+1);
  if (!token || token.length>2048) return null;
  try {
    const [body,sig,...rest] = token.split('.');
    if (rest.length || !await crypto.subtle.verify('HMAC',await key(env.PERDE_SESSION_SECRET),decode(sig),encoder.encode(body))) return null;
    const data = JSON.parse(new TextDecoder().decode(decode(body)));
    if (!Number.isFinite(data.exp) || data.exp<=now/1000) return null;
    const account = list.find(x=>x.id===data.sub && (x.version||1)===data.ver);
    return account ? {...account,exp:data.exp} : null;
  } catch { return null; }
}
export const cookie = token => `${COOKIE}=${token}; Secure; HttpOnly; SameSite=Lax; Path=/; Max-Age=${AGE}`;
export function trusted(request, account) {
  const headers = new Headers(request.headers);
  for (const name of [...headers.keys()]) if (/^(oai-|x-perde-)/i.test(name)) headers.delete(name);
  headers.set('oai-authenticated-user-id',account.id);
  headers.set('oai-authenticated-user-email',account.email);
  headers.set('oai-authenticated-user-full-name',encodeURIComponent(account.name||'Perde'));
  headers.set('oai-authenticated-user-full-name-encoding','percent-encoded-utf-8');
  return new Request(request,{headers});
}
export function loginPage(error=false) {
  return new Response(`<!doctype html><html lang="tr"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Perde · Giriş</title><style>body{background:#101511;color:#eef1e9;font:17px system-ui;max-width:430px;margin:10vh auto;padding:24px}p{line-height:1.6;color:#c0cbb8}input,button{box-sizing:border-box;width:100%;padding:16px;border-radius:12px;margin-top:12px;font:inherit}button{background:#d7f28b;border:0;cursor:pointer}label{display:block}</style><h1>Perde</h1><p>Kendi arşivin, her cihazında.</p>${error?'<p role="alert">Anahtar eşleşmedi. Başındaki ve sonundaki boşluklar otomatik temizlenir.</p>':''}<form method="post" action="/perde-login"><label>Giriş anahtarın<input name="key" type="password" autocomplete="current-password" autocapitalize="none" autocorrect="off" spellcheck="false" required minlength="32" maxlength="256"></label><button>Arşivimi aç</button></form><p>Bu cihaz 180 gün hatırlanır. Ortak cihazlarda işin bitince çıkış yap.</p></html>`,{status:error?401:200,headers:{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store','Content-Security-Policy':"default-src 'none'; style-src 'unsafe-inline'; form-action 'self'; frame-ancestors 'none'; base-uri 'none'"}});
}
