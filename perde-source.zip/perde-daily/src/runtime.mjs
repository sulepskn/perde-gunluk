import {snapshotDetail} from './platform-snapshot.mjs';
import {tmdb} from './maintenance.mjs';
import {ARCHIVE} from './database.mjs';
export function runtimeInfo(d){
 if(d?.type==='tv'||d?.media_type==='tv'||Array.isArray(d?.episode_run_time)||d?.number_of_seasons!=null)return null;
 const value=Number(d?.runtime);return Number.isFinite(value)&&value>0?{min:value,max:value,scope:'movie'}:null;
}
export function runtimeValue(d){return runtimeInfo(d)?.max??null}
export function runtimeMatches(d,min,max){const r=runtimeInfo(d);return r!==null&&r.min>=Math.max(1,Number(min)||0)&&r.max<=(max===''||max==null?Infinity:Number(max))}
export function countryMatches(d,country,mode){if(!country)return true;const origins=d.origin_country?.length?d.origin_country:(d.production_countries||[]).map(x=>x.iso_3166_1),all=new Set([...origins,...(d.production_countries||[]).map(x=>x.iso_3166_1)]);return origins.includes(country)&&(mode!=='exclusive'||[...all].every(x=>x===country))}
export async function runtimeDetail(env,type,id,ctx){
 const daily=await snapshotDetail(env,type,id);if(daily)return daily;
 const key='https://perde-cache.invalid/runtime-details/v3/'+type+'/'+id,cache=typeof caches==='undefined'?null:caches.default;
 try{const hit=await cache?.match(key);if(hit)return hit.json()}catch{}
 try{const row=await env.DB?.prepare('SELECT detail,detail_at FROM perde_metadata WHERE media_type=? AND tmdb_id=?').bind(type,id).first();if(row&&Date.now()-row.detail_at<21600000){const d=JSON.parse(row.detail);if(d.perde_runtime_version===3)return d}}catch{}
 let d=await tmdb(env,type+'/'+id);d.perde_runtime_version=3;
 try{if(env.DB)ctx.waitUntil(env.DB.prepare('INSERT INTO perde_metadata VALUES(?,?,?,?) ON CONFLICT(media_type,tmdb_id) DO UPDATE SET detail=excluded.detail,detail_at=excluded.detail_at').bind(type,id,JSON.stringify(d),Date.now()).run().catch(()=>{}))}catch{}
 if(cache)ctx.waitUntil(cache.put(key,new Response(JSON.stringify(d),{headers:{'Content-Type':'application/json','Cache-Control':'public,max-age=21600'}})).catch(()=>{}));return d;
}
const allowed=new Set(['language','include_adult','sort_by','vote_count.gte','with_genres','with_origin_country','with_original_language','primary_release_year','first_air_date_year','with_runtime.gte','with_runtime.lte']);
export async function runtimeDiscover(request,env,ctx,{includeMarked=false}={}){
 const p=new URL(request.url).searchParams,type=(p.get('path')||'').split('/')[1],q={};for(const [k,v]of p)if(allowed.has(k))q[k]=v;
 const min=Math.max(1,Number(p.get('with_runtime.gte'))||0),max=p.get('with_runtime.lte')??'';q['with_runtime.gte']=min;if(max!=='')q['with_runtime.lte']=max;
 if(p.get('providers')){q.watch_region='TR';q.with_watch_providers=p.get('providers');q.with_watch_monetization_types=p.get('watch_access')==='stream'?'flatrate|free|ads':p.get('watch_access')==='free'?'free|ads':p.get('watch_access')==='rent_buy'?'rent|buy':'flatrate|free|ads|rent|buy'}
 const signature=JSON.stringify([type,q,p.get('country_mode'),p.get('perde_hide_watched'),includeMarked]);let state={v:2,key:signature,page:1,offset:0,bound:null,total:null};
 if(p.get('perde_cursor'))try{const c=JSON.parse(p.get('perde_cursor'));if(c.v!==2||c.key!==signature||!Number.isInteger(c.page)||c.page<1||c.page>500||!Number.isInteger(c.offset)||c.offset<0||c.offset>20)throw Error();state=c}catch{return Response.json({error:'invalid_cursor'},{status:400})}
 const sort=q.sort_by||'',chronological=/^(primary_release_date|first_air_date)\.(asc|desc)$/.test(sort),descending=sort.endsWith('.desc'),date=type==='movie'?'primary_release_date':'first_air_date',dateField=type==='movie'?'release_date':'first_air_date';
 if(chronological){q[date+'.gte']=descending?'1800-01-01':state.bound||'1800-01-01';q[date+'.lte']=descending?state.bound||'9999-12-31':'9999-12-31';if(type==='tv')q.include_null_first_air_dates=false}
 const d=await tmdb(env,'discover/'+type,{...q,page:state.page});if(!Array.isArray(d.results))throw Error('invalid_discovery');if(state.total===null)state.total=d.total_results;
 const ids=d.results.map(x=>type+'-'+x.id),marked=includeMarked?{results:[]}:await env.DB.prepare("SELECT item_id FROM marks WHERE user_id=? AND active=1 AND (kind='hidden' OR(kind='watched' AND ?=1)) AND item_id IN(SELECT value FROM json_each(?))").bind(ARCHIVE,p.get('perde_hide_watched')==='1'?1:0,JSON.stringify(ids)).all();
 const excluded=new Set(marked.results.map(x=>x.item_id)),results=[];let checked=0;
 if(includeMarked){const candidates=d.results.slice(state.offset,state.offset+6);state.offset+=candidates.length;checked=candidates.length;const details=await Promise.all(candidates.map(raw=>runtimeDetail(env,type,raw.id,ctx)));for(const detail of details)if(runtimeMatches(detail,min,max)&&countryMatches(detail,p.get('with_origin_country'),p.get('country_mode')))results.push({...detail,runtime:runtimeValue(detail),media_type:type,genre_ids:(detail.genres||[]).map(x=>x.id),origin_country:detail.origin_country?.length?detail.origin_country:(detail.production_countries||[]).map(x=>x.iso_3166_1)})}
 else while(state.offset<d.results.length&&checked<4){const raw=d.results[state.offset++];if(excluded.has(type+'-'+raw.id))continue;checked++;const detail=await runtimeDetail(env,type,raw.id,ctx);if(runtimeMatches(detail,min,max)&&countryMatches(detail,p.get('with_origin_country'),p.get('country_mode')))results.push({...detail,runtime:runtimeValue(detail),media_type:type,genre_ids:(detail.genres||[]).map(x=>x.id),origin_country:detail.origin_country?.length?detail.origin_country:(detail.production_countries||[]).map(x=>x.iso_3166_1)})}
 let done=false;if(state.offset>=d.results.length){state.offset=0;if(!d.results.length||state.page>=d.total_pages)done=true;else if(chronological){const boundary=d.results.at(-1)?.[dateField];if(!/^\d{4}-\d{2}-\d{2}$/.test(boundary||''))throw Error('missing_date');if(boundary!==state.bound){state.bound=boundary;state.page=1}else state.page++}else state.page++;if(state.page>500){if(chronological)return Response.json({error:'date_bucket_limit'},{status:503});done=true}}
 return Response.json({page:Number(p.get('page'))||1,total_pages:chronological?(done?Number(p.get('page'))||1:500):d.total_pages,total_results:state.total,results,perde_cursor:done?null:JSON.stringify(state),perde_has_more:!done,runtime_verified:true,runtime_checked:checked},{headers:{'Cache-Control':'private,no-store'}});
}
