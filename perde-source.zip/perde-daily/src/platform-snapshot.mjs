const memo=new WeakMap();
export async function platformRecords(env,ids){
 if(!env.ASSETS)return null;let state=memo.get(env.ASSETS);if(!state||Date.now()-state.at>60000){try{const r=await env.ASSETS.fetch(new Request('https://assets.invalid/platform-snapshots/manifest.json'));if(!r.ok)return null;const manifest=await r.json();if(manifest.format!==1||manifest.region!=='TR'||Date.now()-Date.parse(manifest.built_at)>36*3600000)return null;state={at:Date.now(),manifest,buckets:new Map()};memo.set(env.ASSETS,state)}catch{return null}}
 const records={},groups=new Map();for(const id of ids){const bucket=String(Number(id.split('-')[1])%256).padStart(3,'0');if(!groups.has(bucket))groups.set(bucket,[]);groups.get(bucket).push(id)}
 for(const [bucket,selected]of groups){let rows=state.buckets.get(bucket);if(!rows){const r=await env.ASSETS.fetch(new Request('https://assets.invalid/platform-snapshots/'+bucket+'.json'));if(!r.ok)throw Error('platform_snapshot_incomplete');rows=await r.json();state.buckets.set(bucket,rows);while(state.buckets.size>12)state.buckets.delete(state.buckets.keys().next().value)}for(const id of selected)if(rows[id])records[id]=rows[id]}
 return{manifest:state.manifest,records};
}
export async function snapshotDetail(env,type,id){const result=await platformRecords(env,[type+'-'+id]);const d=result?.records[type+'-'+id]?.detail;if(!d)return null;const {watch_availability,...detail}=d;return detail}
