import {snapshotDetail} from './platform-snapshot.mjs';
import {availabilityBatch} from './availability.mjs';
import {tmdb,offers,saveDetail} from './maintenance.mjs';
import {attachIMDb} from '../vendor/application.mjs';

import {correctionRows,correctAvailability,correctionRevision} from './corrections.mjs';
const json=data=>Response.json(data,{headers:{'Cache-Control':'private,no-store'}});
async function cached(name,ttl,produce,ctx,force=false) {
 const cache=typeof caches==='undefined'?null:caches.default;
 const key='https://perde-cache.invalid/independent-v1/'+name;
 if(!force){try{const hit=await cache?.match(key);if(hit)return hit.json()}catch{}}
 const value=await produce();
 if(cache)ctx.waitUntil(cache.put(key,new Response(JSON.stringify(value),{headers:{'Content-Type':'application/json','Cache-Control':'public,max-age='+ttl}})).catch(()=>{}));
 return value;
}
export async function detail(env,type,id,ctx) {
 const daily=await snapshotDetail(env,type,id);if(daily)return attachIMDb(env,daily);
 return cached('detail-v3/'+type+'/'+id,1800,async()=>{
   let value=await tmdb(env,type+'/'+id,{append_to_response:'credits,keywords,external_ids,watch/providers'});
   try{value=await attachIMDb(env,value)}catch{}
   // Catalogue metadata is optional for interactive rendering. D1 quota errors must not hide public title details.
   ctx.waitUntil(saveDetail(env,type,value).catch(()=>{}));
   return {...value,media_type:type,genre_ids:value.genres?.map(x=>x.id)||[],origin_country:value.origin_country?.length?value.origin_country:value.production_countries?.map(x=>x.iso_3166_1)||[]};
 },ctx);
}
export async function platforms(request,env,ctx) {
 const p=new URL(request.url).searchParams,ids=(p.get('items')||'').split(',').filter(Boolean),force=p.get('refresh')==='1';
 if(ids.length>24||ids.some(x=>!/^(movie|tv)-\d{1,12}$/.test(x)))return Response.json({error:'invalid_items'},{status:400});
 try {
   if(!ids.length){
     const data=await cached('platform-options',21600,async()=>{
       const lists=await Promise.all(['movie','tv'].map(type=>tmdb(env,'watch/providers/'+type,{watch_region:'TR'})));
       const found=new Map();
       for(const x of lists.flatMap(x=>x.results||[])){const priority=Number(x.display_priorities?.TR??x.display_priority??999);if(!found.has(x.provider_id)||found.get(x.provider_id).priority>priority)found.set(x.provider_id,{id:x.provider_id,name:x.provider_name,logo:x.logo_path||null,priority})}
       if(![...found.values()].some(x=>/^youtube$/i.test(x.name))){const all=await tmdb(env,'watch/providers/movie');for(const x of all.results||[])if(/^youtube$/i.test(x.provider_name))found.set(x.provider_id,{id:x.provider_id,name:x.provider_name,logo:x.logo_path||null,priority:999})}
       return {region:'TR',checked_at:Date.now(),results:[...found.values()].sort((a,b)=>a.priority-b.priority||a.name.localeCompare(b.name,'tr'))};
     },ctx,force);try{data.correction_revision=await correctionRevision(env)}catch{}return json(data);
   }
   const queue=[...new Set(ids)],results=await availabilityBatch(env,queue,force);
   try{const rows=await correctionRows(env,queue);for(const id of queue)if(!results[id]?.error)results[id]=correctAvailability(id,results[id],rows)}catch{for(const id of queue)if(results[id])results[id].verification='corrections_unavailable'}
   return json({region:'TR',results});
 }catch{return Response.json({error:'platforms_unavailable'},{status:502})}
}
