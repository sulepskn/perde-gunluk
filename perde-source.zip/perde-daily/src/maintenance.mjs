export async function tmdb(env,path,params={}) {
  if (!env.TMDB_API_KEY) throw Error('tmdb_key_missing');
  const url=new URL('https://api.themoviedb.org/3/'+path);
  url.searchParams.set('api_key',env.TMDB_API_KEY);
  for(const [k,v] of Object.entries({language:'tr-TR',...params})) url.searchParams.set(k,String(v));
  url.searchParams.sort();
  const response=await fetch(url,{signal:AbortSignal.timeout(12000)});
  if(!response.ok) throw Error('tmdb_http_'+response.status);
  return response.json();
}
export function offers(detail,now=Date.now()) {
  const region=detail['watch/providers']?.results?.TR||{}, grouped=new Map();
  for(const type of ['flatrate','free','ads','rent','buy']) for(const x of region[type]||[]) {
    if(!Number.isInteger(x.provider_id)) continue;
    const entry=grouped.get(x.provider_id)||{id:x.provider_id,name:x.provider_name,logo:x.logo_path||null,types:[]};
    entry.types.push(type);grouped.set(x.provider_id,entry);
  }
  return {region:'TR',offers:[...grouped.values()],link:region.link||null,checked_at:now,source:'JustWatch via TMDB',source_status:'available'};
}
export async function saveDetail(env,type,detail) {
  const now=Date.now(), snapshot={...detail,media_type:type}, id=detail.id;
  const availability=offers(detail,now);
  await env.DB.batch([
    env.DB.prepare('INSERT INTO catalog(media_type,tmdb_id,original_title,search_title,popularity,adult,snapshot,detail,detail_at,imdb_id,imdb_score) VALUES(?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(media_type,tmdb_id) DO UPDATE SET original_title=excluded.original_title,search_title=excluded.search_title,popularity=excluded.popularity,adult=excluded.adult,snapshot=excluded.snapshot,detail=excluded.detail,detail_at=excluded.detail_at,imdb_id=excluded.imdb_id').bind(type,id,detail.original_title||detail.original_name||'',(detail.title||detail.name||'').toLocaleLowerCase('tr'),detail.popularity||0,detail.adult?1:0,JSON.stringify(snapshot),JSON.stringify(detail),now,detail.imdb_id||detail.external_ids?.imdb_id||null,-1),
    env.DB.prepare('INSERT INTO perde_metadata VALUES(?,?,?,?) ON CONFLICT(media_type,tmdb_id) DO UPDATE SET detail=excluded.detail,detail_at=excluded.detail_at').bind(type,id,JSON.stringify(detail),now),
    env.DB.prepare('INSERT INTO watch_availability VALUES(?,?,?,?,?) ON CONFLICT(media_type,tmdb_id,region) DO UPDATE SET data=excluded.data,checked_at=excluded.checked_at').bind(type,id,'TR',JSON.stringify(availability),now)
  ]);
  return availability;
}
export async function refresh(env,now=Date.now()) {
  const started=new Date(now).toISOString();
  try {
    // Small batches keep each Free invocation bounded. A full static snapshot is never imported into D1.
    const slot=Math.floor(now/900000), type=slot%2?'tv':'movie';
    const page=1+Math.floor((slot%96)/20), index=slot%20;
    const today=new Date(now).toISOString().slice(0,10);
    const recent=await tmdb(env,'discover/'+type,{sort_by:type==='movie'?'primary_release_date.desc':'first_air_date.desc',page,include_adult:false,[type==='movie'?'primary_release_date.lte':'first_air_date.lte']:today,'vote_count.gte':5});
    const candidate=recent.results?.[index]||recent.results?.[0];
    if(candidate) await saveDetail(env,type,await tmdb(env,type+'/'+candidate.id,{append_to_response:'watch/providers,external_ids'}));
    const stale=await env.DB.prepare("SELECT media_type,tmdb_id FROM watch_availability WHERE region='TR' AND checked_at<? ORDER BY checked_at LIMIT 1").bind(now-86400000).first();
    if(stale) await saveDetail(env,stale.media_type,await tmdb(env,stale.media_type+'/'+stale.tmdb_id,{append_to_response:'watch/providers,external_ids'}));
    const state={status:'ok',started,finished:new Date().toISOString(),latest:candidate?type+'-'+candidate.id:null,refreshedPlatforms:stale?1:0,scope:'Recent titles and one stale platform record per run; static full catalogue remains a dated snapshot.'};
    await env.DB.prepare('INSERT INTO maintenance_state VALUES(?,?) ON CONFLICT(id) DO UPDATE SET data=excluded.data').bind('refresh',JSON.stringify(state)).run();
    return state;
  } catch(error) {
    const state={status:'error',started,finished:new Date().toISOString(),error:/^(tmdb_key_missing|tmdb_http_\d+)$/.test(error.message)?error.message:'refresh_failed'};
    await env.DB.prepare('INSERT INTO maintenance_state VALUES(?,?) ON CONFLICT(id) DO UPDATE SET data=excluded.data').bind('refresh',JSON.stringify(state)).run();
    throw Error(state.error);
  }
}
