import {tmdb} from './maintenance.mjs';

import {ARCHIVE} from './database.mjs';
import {runtimeDetail,runtimeMatches,countryMatches,runtimeDiscover} from './runtime.mjs';
import {filterCorrectedIds} from './corrections.mjs';

const json=(data,status=200)=>Response.json(data,{status,headers:{'Cache-Control':'private,no-store'}});

function parameters(p,type,page){

 const q={include_adult:p.get('adult')==='1',page,sort_by:sortValue(p.get('count_sort'),type)};

 if(type==='tv'&&(p.get('year')||p.get('dated')==='1'))q.include_null_first_air_dates=false;

 for(const [from,to] of [['country','with_origin_country'],['original_language','with_original_language']])if(p.get(from))q[to]=p.get(from);

 if(p.get('year'))q[type==='movie'?'primary_release_year':'first_air_date_year']=p.get('year');

 if(Number(p.get('min_votes'))>0)q['vote_count.gte']=p.get('min_votes');
 if(type==='movie'&&(p.get('runtime_min')||p.get('runtime_max'))){q['with_runtime.gte']=Math.max(1,Number(p.get('runtime_min'))||0);if(p.get('runtime_max')!=='')q['with_runtime.lte']=p.get('runtime_max')}

 if(p.get('genre_selected')==='1')q.with_genres=p.get('genres_'+type)||'';

 if(p.get('dated')==='1'){const key=type==='movie'?'primary_release_date':'first_air_date';q[key+'.gte']='1800-01-01';q[key+'.lte']='9999-12-31'}

 const providers=p.get('providers')||p.get('with_watch_providers');

 if(providers){q.watch_region='TR';q.with_watch_providers=providers;q.with_watch_monetization_types=p.get('watch_access')==='stream'?'flatrate|free|ads':p.get('watch_access')==='free'?'free|ads':p.get('watch_access')==='rent_buy'?'rent|buy':'flatrate|free|ads|rent|buy'}

 return q;

}

async function pageData(env,p,type,page,ctx){

 const q=parameters(p,type,page),key='https://perde-cache.invalid/count-pages/v1/'+type+'?'+new URLSearchParams(q);

 const cache=typeof caches==='undefined'?null:caches.default;

 try{const hit=await cache?.match(key);if(hit)return hit.json()}catch{}

 const value=await tmdb(env,'discover/'+type,q);

 if(!Array.isArray(value.results)||!Number.isFinite(value.total_pages)||!Number.isFinite(value.total_results))throw Error('invalid_source');

 if(cache)ctx.waitUntil(cache.put(key,new Response(JSON.stringify(value),{headers:{'Content-Type':'application/json','Cache-Control':'public,max-age=300'}})).catch(()=>{}));

 return value;

}

function sortValue(sort,type){return sort==='old'?(type==='movie'?'primary_release_date.asc':'first_air_date.asc'):sort==='new'?(type==='movie'?'primary_release_date.desc':'first_air_date.desc'):sort==='votes'?'vote_count.desc':sort==='title'?(type==='movie'?'title.asc':'name.asc'):sort==='rating'?'vote_average.desc':'popularity.desc'}
async function runtimeCount(request,env,ctx){
 const p=new URL(request.url).searchParams;
 if(p.get('genre_selected')==='1'&&!p.get('genres_movie'))return json({source_ids:[],eligible_mark_ids:[],source_total_delta:0,source_remaining_delta:0,count_checked:0,next_count_cursor:null});
 const q=new URLSearchParams({path:'discover/movie',sort_by:sortValue(p.get('count_sort'),'movie'),include_adult:p.get('adult')==='1'?'true':'false',perde_hide_watched:'0','with_runtime.gte':String(Math.max(1,Number(p.get('runtime_min'))||0))});
 for(const [from,to]of [['runtime_max','with_runtime.lte'],['year','primary_release_year'],['country','with_origin_country'],['country_mode','country_mode'],['original_language','with_original_language'],['min_votes','vote_count.gte'],['providers','providers'],['watch_access','watch_access']])if(p.get(from)&&(from!=='min_votes'||Number(p.get(from))>0))q.set(to,p.get(from));
 if(p.get('genre_selected')==='1')q.set('with_genres',p.get('genres_movie'));if(p.get('count_cursor'))q.set('perde_cursor',p.get('count_cursor'));
 const response=await runtimeDiscover(new Request('https://archive.internal/api/catalog?'+q),env,ctx,{includeMarked:true});if(!response.ok)return response;const d=await response.json(),ids=await filterCorrectedIds(env,d.results.map(x=>'movie-'+x.id),p);
 const rows=await env.DB.prepare("SELECT item_id,kind FROM marks WHERE user_id=? AND active=1 AND kind IN ('watched','hidden') AND item_id IN(SELECT value FROM json_each(?))").bind(ARCHIVE,JSON.stringify(ids)).all(),personal=new Set(rows.results.map(x=>x.item_id)),excluded=new Set(rows.results.filter(x=>x.kind==='hidden'||p.get('hide_watched')==='1').map(x=>x.item_id));
 return json({source_ids:ids,eligible_mark_ids:ids.filter(id=>personal.has(id)),source_total_delta:ids.length,source_remaining_delta:ids.filter(id=>!excluded.has(id)).length,count_checked:d.runtime_checked,next_count_cursor:d.perde_cursor,runtime_verified:true});
}

export async function sourceCountBatch(request,env,ctx){

 const p=new URL(request.url).searchParams;

 // Exact production-country and runtime checks still need title details in the retained path.

 const hasRuntime=p.get('type')!=='tv'&&Boolean(p.get('runtime_min')||p.get('runtime_max'));
 if(hasRuntime)return runtimeCount(request,env,ctx);
 if(!hasRuntime&&p.get('country')&&p.get('country_mode')==='exclusive')return null;

 const types=(p.get('type')?[p.get('type')]:['movie','tv']).filter(t=>!hasRuntime||t==='movie').filter(t=>p.get('genre_selected')!=='1'||p.get('genres_'+t));

 if(types.some(t=>!['movie','tv'].includes(t)))return json({error:'invalid_type'},400);

 const signature=new URLSearchParams(p);signature.delete('count_cursor');signature.sort();

 let state={v:1,key:signature.toString(),t:0,page:1,offset:0};

 if(p.get('count_cursor'))try{

   const c=JSON.parse(p.get('count_cursor'));

   if(c.v!==1||c.key!==state.key||!Number.isInteger(c.t)||c.t<0||c.t>types.length||!Number.isInteger(c.page)||c.page<1||c.page>500||!Number.isInteger(c.offset)||c.offset<0||c.offset>20)throw Error();state=c;

 }catch{return json({error:'invalid_cursor'},400)}

 if(state.t>=types.length)return json({eligible_mark_ids:[],source_total_delta:0,source_remaining_delta:0,count_checked:0,next_count_cursor:null,source_total:0});

 try{

   const typeIndex=state.t,type=types[typeIndex],first=await pageData(env,p,type,state.page,ctx);

   if(first.total_pages>500)return json({error:'source_count_limit',message:'Bu seçim kaynak sayfa sınırını aşıyor; kesin kalan sayı hesaplanamadı.'},503);

   const other=types.length>1?await pageData(env,p,types[1-typeIndex],1,ctx):null;

   if(other?.total_pages>500)return json({error:'source_count_limit',message:'Bu se�im kaynak sayfa s�n�r�n� a��yor; kesin kalan say� hesaplanamad�.'},503);

   const sourceTotal=first.total_results+(other?.total_results||0);

   const last=Math.min(first.total_pages,state.page+((p.get('providers')||p.get('with_watch_providers'))?0:9)),pages=[first,...await Promise.all(Array.from({length:Math.max(0,last-state.page)},(_,i)=>pageData(env,p,type,state.page+i+1,ctx)))];

   const rows=pages.flatMap((x,i)=>i===0?x.results.slice(state.offset):x.results).filter(x=>!p.get('year')||String(x[type==='movie'?'release_date':'first_air_date']||'').slice(0,4)===p.get('year')),ids=await filterCorrectedIds(env,[...new Set(rows.map(x=>type+'-'+x.id))],p);

   const marked=await env.DB.prepare("SELECT item_id,kind FROM marks WHERE user_id=? AND active=1 AND kind IN ('watched','hidden') AND item_id IN (SELECT value FROM json_each(?))").bind(ARCHIVE,JSON.stringify(ids)).all();

   const personal=new Set(marked.results.map(x=>x.item_id)),excluded=new Set(marked.results.filter(x=>x.kind==='hidden'||p.get('hide_watched')==='1').map(x=>x.item_id));

   state.page=last+1;state.offset=0;if(state.page>first.total_pages){state.t++;state.page=1}

   return json({source_ids:ids,eligible_mark_ids:ids.filter(id=>personal.has(id)),source_total_delta:ids.length,source_remaining_delta:ids.filter(id=>!excluded.has(id)).length,count_checked:ids.length,next_count_cursor:state.t<types.length?JSON.stringify(state):null,source_total:sourceTotal});

 }catch{return json({error:'source_count_unavailable'},502)}

}

