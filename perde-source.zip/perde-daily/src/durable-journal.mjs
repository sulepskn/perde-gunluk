// Keep frequent, acknowledged changes in the existing Durable Object's SQLite.
// KV holds occasional complete snapshots and the untouched legacy journals.
export function durableJournalNamespace(kv,storage){
 if(!storage?.sql||typeof storage.transactionSync!=='function')throw Error('durable_journal_storage_unavailable');
 const stats={rowsRead:0,rowsWritten:0,puts:0,legacyScans:0},prefix='journal/',chunkSize=512*1024;
 function exec(sql,...args){const c=storage.sql.exec(sql,...args),rows=c.toArray();stats.rowsRead+=c.rowsRead||0;stats.rowsWritten+=c.rowsWritten||0;return rows}
 exec('CREATE TABLE IF NOT EXISTS perde_durable_journal(id TEXT PRIMARY KEY,metadata TEXT NOT NULL,parts INTEGER NOT NULL,legacy INTEGER NOT NULL DEFAULT 0) WITHOUT ROWID');
 exec('CREATE TABLE IF NOT EXISTS perde_durable_journal_parts(id TEXT NOT NULL,part INTEGER NOT NULL,data BLOB NOT NULL,PRIMARY KEY(id,part)) WITHOUT ROWID');
 exec('CREATE TABLE IF NOT EXISTS perde_durable_journal_state(id TEXT PRIMARY KEY,started_at INTEGER NOT NULL,last_scan INTEGER NOT NULL) WITHOUT ROWID');
 let scanning;
 async function legacy(){
  if(scanning)return scanning;
  scanning=(async()=>{const now=Date.now(),state=exec("SELECT started_at,last_scan FROM perde_durable_journal_state WHERE id='kv-legacy'")[0];
   // Recheck during the rolling-code transition so a late old-version journal
   // is imported too. Later cold starts need no KV list operation.
   if(state&&(now-state.started_at>10*60000||now-state.last_scan<60000))return;
   const keys=[];let cursor;
   do{const page=await kv.list({prefix,limit:1000,...(cursor?{cursor}:{})});stats.legacyScans++;keys.push(...page.keys);cursor=page.list_complete?null:page.cursor}while(cursor);
   storage.transactionSync(()=>{for(const k of keys)exec('INSERT OR IGNORE INTO perde_durable_journal VALUES(?,?,0,1)',k.name,JSON.stringify(k.metadata||{}));exec("INSERT INTO perde_durable_journal_state VALUES('kv-legacy',?,?) ON CONFLICT(id) DO UPDATE SET last_scan=excluded.last_scan",now,now)});
  })();try{await scanning}finally{scanning=null}
 }
 async function get(key,options){
  if(!key.startsWith(prefix))return kv.get(key,options);
  const head=exec('SELECT parts,legacy FROM perde_durable_journal WHERE id=?',key)[0];
  if(!head||head.legacy)return kv.get(key,options);
  const parts=exec('SELECT data FROM perde_durable_journal_parts WHERE id=? ORDER BY part',key);
  if(parts.length!==head.parts)throw Error('durable_journal_parts_incomplete');
  const arrays=parts.map(p=>new Uint8Array(p.data)),bytes=new Uint8Array(arrays.reduce((n,p)=>n+p.length,0));let at=0;
  for(const part of arrays){bytes.set(part,at);at+=part.length}return new TextDecoder().decode(bytes);
 }
 async function put(key,value,options={}){
  if(!key.startsWith(prefix))return kv.put(key,value,options);
  const bytes=new TextEncoder().encode(value),count=Math.ceil(bytes.length/chunkSize);
  storage.transactionSync(()=>{
   exec('INSERT INTO perde_durable_journal VALUES(?,?,?,0) ON CONFLICT(id) DO UPDATE SET metadata=excluded.metadata,parts=excluded.parts,legacy=0',key,JSON.stringify(options.metadata||{}),count);
   exec('DELETE FROM perde_durable_journal_parts WHERE id=?',key);
   for(let part=0;part<count;part++){const data=bytes.slice(part*chunkSize,(part+1)*chunkSize);exec('INSERT INTO perde_durable_journal_parts VALUES(?,?,?)',key,part,data.buffer)}
  });stats.puts++;
 }
 async function list(options={}){
  if(options.prefix!==prefix)return kv.list(options);
  await legacy();const after=options.cursor?JSON.parse(options.cursor).sqlJournalAfter:'',limit=Math.min(1000,Math.max(1,options.limit||1000));
  if(typeof after!=='string')throw Error('invalid_durable_journal_cursor');
  const rows=exec('SELECT id,metadata FROM perde_durable_journal WHERE id>? ORDER BY id LIMIT ?',after,limit+1),more=rows.length>limit,keys=rows.slice(0,limit).map(r=>({name:r.id,metadata:JSON.parse(r.metadata)}));
  return{keys,list_complete:!more,...(more?{cursor:JSON.stringify({sqlJournalAfter:keys.at(-1).name})}:{})};
 }
 async function remove(key){
  if(!key.startsWith(prefix))return kv.delete(key);
  // Legacy KV objects remain as recovery material. Only the SQL index expires.
  storage.transactionSync(()=>{exec('DELETE FROM perde_durable_journal_parts WHERE id=?',key);exec('DELETE FROM perde_durable_journal WHERE id=?',key)});
 }
 return{get,getWithMetadata:(...args)=>kv.getWithMetadata(...args),put,list,delete:remove,stats};
}
