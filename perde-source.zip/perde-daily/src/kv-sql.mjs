import initSQL from '../vendor/sqlite-runtime.cjs';
import wasm from '../vendor/sqlite-runtime.wasm';
import {memoryDatabase} from './memory-sql.mjs';
import {durableJournalNamespace} from './durable-journal.mjs';
export function kvDatabase(namespace,onReplay,storage){
 const journal=durableJournalNamespace(namespace,storage),db=memoryDatabase(journal,initSQL,wasm,onReplay);
 Object.assign(db.stats,{journalBackend:'durable_sql',journalSql:journal.stats});return db;
}
