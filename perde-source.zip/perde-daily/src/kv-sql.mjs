import initSQL from '../vendor/sqlite-runtime.cjs';
import wasm from '../vendor/sqlite-runtime.wasm';
import {memoryDatabase} from './memory-sql.mjs';
export const kvDatabase=(namespace,onReplay)=>memoryDatabase(namespace,initSQL,wasm,onReplay);
