import {ARCHIVE} from './database.mjs';
import {matchesSnapshotRow} from './snapshot-count.mjs';
import {correctionRows} from './corrections.mjs';

// Browse and count the same daily metadata. Bound each request's scan and asset reads.
const states = new WeakMap();
function chunkMayMatch(chunk, p) {
  if (!chunk) return true;
  const providers = (p.get('providers') || '').split('|');
  if (!providers.some(id => chunk.providers.includes(id))) return false;
  if (p.get('type') && !chunk.types.includes(p.get('type'))) return false;
  if (p.get('year') && !chunk.years.includes(p.get('year'))) return false;
  if (p.get('country') && !chunk.countries.includes(p.get('country'))) return false;
  if (p.get('original_language') && !chunk.languages.includes(p.get('original_language'))) return false;
  const genres = (p.get('genres_movie') + '|' + p.get('genres_tv')).split('|').map(Number);
  return p.get('genre_selected') !== '1' || genres.some(id => chunk.genres.includes(id));
}
export async function snapshotBrowse(request, env) {
  const p = new URL(request.url).searchParams;
  if (!p.get('providers') || p.has('counts_only') || p.has('status')) return null;
  let state = states.get(env.ASSETS);
  if (!state || Date.now() - state.at > 60000) {
    const response = await env.ASSETS.fetch(new Request('https://assets.invalid/platform-snapshots/manifest.json'));
    if (!response.ok) return null;
    const manifest = await response.json();
    if (!manifest.browse || Date.now() - Date.parse(manifest.built_at) > 36 * 3600000) return null;
    state = {manifest, at: Date.now(), chunks: new Map(), indexes: new Map()};
    states.set(env.ASSETS, state);
  }
  const {manifest} = state;
  const sort = ['popular', 'votes', 'rating', 'old', 'new', 'title'].includes(p.get('sort')) ? p.get('sort') : 'popular';
  if (['old', 'new'].includes(sort)) p.set('dated', '1');
  const signature = new URLSearchParams(p);
  signature.delete('cursor');
  signature.sort();
  const key = signature.toString();
  if (!state.indexes.has(sort)) {
    const response = await env.ASSETS.fetch(new Request('https://assets.invalid/platform-snapshots/browse-index-' + sort + '.json'));
    state.indexes.set(sort, response.ok ? await response.json() : []);
  }
  let offset = 0;
  if (p.get('cursor')) {
    try {
      const cursor = JSON.parse(p.get('cursor'));
      if (cursor.key !== key || cursor.snapshot !== manifest.built_at ||
          !Number.isSafeInteger(cursor.offset) || cursor.offset < 0 || cursor.offset > manifest.browse.total) throw Error();
      offset = cursor.offset;
    } catch {
      return Response.json({error: 'invalid_cursor'}, {status: 400});
    }
  }
  const candidates = [];
  let scanned = 0;
  while (offset < manifest.browse.total && scanned < 1024 && candidates.length < 20) {
    const part = Math.floor(offset / manifest.browse.chunk_size);
    if (!chunkMayMatch(state.indexes.get(sort)[part], p)) {
      offset = Math.min(manifest.browse.total, (part + 1) * manifest.browse.chunk_size);
      continue;
    }
    const name = sort + '-' + String(part).padStart(4, '0');
    let rows = state.chunks.get(name);
    if (!rows) {
      const response = await env.ASSETS.fetch(new Request('https://assets.invalid/platform-snapshots/browse-' + name + '.json'));
      if (!response.ok) throw Error('snapshot_browse_incomplete');
      rows = await response.json();
      state.chunks.set(name, rows);
      while (state.chunks.size > 12) state.chunks.delete(state.chunks.keys().next().value);
    }
    const row = rows[offset % manifest.browse.chunk_size];
    if (!row) throw Error('snapshot_browse_invalid');
    offset++;
    scanned++;
    if (matchesSnapshotRow(row, p)) candidates.push(row);
  }
  const ids = candidates.map(row => row[0]);
  const corrections = await correctionRows(env, ids);
  const blocked = new Set(corrections.filter(row => row.blocked === 1).map(row => row.item_id + ':' + row.provider_id));
  const marks = await env.DB.prepare("SELECT item_id FROM marks WHERE user_id=? AND active=1 AND (kind='hidden' OR(kind='watched' AND ?=1)) AND item_id IN(SELECT value FROM json_each(?))")
    .bind(ARCHIVE, p.get('hide_watched') === '1' ? 1 : 0, JSON.stringify(ids)).all();
  const excluded = new Set(marks.results.map(row => row.item_id));
  const results = candidates.filter(row => !excluded.has(row[0]) && matchesSnapshotRow(row, p, blocked)).map(row => {
    const [type, number] = row[0].split('-');
    const offers = Object.entries(row[8]).filter(([provider]) => !blocked.has(row[0] + ':' + provider))
      .map(([provider, types]) => ({id: Number(provider), name: manifest.browse.providers[provider] || 'Platform ' + provider, types}));
    return {id: Number(number), media_type: type, adult: Boolean(row[1]),
      title: row[10], name: row[10], original_title: row[10], original_name: row[10],
      [type === 'movie' ? 'release_date' : 'first_air_date']: row[2], genre_ids: row[3], origin_country: row[4],
      original_language: row[5], vote_count: row[6], runtime: row[7], popularity: row[11], vote_average: row[12],
      needs_detail: true, in_catalog: true,
      watch_availability: {region: 'TR', offers, checked_at: row[9], source: 'Günlük Türkiye platform kataloğu'}};
  });
  return Response.json({results, source: 'fast_filtered_discovery', filtered: true, capped: false,
    count_pending: true, total_results: 0, total_before_exclusions: 0, candidate_total: manifest.currently_available,
    eligible_mark_ids: [], scanned, snapshot: manifest.snapshot,
    next_cursor: offset < manifest.browse.total ? JSON.stringify({key, snapshot: manifest.built_at, offset}) : null},
    {headers: {'Cache-Control': 'private,no-store'}});
}

export async function snapshotDiscover(request, env) {
  const source = new URL(request.url).searchParams;
  if (!(source.get('providers') || source.get('with_watch_providers'))) return null;
  const type = (source.get('path') || '').split('/')[1];
  const sort = source.get('sort_by') || '';
  const orders = {'popularity.desc': 'popular', 'vote_count.desc': 'votes', 'vote_average.desc': 'rating',
    'primary_release_date.asc': 'old', 'primary_release_date.desc': 'new',
    'first_air_date.asc': 'old', 'first_air_date.desc': 'new', 'title.asc': 'title', 'name.asc': 'title'};
  const p = new URLSearchParams({type, sort: orders[sort] || 'popular',
    adult: source.get('include_adult') === 'true' ? '1' : '0',
    providers: source.get('providers') || source.get('with_watch_providers'),
    hide_watched: source.get('perde_hide_watched') || '0'});
  for (const [from, to] of [['with_origin_country', 'country'], ['country_mode', 'country_mode'],
    ['with_original_language', 'original_language'], ['vote_count.gte', 'min_votes'],
    ['with_runtime.gte', 'runtime_min'], ['with_runtime.lte', 'runtime_max'],
    ['primary_release_year', 'year'], ['first_air_date_year', 'year'], ['watch_access', 'watch_access']]) {
    if (source.get(from)) p.set(to, source.get(from));
  }
  if (source.get('with_genres')) {
    p.set('genre_selected', '1');
    p.set('genres_' + type, source.get('with_genres').replaceAll(',', '|'));
  }
  if (source.get('perde_cursor')) p.set('cursor', source.get('perde_cursor'));
  const response = await snapshotBrowse(new Request('https://archive.internal/api/catalog-index?' + p), env);
  if (!response || !response.ok) return response;
  const data = await response.json();
  return Response.json({...data, page: Number(source.get('page')) || 1, total_pages: 1,
    perde_cursor: data.next_cursor, perde_has_more: Boolean(data.next_cursor)},
    {headers: {'Cache-Control': 'private,no-store'}});
}
