export function durableDatabase(stub){
 async function send(path,body){const r=await stub.fetch('https://archive.internal'+path,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});const d=await r.json();if(!r.ok)throw Error(d.error||'archive_storage_unavailable');return d}
 function statement(sql,params=[]){return{sql,params,bind(...values){return statement(sql,values)},async all(){return send('/query',{sql,params})},async run(){return send('/query',{sql,params})},async first(column){const d=await send('/query',{sql,params});const row=d.results[0];return row?(column?row[column]:row):null},async raw(options){const d=await send('/query',{sql,params});const rows=d.results.map(x=>d.columns.map(k=>x[k]));return options?.columnNames?[d.columns,...rows]:rows}}}
 return{prepare:sql=>statement(sql),batch:statements=>send('/batch',{statements:statements.map(s=>({sql:s.sql,params:s.params}))}),exec:sql=>send('/query',{sql,params:[]})};
}
export function archiveStub(env){return env.ARCHIVE_STORE.get(env.ARCHIVE_STORE.idFromName('household-v1'))}
