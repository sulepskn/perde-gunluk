import {availabilityBatch} from './availability.mjs';
let schema;
async function ready(env){if(!schema)schema=env.DB.prepare('CREATE TABLE IF NOT EXISTS platform_corrections(item_id TEXT NOT NULL,provider_id INTEGER NOT NULL,blocked INTEGER NOT NULL,note TEXT NOT NULL,updated_at INTEGER NOT NULL,PRIMARY KEY(item_id,provider_id)) WITHOUT ROWID').run().catch(e=>{schema=null;throw e});await schema}
export async function correctionRows(env,ids){await ready(env);const r=await env.DB.prepare('SELECT item_id,provider_id,blocked,note,updated_at FROM platform_corrections WHERE item_id IN (SELECT value FROM json_each(?))').bind(JSON.stringify(ids)).all();return r.results}
export async function correctionRevision(env){await ready(env);const row=await env.DB.prepare('SELECT COALESCE(MAX(updated_at),0) AS revision FROM platform_corrections').first();return Number(row?.revision)||0}
export function correctAvailability(id,data,rows){const blocked=new Set(rows.filter(x=>x.item_id===id&&x.blocked===1).map(x=>x.provider_id));return{...data,offers:(data.offers||[]).filter(x=>!blocked.has(x.id)),verification:'upstream_report_only',corrections:rows.filter(x=>x.item_id===id&&x.blocked===1).map(x=>({provider_id:x.provider_id,note:x.note,checked_at:x.updated_at,source:'household_report'}))}}
export async function filterCorrectedIds(env,ids,p){
 const providers=(p.get('providers')||p.get('with_watch_providers')||'').split('|').filter(Boolean).map(Number);if(!providers.length||!ids.length)return ids;
 const rows=await correctionRows(env,ids),data=await availabilityBatch(env,ids),access=p.get('watch_access')||'all',types=access==='stream'?['flatrate','free','ads']:access==='free'?['free','ads']:access==='rent_buy'?['rent','buy']:['flatrate','free','ads','rent','buy'],removed=new Set();
 for(const id of ids){const corrected=correctAvailability(id,data[id],rows);if(!corrected.offers.some(x=>providers.includes(x.id)&&x.types.some(type=>types.includes(type))))removed.add(id)}

 return ids.filter(id=>!removed.has(id));
}
export async function correctionApi(request,env){
 await ready(env);const url=new URL(request.url);
 if(request.method==='GET'){const ids=(url.searchParams.get('items')||'').split(',').filter(x=>/^(movie|tv)-\d+$/.test(x)).slice(0,24);return Response.json({rows:await correctionRows(env,ids)},{headers:{'Cache-Control':'no-store'}})}
 if(request.method!=='POST')return Response.json({error:'method'},{status:405});
 const raw=await request.text();if(raw.length>4000)return Response.json({error:'too_large'},{status:413});let b;try{b=JSON.parse(raw)}catch{return Response.json({error:'invalid_json'},{status:400})}
 if(!/^(movie|tv)-\d+$/.test(b.itemId||'')||!Number.isInteger(b.providerId)||b.providerId<=0||typeof b.blocked!=='boolean'||typeof b.note!=='string'||b.note.length>1000)return Response.json({error:'invalid_correction'},{status:400});
 const revision=Date.now();await env.DB.prepare('INSERT INTO platform_corrections VALUES(?,?,?,?,?) ON CONFLICT(item_id,provider_id) DO UPDATE SET blocked=excluded.blocked,note=excluded.note,updated_at=excluded.updated_at').bind(b.itemId,b.providerId,b.blocked?1:0,b.note,revision).run();return Response.json({ok:true,revision},{headers:{'Cache-Control':'no-store'}});
}
