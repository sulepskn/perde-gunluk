"""Merge the complete TR availability scan without changing personal title identifiers."""
import json
import pathlib
import re
import unicodedata
import gzip
import subprocess
import time
import urllib.request
import datetime as dt

from official_catalogue import entries

GENRES = {'action': 28, 'adventure': 12, 'animation': 16, 'comedy': 35,
          'crime': 80, 'documentation': 99, 'drama': 18, 'family': 10751,
          'fantasy': 14, 'history': 36, 'horror': 27, 'music': 10402,
          'romance': 10749, 'scifi': 878, 'thriller': 53, 'war': 10752, 'western': 37, 'reality': 10764}


def refresh_source(path):
    previous = None
    try:
        request = urllib.request.Request('https://perde-bagimsiz.sulepiskin.workers.dev/platform-snapshots/direct-availability.json.gz', headers={'User-Agent': 'PerdeDaily/1.0', 'Accept': 'application/gzip'})
        with urllib.request.urlopen(request, timeout=60) as response:
            previous = json.loads(gzip.decompress(response.read()))
    except Exception:
        pass
    candidates = [previous]
    today = dt.datetime.now(dt.timezone.utc).date()
    for source in candidates:
        if not source or source.get('region') != 'TR' or source.get('total', 0) < 10000:
            continue
        checked = dt.datetime.fromtimestamp(source['checked_at'] / 1000, dt.timezone.utc)
        if checked.date() == today and 0 <= time.time() * 1000 - source['checked_at'] < 24 * 3600000:
            source['refresh_status'] = 'same_day_snapshot'
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(json.dumps(source, ensure_ascii=False), encoding='utf-8')
            return source
    try:
        subprocess.run(['node', str(pathlib.Path(__file__).with_name('availability-source.mjs')), str(path)], check=True)
        source = json.loads(path.read_text(encoding='utf-8'))
        source['refresh_status'] = 'fresh'
    except subprocess.CalledProcessError:
        # A secondary-source outage must not stop the existing daily TMDB/IMDb refresh.
        try:
            request = urllib.request.Request('https://perde-bagimsiz.sulepiskin.workers.dev/platform-snapshots/direct-availability.json.gz', headers={'User-Agent': 'PerdeDaily/1.0', 'Accept': 'application/gzip'})
            with urllib.request.urlopen(request, timeout=60) as response:
                source = json.loads(gzip.decompress(response.read()))
            if source.get('region') != 'TR' or source.get('total', 0) < 10000:
                raise ValueError('Previous source invalid')
            source['refresh_status'] = 'previous_snapshot'
        except Exception:
            source = {'region': 'TR', 'total': 0, 'expected': 0, 'titles': [], 'checked_at': 0,
                      'refresh_status': 'unavailable'}
        path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(source, ensure_ascii=False), encoding='utf-8')
    return source


def normalized(value):
    value = unicodedata.normalize('NFKD', value.lower().replace('ı', 'i'))
    return ' '.join(''.join(c if c.isalnum() else ' ' for c in value if not unicodedata.combining(c)).split())


def item_id(node):
    kind = 'movie' if node['objectType'] == 'MOVIE' else 'tv'
    external = node['content'].get('externalIds') or {}
    for entry in entries():
        if entry['imdb_id'] == external.get('imdbId'):
            return entry['item_id']
    identifier = external.get('tmdbId')
    if identifier and str(identifier).isdigit() and 0 < int(identifier) < 64_000_000:
        return kind + '-' + str(int(identifier))
    return kind + '-' + str(900_000_000_000 + int(node['id'][2:]))


def source_detail(node):
    kind, number = item_id(node).split('-')
    content = node['content']
    date = str(content.get('originalReleaseYear') or '')
    genres = sorted({GENRES[g['technicalName']] for g in content.get('genres', []) if g['technicalName'] in GENRES})
    if kind == 'tv':
        genres = sorted({10759 if value in [28, 12] else 10765 if value in [878, 14] else value for value in genres})
    countries = content.get('productionCountries') or []
    return {'id': int(number), 'media_type': kind, 'title': content['title'], 'name': content['title'],
            'original_title': content.get('originalTitle') or content['title'],
            'original_name': content.get('originalTitle') or content['title'],
            'release_date' if kind == 'movie' else 'first_air_date': date,
            'genre_ids': genres, 'genres': [{'id': value} for value in genres],
            'origin_country': countries, 'production_countries': [{'iso_3166_1': c} for c in countries],
            'original_language': '', 'runtime': content.get('runtime') if kind == 'movie' else None,
            'adult': False, 'vote_count': 0, 'vote_average': None, 'popularity': 0, 'poster_path': None,
            'external_ids': {'imdb_id': (content.get('externalIds') or {}).get('imdbId')},
            'source_url': 'https://www.justwatch.com' + content['fullPath'], 'supplemental': True,
            'source_only': True,
            'overview': ''}


def supplemental_entries(source):
    result = []
    for node in source['titles']:
        if not node['offers']:
            continue
        identifier = item_id(node)
        if int(identifier.split('-')[1]) < 64_000_000:
            continue
        result.append({'item_id': identifier, 'title': node['content']['title'], 'supplemental': True,
                       'detail': source_detail(node)})
    return result


def catalogue_entries(source):
    return [{'item_id': item_id(node), 'title': node['content']['title'],
             'supplemental': int(item_id(node).split('-')[1]) >= 64_000_000}
            for node in source['titles'] if node['offers']]


def merge_availability(records, source, providers):
    by_name = {}
    aliases = {'max': 'hbomax', 'hbo max': 'hbomax', 'disney plus': 'disney',
               'disney+': 'disney', 'amazon prime video': 'primevideo',
               'prime video': 'primevideo', 'tv+': 'tvplus'}
    def name(value):
        value = value.strip().lower()
        return aliases.get(value) or re.sub(r'[^a-z0-9]', '', normalized(value))
    for provider in providers:
        if provider.get('display_priorities') and 'TR' not in provider['display_priorities']:
            continue
        by_name.setdefault(name(provider['provider_name']), provider['provider_id'])
    checked = source['checked_at']
    mapped = set()
    added = 0
    for node in source['titles']:
        identifier = item_id(node)
        previous = records.get(identifier, {})
        if not previous and not node['offers']:
            continue
        if source.get('refresh_status')=='previous_snapshot' and checked < previous.get('checked_at', 0) and not (previous.get('detail') or {}).get('source_only'):
            continue
        previous_detail = previous.get('detail')
        detail = source_detail(node) if not previous_detail or previous_detail.get('source_only') else previous_detail
        if not previous:
            added += 1
        offers = {offer['id']: dict(offer, types=list(offer['types']))
                  for offer in previous.get('availability', {}).get('offers', [])} if identifier in mapped else {}
        for offer in node['offers']:
            if source.get('refresh_status')=='previous_snapshot' and time.time() * 1000 - checked > 36 * 3600000:
                continue
            access = offer['monetizationType'].lower()
            if access not in ['flatrate', 'free', 'ads', 'rent', 'buy']:
                continue
            package = offer['package']
            provider_id = by_name.get(name(package['clearName']))
            if provider_id is None:
                provider_id = 500000 + int(package['packageId'])
            if provider_id >= 1000000:
                raise ValueError('Supplemental provider ID out of supported range')
            row = offers.setdefault(provider_id, {'id': provider_id, 'name': package['clearName'], 'logo': None, 'types': []})
            if access not in row['types']:
                row['types'].append(access)
        availability = {'region': 'TR', 'offers': list(offers.values()), 'checked_at': checked,
                        'link': 'https://www.justwatch.com' + node['content']['fullPath'],
                        'source': 'JustWatch Türkiye', 'source_status': 'available'}
        detail['watch_availability'] = availability
        records[identifier] = {'checked_at': checked, 'detail': detail, 'availability': availability}
        mapped.add(identifier)
    return {'source_total': source['total'], 'source_expected': source['expected'],
            'mapped_titles': len(mapped), 'new_records': added,
            'uncovered_source_titles': max(0, source['expected'] - source['total']),
            'refresh_status': source.get('refresh_status', 'fresh'),
            'checked_at': checked, 'all_years': True, 'all_providers': True}


def write_supplemental_search(output, supplements):
    buckets = {}
    for entry in supplements:
        detail = entry['detail']
        prefixes = set()
        for title in [detail.get('title', ''), detail.get('original_title', '')]:
            for word in normalized(title).split():
                prefixes.update([word[:1], word[:2]])
        for prefix in prefixes:
            buckets.setdefault(prefix.encode('utf-8').hex(), {})[entry['item_id']] = detail
    output.mkdir(parents=True, exist_ok=True)
    for prefix, values in buckets.items():
        (output / ('supplemental-search-' + prefix + '.json')).write_text(
            json.dumps(list(values.values()), ensure_ascii=False, separators=(',', ':')), encoding='utf-8')
