import fs from 'node:fs/promises';
import path from 'node:path';
import {createHash} from 'node:crypto';

const query = `query Availability($after: String, $filter: TitleFilter) {
  genres { shortName }
  popularTitles(country: TR, first: 100, after: $after, filter: $filter, sortBy: POPULAR, sortRandomSeed: 0) {
    totalCount
    edges { node { id objectType
      content(country: TR, language: tr) { title originalTitle originalReleaseYear fullPath
        externalIds { imdbId tmdbId } runtime productionCountries genres { technicalName } }
      offers(country: TR, platform: WEB) { monetizationType package { packageId clearName technicalName } }
    } }
    pageInfo { hasNextPage endCursor }
  }
}`;
const titles = new Map();
let pages = 0;
let nextRequest = 0;
let genres = [];
const cacheRoot = process.argv[2] + '.pages';
await fs.mkdir(cacheRoot,{recursive:true});
async function read(after = null, filter = null) {
  const cacheKey=createHash('sha256').update(JSON.stringify([new Date().toISOString().slice(0,10),after,filter])).digest('hex');
  const file=path.join(cacheRoot,cacheKey+'.json');
  try {const cached=JSON.parse(await fs.readFile(file,'utf8'));genres=cached.genres;pages++;return cached.data;}catch{}
  const wait = Math.max(0, nextRequest - Date.now());
  nextRequest = Math.max(Date.now(), nextRequest) + 200;
  if (wait) await new Promise(resolve => setTimeout(resolve, wait));
  for (let attempt = 0; attempt < 4; attempt++) {
    try {
      const response = await fetch('https://apis.justwatch.com/graphql', {
        method: 'POST', headers: {'Content-Type': 'application/json', 'User-Agent': 'PerdePersonalArchive/1.0'},
        body: JSON.stringify({query, variables: {after, filter}}), signal: AbortSignal.timeout(45000)
      });
      if (!response.ok) throw Error('Availability source HTTP ' + response.status);
      const result = await response.json();
      const data = result.data?.popularTitles;
      if (result.errors?.length || !data || !Number.isSafeInteger(data.totalCount) || !Array.isArray(data.edges)) throw Error('Invalid availability source');
      genres=result.data.genres.map(row=>row.shortName);
      await fs.writeFile(file,JSON.stringify({genres,data}));
      pages++;
      if (pages % 25 === 0) console.log(JSON.stringify({availability_source_titles: titles.size, requests: pages}));
      return data;
    } catch (error) {
      if (attempt === 3) throw error;
      await new Promise(resolve => setTimeout(resolve, 2000 * (attempt + 1)));
    }
  }
}
function collect(data) {
  for (const {node} of data.edges) {
    if (!/^(tm|ts)\d+$/.test(node.id) || !['MOVIE', 'SHOW'].includes(node.objectType) ||
        !node.content?.title || !Array.isArray(node.offers)) throw Error('Invalid availability title');
    titles.set(node.id, node);
  }
}
const baseline = await read();
const expected = baseline.totalCount;
if (expected < 10000) throw Error('Unexpectedly small availability source');
collect(baseline);
// Retain the source's broad sweep for undated entries, then partition dated titles.
let cursor = baseline.pageInfo.endCursor;
for (let page = 1; page < 19 && cursor; page++) {
  const data = await read(cursor);
  if (!data.edges.length) break;
  collect(data);
  cursor = data.pageInfo.hasNextPage ? data.pageInfo.endCursor : null;
}
async function window(kind, lo, hi, genre = null) {
  const filter = {objectTypes: [kind], releaseYear: {min: lo, max: hi}};
  if(genre) filter.genres=[genre];
  let data = await read(null, filter);
  if (data.totalCount >= 1800) {
    if (lo === hi) {
      if(genre) throw Error('Availability source genre window exceeds pagination cap');
      collect(data);
      let after=data.pageInfo.endCursor;
      for(let page=1;page<19&&after;page++) {const broad=await read(after,filter);if(!broad.edges.length)break;collect(broad);after=broad.pageInfo.hasNextPage?broad.pageInfo.endCursor:null;}
      for(const code of genres) await window(kind,lo,hi,code);
      return;
    }
    const mid = Math.floor((lo + hi) / 2);
    await window(kind, lo, mid);
    await window(kind, mid + 1, hi);
    return;
  }
  const wanted = data.totalCount;
  const found = new Set();
  const cursors = new Set();
  do {
    for (const edge of data.edges) found.add(edge.node.id);
    collect(data);
    if (!data.pageInfo.hasNextPage) break;
    const after = data.pageInfo.endCursor;
    if (!after || cursors.has(after)) throw Error('Availability cursor did not advance');
    cursors.add(after);
    data = await read(after, filter);
    if (!data.edges.length) throw Error('Availability source truncated a dated window');
  } while (true);
  if (found.size < wanted * 0.99) throw Error('Availability source window incomplete');
}
await window('MOVIE', 0, 2100);
await window('SHOW', 0, 2100);
if (titles.size < expected * 0.99) throw Error('Availability source below expected coverage');
const output = process.argv[2];
if (!output) throw Error('Output path required');
await fs.mkdir(path.dirname(output), {recursive: true});
await fs.writeFile(output, JSON.stringify({region: 'TR', checked_at: Date.now(), expected,
  total: titles.size, pages, titles: [...titles.values()]}));
console.log(JSON.stringify({availability_source_complete: true, titles: titles.size, pages}));
