"""Daily public Turkey availability and title details; never read personal archive APIs."""
import argparse,concurrent.futures,datetime as dt,json,os,pathlib,threading,time,urllib.request,urllib.error

KINDS=('flatrate','free','ads','rent','buy')
class Client:
    def __init__(self,key,rate=20):self.key=key;self.rate=rate;self.lock=threading.Lock();self.next=0
    def get(self,path,params=None):
        from urllib.parse import urlencode
        for attempt in range(5):
            with self.lock:
                wait=max(0,self.next-time.monotonic());self.next=max(self.next,time.monotonic())+1/self.rate
            if wait:time.sleep(wait)
            url='https://api.themoviedb.org/3/'+path+'?'+urlencode({'api_key':self.key,'language':'tr-TR',**(params or {})})
            try:
                with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'PerdePersonalArchive/1.0'}),timeout=35) as r:return json.load(r)
            except urllib.error.HTTPError as e:
                if e.code==404:return None
                if e.code not in (429,500,502,503,504):raise RuntimeError('TMDB HTTP '+str(e.code)+' on '+path) from None
                time.sleep(min(60,max(2,float(e.headers.get('Retry-After','2')))*(attempt+1)))
            except (urllib.error.URLError,TimeoutError):time.sleep(2*(attempt+1))
        raise RuntimeError('TMDB retries exhausted on '+path)

def public_json(url,missing=False):
    try:
        with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'PerdePersonalArchive/1.0'}),timeout=90) as r:
            if 'application/json' not in r.headers.get('Content-Type',''):
                if missing:return None
                raise ValueError('Expected a public JSON snapshot')
            return json.load(r)
    except urllib.error.HTTPError as e:
        if e.code==404 and missing:return None
        raise RuntimeError('Public snapshot HTTP '+str(e.code)) from None

def write_json(path,value):
    path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(value,ensure_ascii=False,separators=(',',':')),encoding='utf-8')

def discover(client,kind,report):
    common={'watch_region':'TR','with_watch_monetization_types':'|'.join(KINDS),'include_adult':'true','sort_by':'popularity.desc'}
    if kind=='tv':common['include_null_first_air_dates']='true'
    first=client.get('discover/'+kind,common)
    if not first or not isinstance(first.get('results'),list):raise ValueError('Missing discovery results')
    found={kind+'-'+str(x['id']) for x in first['results']};requests=1
    def pages(params,initial):
        nonlocal requests
        numbers=range(2,min(500,int(initial['total_pages']))+1)
        def fetch_page(page):return page,client.get('discover/'+kind,{**params,'page':page})
        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
            for page,data in pool.map(fetch_page,numbers):
                requests+=1
                if not data or not isinstance(data.get('results'),list):raise ValueError('Partial discovery page')
                found.update(kind+'-'+str(x['id']) for x in data['results'])
                if page%100==0:print(json.dumps({'discovery':kind,'page':page,'known':len(found)}),flush=True)
    if first['total_pages']<=500:pages(common,first)
    else:
        # A popular sweep includes otherwise undated records; date windows avoid the 500-page cap.
        pages(common,first)
        def window(lo,hi):
            nonlocal requests
            date='primary_release_date' if kind=='movie' else 'first_air_date'
            params={**common,date+'.gte':str(lo)+'-01-01',date+'.lte':str(hi)+'-12-31'}
            if kind=='tv':params['include_null_first_air_dates']='false'
            data=client.get('discover/'+kind,params);requests+=1
            if not data:raise ValueError('Missing discovery window')
            field='release_date' if kind=='movie' else 'first_air_date'
            if any(x.get(field) and not lo<=int(x[field][:4])<=hi for x in data['results']):raise ValueError('Source ignored discovery date window')
            if data['total_pages']>500:
                if lo==hi:raise ValueError('Single-year discovery exceeds source page cap')
                mid=(lo+hi)//2;window(lo,mid);window(mid+1,hi);return
            found.update(kind+'-'+str(x['id']) for x in data['results']);pages(params,data)
        window(1800,2099)
    report[kind]={'ids':len(found),'discovery_requests':requests,'undated_coverage':'initial source sweep plus previously known records'}
    return found

def new_catalogue_ids(root,base):
    found=set()
    for kind in ('movie','tv'):
        path=root/(kind+'-membership.bin')
        if not path.exists():continue
        try:
            with urllib.request.urlopen(urllib.request.Request(base+'/catalogue/'+kind+'-membership.bin',headers={'User-Agent':'PerdePersonalArchive/1.0'}),timeout=90) as r:previous=r.read()
        except urllib.error.HTTPError as e:
            if e.code==404:continue
            raise
        for index,value in enumerate(path.read_bytes()):
            old=previous[index] if index<len(previous) else 0
            if value==old:continue
            for slot in range(4):
                if (value>>(slot*2))&3 and not (old>>(slot*2))&3:found.add(kind+'-'+str(index*4+slot))
    if len(found)>20000:raise ValueError('Unexpected new title delta; refusing a partial bulk refresh')
    return found

def availability(detail,checked_at):
    region=detail.get('watch/providers',{}).get('results',{}).get('TR',{});grouped={}
    for access in KINDS:
        for row in region.get(access,[]):
            offer=grouped.setdefault(row['provider_id'],{'id':row['provider_id'],'name':row['provider_name'],'logo':row.get('logo_path'),'types':[]});offer['types'].append(access)
    return {'region':'TR','offers':list(grouped.values()),'link':region.get('link'),'checked_at':checked_at,'source':'JustWatch via TMDB','source_status':'available'}

def record(client,item_id):
    kind,number=item_id.split('-');d=client.get(kind+'/'+number,{'append_to_response':'external_ids,watch/providers'});checked=int(time.time()*1000)
    if d is None:return {'checked_at':checked,'detail':None,'availability':{'region':'TR','offers':[],'checked_at':checked,'source_status':'not_found'}}
    fields=['id','title','name','original_title','original_name','release_date','first_air_date','adult','genres','production_countries','origin_country','original_language','vote_count','vote_average','popularity','poster_path','overview','number_of_seasons','number_of_episodes','external_ids','imdb_id']
    detail={k:d[k] for k in fields if k in d};detail['media_type']=kind;detail['genre_ids']=[x['id'] for x in d.get('genres',[])];detail['origin_country']=d.get('origin_country') or [x['iso_3166_1'] for x in d.get('production_countries',[])]
    if kind=='movie':detail['runtime']=d.get('runtime')
    a=availability(d,checked);detail['watch_availability']=a
    return {'checked_at':checked,'detail':detail,'availability':a}

def availability_index(records):return {item:{str(o['id']):sorted(o['types']) for o in r['availability']['offers']} for item,r in records.items()}
def changes(before,after):
    if before is None:return {'baseline':True,'entered':0,'left':0,'events':[]}
    events=[];entered=left=0
    for item in sorted(set(before)|set(after)):
        a=before.get(item,{});b=after.get(item,{})
        if a==b:continue
        added=sorted(set(b)-set(a),key=int);removed=sorted(set(a)-set(b),key=int);entered+=len(added);left+=len(removed)
        events.append({'item_id':item,'added_providers':list(map(int,added)),'removed_providers':list(map(int,removed)),'access_changed':[int(k) for k in set(a)&set(b) if a[k]!=b[k]]})
    return {'baseline':False,'entered':entered,'left':left,'events':events}

def build(records,output,snapshot,previous,discovery,new_ids,started):
    index=availability_index(records);delta=changes(previous,index);buckets=[{} for _ in range(256)]
    for item,r in records.items():buckets[int(item.split('-')[1])%256][item]=r
    for i,rows in enumerate(buckets):write_json(output/(str(i).zfill(3)+'.json'),rows)
    # Small public metadata shards let broad filtered counts finish without
    # hundreds of live discovery requests or access to personal lists.
    count_shards=[[] for _ in range(64)]
    for item,r in records.items():
        d=r['detail']
        if not d:continue
        countries=[x['iso_3166_1'] for x in d.get('production_countries',[])] or d.get('origin_country',[])
        count_shards[int(item.split('-')[1])%64].append([item,int(bool(d.get('adult'))),d.get('release_date') or d.get('first_air_date') or '',d.get('genre_ids',[]),countries,d.get('original_language',''),d.get('vote_count',0),d.get('runtime'),index[item],r['checked_at']])
    for i,rows in enumerate(count_shards):write_json(output/('count-'+str(i).zfill(2)+'.json'),rows)
    write_json(output/'availability-index.json',index);write_json(output/'changes.json',delta)
    today=dt.datetime.now(dt.timezone.utc).date().isoformat();recent=[r['detail'] for r in records.values() if r['detail'] and (r['detail'].get('release_date') or r['detail'].get('first_air_date') or '')<=today]
    recent.sort(key=lambda r:r.get('release_date') or r.get('first_air_date') or '',reverse=True);write_json(output/'recent.json',{'results':recent[:100]})
    manifest={'format':1,'snapshot':snapshot,'region':'TR','started_at':started,'built_at':dt.datetime.now(dt.timezone.utc).isoformat(),'count':len(records),'buckets':256,'currently_available':sum(bool(x) for x in index.values()),'new_catalogue_titles_checked':len(new_ids),'changes':{k:delta[k] for k in ('baseline','entered','left')},'discovery':discovery,'source':'TMDB/JustWatch; source listings are not independently verified platform access','personal_data_accessed':False}
    manifest['count_shards']=64
    write_json(output/'manifest.json',manifest);return manifest

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=pathlib.Path,required=True);parser.add_argument('--catalogue',type=pathlib.Path,required=True);parser.add_argument('--base-url',required=True);parser.add_argument('--workers',type=int,default=8);parser.add_argument('--resume',type=pathlib.Path,default=pathlib.Path('work/platform-resume.jsonl'));args=parser.parse_args()
    key=os.environ.get('TMDB_API_KEY');
    if not key:raise ValueError('TMDB_API_KEY secret is required')
    started=dt.datetime.now(dt.timezone.utc).isoformat();base=args.base_url.rstrip('/');previous=public_json(base+'/platform-snapshots/availability-index.json',missing=True);client=Client(key);stats={};ids=set(previous or {});records={}
    previous_manifest=public_json(base+'/platform-snapshots/manifest.json',missing=True);today=dt.datetime.now(dt.timezone.utc).date().isoformat()
    reuse=bool(previous_manifest and previous_manifest.get('snapshot')==today and time.time()-dt.datetime.fromisoformat(previous_manifest['built_at']).timestamp()<6*3600)
    if reuse:
        client.get('configuration')
        def load_bucket(i):return public_json(base+'/platform-snapshots/'+str(i).zfill(3)+'.json')
        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
            for rows in pool.map(load_bucket,range(256)):records.update(rows)
        if len(records)!=previous_manifest['count']:raise ValueError('Previous daily snapshot is incomplete')
        stats={**previous_manifest.get('discovery',{}),'reused_current_day_records':len(records)}
    else:
        for kind in ('movie','tv'):ids.update(discover(client,kind,stats));print(json.dumps({'discovered':kind,'candidates':len(ids)}),flush=True)
    new_ids=new_catalogue_ids(args.catalogue,base);ids.update(new_ids)
    if len(ids)<10000:raise ValueError('Unexpectedly small Turkey platform universe; refusing publication')
    args.resume.parent.mkdir(parents=True,exist_ok=True)
    if args.resume.exists():
        for line in args.resume.read_text(encoding='utf-8').splitlines():
            row=json.loads(line)
            if row['item_id'] in ids and dt.datetime.fromtimestamp(row['record']['checked_at']/1000,dt.timezone.utc).date().isoformat()==today and row['record']['checked_at']>records.get(row['item_id'],{}).get('checked_at',0):records[row['item_id']]=row['record']
    with args.resume.open('a',encoding='utf-8') as checkpoint,concurrent.futures.ThreadPoolExecutor(max_workers=args.workers) as pool:
        pending={pool.submit(record,client,item):item for item in sorted(ids-set(records))}
        for future in concurrent.futures.as_completed(pending):
            item=pending[future];value=future.result();records[item]=value;checkpoint.write(json.dumps({'item_id':item,'record':value},ensure_ascii=False)+'\n')
            if len(records)%250==0:checkpoint.flush();print(json.dumps({'platform_titles_checked':len(records),'expected':len(ids)}),flush=True)
    manifest=build(records,args.output,dt.datetime.now(dt.timezone.utc).date().isoformat(),previous,stats,new_ids,started)
    if previous and manifest['currently_available']<sum(bool(v) for v in previous.values())*0.7:raise ValueError('Large availability shrink; refusing unchecked publication')
    print(json.dumps(manifest),flush=True)
if __name__=='__main__':main()
