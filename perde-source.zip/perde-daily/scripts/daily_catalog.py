"""Build public TMDB title indexes and IMDb buckets; never read personal D1 data."""
import argparse,csv,datetime as dt,gzip,hashlib,json,math,os,pathlib,struct,urllib.request

def write_json(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value,ensure_ascii=False,separators=(',',':')),encoding='utf-8')

def download(url,path):
    path.parent.mkdir(parents=True,exist_ok=True)
    request=urllib.request.Request(url,headers={'User-Agent':'PerdePersonalArchive/1.0'})
    digest=hashlib.sha256()
    with urllib.request.urlopen(request,timeout=120) as response,path.open('wb') as output:
        modified=response.headers.get('Last-Modified')
        while chunk:=response.read(1024*1024):
            output.write(chunk);digest.update(chunk)
    return {'url':url,'sha256':digest.hexdigest(),'last_modified':modified}

def build_catalogue(inputs,output,snapshot,minimum=1_000_000):
    by_id={}
    for media_type,adult,path in inputs:
        with gzip.open(path,'rt',encoding='utf-8') as source:
            for line in source:
                row=json.loads(line);identifier=row['id'];title=row.get('original_title') or row.get('original_name')
                if not isinstance(identifier,int) or not 0<identifier<64_000_000 or not isinstance(title,str):
                    raise ValueError('Invalid TMDB export row')
                popularity=float(row.get('popularity') or 0)
                if not math.isfinite(popularity):raise ValueError('Invalid popularity')
                by_id[media_type,identifier]=[media_type,identifier,title,popularity,int(adult or bool(row.get('adult')))]
    rows=list(by_id.values());del by_id
    if len(rows)<minimum:raise ValueError('Catalogue below minimum; refusing partial publication')
    counts=[]
    for media_type in ['movie','tv']:
        selected=[x for x in rows if x[0]==media_type]
        bits=bytearray(max((x[1] for x in selected),default=0)//4+1)
        for x in selected:bits[x[1]//4]|=(2 if x[4] else 1)<<((x[1]%4)*2)
        output.mkdir(parents=True,exist_ok=True);(output/(media_type+'-membership.bin')).write_bytes(bits)
        for adult in [0,1]:counts.append({'media_type':media_type,'adult':adult,'count':sum(x[4]==adult for x in selected)})
    size=6000
    for sort in ['popular','title']:
        rows.sort(key=(lambda x:(-x[3],x[0],x[1])) if sort=='popular' else (lambda x:(x[2].casefold(),x[0],x[1])))
        for index,start in enumerate(range(0,len(rows),size)):write_json(output/(sort+'-'+str(index).zfill(4)+'.json'),rows[start:start+size])
    manifest={'snapshot':snapshot,'total':len(rows),'counts':counts,'chunk_size':size,'chunks':math.ceil(len(rows)/size),'sorts':['popular','title'],'format':1}
    write_json(output/'manifest.json',manifest);return manifest

def build_imdb(source,output,snapshot,minimum=1_000_000):
    buckets=[[] for _ in range(256)];count=0
    with gzip.open(source,'rt',encoding='utf-8',newline='') as handle:
        reader=csv.DictReader(handle,delimiter='\t')
        if reader.fieldnames!=['tconst','averageRating','numVotes']:raise ValueError('Unexpected IMDb schema')
        for row in reader:
            identifier=int(row['tconst'].removeprefix('tt'));rating=round(float(row['averageRating'])*10);votes=int(row['numVotes'])
            if not 0<identifier<2**32 or not 0<=rating<=100 or not 0<=votes<2**32:raise ValueError('Invalid IMDb rating')
            buckets[identifier%256].append((identifier,rating,votes));count+=1
    if count<minimum:raise ValueError('IMDb below minimum; refusing partial publication')
    output.mkdir(parents=True,exist_ok=True)
    for number,rows in enumerate(buckets):
        rows.sort(key=lambda x:x[0])
        with (output/(str(number).zfill(3)+'.bin')).open('wb') as handle:
            for row in rows:handle.write(struct.pack('<IBI',*row))
    manifest={'snapshot':snapshot,'count':count,'buckets':256,'record_size':9,'format':'uint32le imdb-number, uint8 rating-times-10, uint32le votes','source':'IMDb Non-Commercial Datasets','source_sha256':hashlib.sha256(source.read_bytes()).hexdigest()}
    write_json(output/'manifest.json',manifest);return manifest

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=pathlib.Path,required=True);parser.add_argument('--work',type=pathlib.Path,default=pathlib.Path('work/daily-downloads'));parser.add_argument('--date',default=dt.datetime.now(dt.timezone.utc).date().isoformat());args=parser.parse_args()
    date=dt.date.fromisoformat(args.date);stamp=date.strftime('%m_%d_%Y');sources=[];inputs=[]
    for media_type,name in [('movie','movie'),('tv','tv_series')]:
        for adult in [False,True]:
            filename=('adult_' if adult else '')+name+'_ids_'+stamp+'.json.gz';path=args.work/filename
            sources.append(download('https://files.tmdb.org/p/exports/'+filename,path));inputs.append((media_type,adult,path))
    ratings=args.work/'title.ratings.tsv.gz';sources.append(download('https://datasets.imdbws.com/title.ratings.tsv.gz',ratings))
    catalogue=build_catalogue(inputs,args.output/'catalogue',args.date);imdb=build_imdb(ratings,args.output/'imdb',args.date)
    checkpoint=pathlib.Path('status/latest-public-snapshot.json')
    if checkpoint.exists():
        previous=json.loads(checkpoint.read_text(encoding='utf-8'))
        if catalogue['total']<previous.get('catalogue_total',0)*0.95 or imdb['count']<previous.get('imdb_count',0)*0.95:raise ValueError('Unexpected snapshot shrink; refusing publication')
    write_json(args.output/'daily-status.json',{'execution_origin':'github_actions' if os.getenv('GITHUB_ACTIONS')=='true' else 'local_manual','built_at':dt.datetime.now(dt.timezone.utc).isoformat(),'catalogue_date':args.date,'catalogue_total':catalogue['total'],'imdb_count':imdb['count'],'sources':sources,'personal_data_accessed':False})
    print(json.dumps({'catalogue_total':catalogue['total'],'imdb_count':imdb['count'],'personal_data_accessed':False}))

if __name__=='__main__':main()
