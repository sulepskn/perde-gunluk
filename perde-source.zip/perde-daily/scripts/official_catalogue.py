"""Supplement missing upstream records using dated, country-specific official listings."""
import datetime as dt
import json
import pathlib
import re
import time
import urllib.error
import urllib.request

REGISTRY = pathlib.Path(__file__).parents[1] / 'config' / 'catalogue-supplements.json'


def entries():
    return json.loads(REGISTRY.read_text(encoding='utf-8'))


def parse_listing(document, entry, now):
    def script(identifier):
        match = re.search(r'<script\b(?=[^>]*\bid=["\']' + re.escape(identifier) + r'["\'])[^>]*>(.*?)</script>', document, re.S)
        if not match:
            raise ValueError('Official listing data missing: ' + entry['item_id'])
        return json.loads(match[1])

    geo = script('__DOTCOM_GEO__')['pageLocales']
    if geo.get('urlCountry') != 'tr':
        raise ValueError('Official listing country mismatch')
    windows = geo.get('windows', {})
    window = windows.get('tr/tr') or windows.get('tr/en')
    if not isinstance(window, list) or len(window) != 2:
        raise ValueError('Official Turkey publication window missing')
    start, end = [dt.datetime.fromisoformat(value.replace('Z', '+00:00')) for value in window]
    page = script('__NEXT_DATA__')['props']['pageProps']
    feature = entry['source_url'].rsplit('/', 1)[1]
    matches = [value for value in page.get('mappedData', {}).values()
               if isinstance(value, dict) and value.get('featureId') == feature and 'releaseDate' in value]
    if len(matches) != 1:
        raise ValueError('Official title identity mismatch')
    data = matches[0]
    title = data.get('title', {}).get('full')
    if title != entry['title']:
        raise ValueError('Official title changed; review required')
    runtime = data.get('runtime', '')
    if not re.fullmatch(r'(?:(\d+)h\s*)?(?:(\d+)m)?', runtime) or not runtime:
        raise ValueError('Official runtime missing')
    parts = re.fullmatch(r'(?:(\d+)h\s*)?(?:(\d+)m)?', runtime)
    summary = data.get('summary', {})
    overview = summary.get('long') or summary.get('short') or '' if isinstance(summary, dict) else str(summary)
    checked = int(now.timestamp() * 1000)
    offer = {'id': 1899, 'name': 'HBO Max', 'logo': None, 'types': ['flatrate']}
    availability = {'region': 'TR', 'offers': [offer] if start <= now < end else [],
                    'link': entry['source_url'], 'checked_at': checked, 'source': 'HBO Max Türkiye',
                    'source_status': 'available', 'official_listing': True,
                    'publication_window': window}
    return {'id': int(entry['item_id'].split('-')[1]), 'media_type': 'movie',
            'title': title, 'original_title': title, 'release_date': data['releaseDate'],
            'runtime': int(parts[1] or 0) * 60 + int(parts[2] or 0),
            'genres': [{'id': 16, 'name': 'Animasyon'}, {'id': 35, 'name': 'Komedi'}],
            'genre_ids': [16, 35], 'origin_country': ['US'],
            'production_countries': [{'iso_3166_1': 'US'}], 'original_language': 'en',
            'adult': False, 'vote_count': 0, 'vote_average': None, 'popularity': 0,
            'poster_path': None, 'overview': overview,
            'external_ids': {'imdb_id': entry['imdb_id']},
            'source_url': entry['source_url'], 'supplemental': entry['supplemental'],
            'watch_availability': availability}


def refresh_official(records, fetch=None, now=None):
    now = now or dt.datetime.now(dt.timezone.utc)
    if fetch is None:
        def fetch(url):
            request = urllib.request.Request(url, headers={'User-Agent': 'PerdePersonalArchive/1.0'})
            for attempt in range(3):
                try:
                    with urllib.request.urlopen(request, timeout=45) as response:
                        return response.read().decode('utf-8')
                except (urllib.error.URLError, TimeoutError):
                    if attempt == 2:
                        raise
                    time.sleep(2 * (attempt + 1))
    for entry in entries():
        detail = parse_listing(fetch(entry['source_url']), entry, now)
        previous = records.get(entry['item_id'], {})
        upstream = previous.get('detail') or {}
        # Preserve upstream scores and artwork while filling missing official metadata.
        merged = {**detail, **upstream, 'runtime': upstream.get('runtime') or detail['runtime'],
                  'source_url': detail['source_url'], 'supplemental': detail['supplemental']}
        for field in ['genres', 'genre_ids', 'origin_country', 'production_countries',
                      'original_language', 'overview', 'external_ids']:
            if not merged.get(field):
                merged[field] = detail[field]
        availability = dict(previous.get('availability') or detail['watch_availability'])
        offers = [offer for offer in availability.get('offers', []) if offer['id'] != 1899]
        offers.extend(detail['watch_availability']['offers'])
        availability.update({**detail['watch_availability'], 'offers': offers})
        merged['watch_availability'] = availability
        records[entry['item_id']] = {'checked_at': availability['checked_at'],
                                     'detail': merged, 'availability': availability}
    return records
